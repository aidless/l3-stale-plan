#!/usr/bin/env python3
"""L3 v3 runner — plan-version carrier, with resource names always visible.

D16 finding: in v2, deleting the S_c carrier also deleted the ONLY occurrence of
the resource names (`store-a`/`store-b`), because they appeared solely inside the
carrier messages and nowhere in the system prompt.  The deletion arm therefore
could not land a single accepted write *before* the invalidation event, so the
label "stale-plan failure" did not describe what happened.

v3 isolates the plan-version signal from the identifier vocabulary:
  * resource names, target paths and file names are in the SYSTEM PROMPT for
    BOTH arms -- always available, byte-identical;
  * the ONLY carrier content is the version mapping (which plan row is current
    after a change), held in conversation history.  keep = mapping present,
    del = mapping removed.  Everything else is identical.
Therefore a deletion-arm episode that fails after injection has genuinely
lost only the version information, not the ability to address the service.

This is a NEW orchestration-layer file.  Frozen layer (6 files), v2 runner,
and the v2 preregistration are untouched.  Does not become an experiment until
a v3 preregistration is approved (draft at L3_V3_PREREG_DRAFT.md).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import statistics
import sys
import threading
import time
import urllib.error
from concurrent.futures import ThreadPoolExecutor

ROOT = pathlib.Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import agent_arm  # noqa: E402
import v2_runner_sc as v2  # noqa: E402

MAX_TOKENS = v2.MAX_TOKENS_V2
MAX_CALLS = v2.MAX_CALLS
INJECT_TURN = 5
MAX_TURNS = v2.MAX_TURNS

# 两臂逐字相同：资源名/路径/文件名全部常驻，删载体只删版本映射。
SYSTEM_PROMPT = (
    "You are an agent migrating files on a remote storage service.\n"
    "Goal: all files written to the current target path.\n"
    "There are {n_files} files: {first} .. {last}.\n"
    "Two storage resources exist and are always usable: {r0} and {r1}.\n"
    "Two plan rows exist: row v1 -> resource {r0}, target {t1}; "
    "row v2 -> resource {r1}, target {t2}.\n"
    "Rules:\n"
    "- The service may change at any time. `stat` does not publish which row is current.\n"
    "- `write` needs the plan_version your write is based on (1 or 2). "
    "A write based on an outdated plan_version is rejected.\n"
    "- A turn may contain at most 8 `write` calls; you cannot finish everything in one turn.\n"
    "- When the service changes, which row is current is recorded in your prior "
    "conversation; `stat` will not tell you.\n"
    "- Use `verify` only for files you already wrote.\n"
    "Reply with tool calls only; no prose."
)

INJECT_NOTICE = v2.INJECT_NOTICE  # 两臂逐字同一句


def version_messages(card: dict) -> list[dict]:
    """v3 载体：只有版本映射。资源名/路径在 system prompt 里，不在这里。"""
    note = (
        "Migration note from the previous session — the service publishes two plan rows; "
        "exactly one is current and the service will not tell you which:\n"
        f"  plan v1: basis_version=1\n"
        f"  plan v2: basis_version=2\n"
        "After the service reports a change, the later row is the one that holds."
    )
    return [
        {"role": "user", "content": note},
        {"role": "assistant", "content": "Noted — I will use the row that is current."},
    ]


class EnvV3(v2.EnvSC):
    """同 v2 环境；stat 仍不回授版本/目标（D11.1），资源名在提示里恒可见。"""

    def stat(self, card: dict) -> dict:
        return {"note": "the service does not publish a plan; consult what you have on record",
                "files_seen": 0}


def run_episode(client, card: dict, keep_carrier: bool, max_turns: int = MAX_TURNS) -> dict:
    env = EnvV3(card)
    written: dict[str, bool] = {}
    system = SYSTEM_PROMPT.format(
        n_files=card["n_steps"], first=card["files"][0], last=card["files"][-1],
        r0=card["resources"][0], r1=card["resources"][1],
        t1=card["target_v1"], t2=card["target_v2"])
    messages = [{"role": "system", "content": system}]
    if keep_carrier:
        messages.extend(version_messages(card))
    trace = {
        "schema": "l3-trace-v3/v1",
        "card_id": card["card_id"], "model": getattr(client, "model", "?"),
        "arm": "keep" if keep_carrier else "del",
        "carrier": "S_version:history", "carrier_present": keep_carrier,
        "injection": None, "steps": [], "errors": [], "budget_exhausted": False,
    }
    started = time.time()

    for turn in range(max_turns):
        if sum(written.values()) >= card["n_steps"]:
            break
        if turn >= INJECT_TURN and not env.injected:
            env.inject(card)
            trace["injection"] = {"step": turn, "from_version": 1, "to_version": 2,
                                  "kind": card["injection"]["kind"]}
            messages.append({"role": "user", "content": INJECT_NOTICE})
        try:
            choice = client.complete(messages)
        except agent_arm.Budget as e:
            trace["budget_exhausted"] = True
            trace["errors"].append(str(e))
            break
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError,
                json.JSONDecodeError) as e:
            trace["errors"].append(f"transport:{type(e).__name__}:{e}")
            break

        message = choice.get("message") or {}
        tool_calls = message.get("tool_calls") or []
        finish = choice.get("finish_reason")
        am = {"role": "assistant", "content": message.get("content") or ""}
        if tool_calls:
            am["tool_calls"] = tool_calls
        messages.append(am)
        if not tool_calls:
            trace["steps"].append({"step": turn, "plan_version": env.plan_version,
                                   "tool_calls": [], "text": (message.get("content") or "")[:300],
                                   "finish": finish})
            break
        step_calls = []
        for call in tool_calls:
            res = v2.dispatch(call, env, card, written)
            step_calls.append({"tool": call["function"]["name"],
                               "args": agent_arm._safe_args(call),
                               "ok": res.get("ok", False),
                               "result": res.get("result"),
                               "error": res.get("error")})
            messages.append({"role": "tool", "tool_call_id": call.get("id", ""),
                             "content": json.dumps(res, ensure_ascii=False)[:800]})
        trace["steps"].append({"step": turn, "plan_version": env.plan_version,
                               "tool_calls": step_calls, "finish": finish})

    last = trace["steps"][-1] if trace["steps"] else {}
    trace["final"] = {
        "verified_count": sum(written.values()),
        "n_files": card["n_steps"],
        "final_target": env.target,
        "tool_call_count": sum(len(s["tool_calls"]) for s in trace["steps"]),
        "trajectory_length": len(trace["steps"]),
        "empty_tail": (not last.get("tool_calls")),
        "last_finish": last.get("finish"),
        "token_proxy": client.prompt_tokens + client.completion_tokens,
        "wall_clock_s": round(time.time() - started, 2),
    }
    trace["usage"] = {"calls": client.calls, "prompt_tokens": client.prompt_tokens,
                      "completion_tokens": client.completion_tokens}
    trace["verdict"] = v2.verdict_of(trace)
    return trace


class ScriptedClient:
    """零 API：有版本映射且见变更通知才切 v2；否则一直用 v1 行。"""

    def __init__(self, keep_carrier: bool, per_turn: int = 4, card: dict | None = None):
        self.keep_carrier = keep_carrier
        self.card = card or make_card()
        self.per_turn = per_turn
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.max_calls = MAX_CALLS
        self.model = "scripted"

    def complete(self, messages):
        self.calls += 1
        seen_change = any(m.get("role") == "user" and "reported a change" in (m.get("content") or "")
                          for m in messages)
        has_map = any("basis_version=2" in (m.get("content") or "")
                      for m in messages if m.get("role") == "user")
        use_v2 = seen_change and has_map
        n_done = sum(1 for m in messages if m.get("role") == "tool"
                     and '"files"' in (m.get("content") or ""))
        idx = n_done * self.per_turn
        card = self.card
        files = card["files"][idx:min(idx + self.per_turn, card["n_steps"])]
        target = card["target_v2"] if use_v2 else card["target_v1"]
        store = card["resources"][1] if use_v2 else card["resources"][0]
        basis = 2 if use_v2 else 1
        call = {"id": f"c{self.calls}", "type": "function",
                "function": {"name": "write", "arguments": json.dumps(
                    {"files": files, "resource": store, "basis_version": basis,
                     "target": target})}}
        return {"message": {"content": "", "tool_calls": [call]}, "finish_reason": "tool_calls"}


def make_card(n_files: int = 40, seed: int = 200000) -> dict:
    card = v2.make_card(n_files=n_files, seed=seed)
    card["schema"] = "l3-card-v3/v1"
    card["carrier"] = "S_version:history"
    card["injection"] = {"kind": "plan_invalidation",
                         "effect": "plan_version 1->2, store-a unavailable, target v1->v2; "
                                   "resource names remain visible in the prompt"}
    return card


def count_ok_writes(trace: dict) -> int:
    return sum(1 for step in trace["steps"] for c in step["tool_calls"]
               if c["tool"] == "write" and c["ok"])


def selftest() -> None:
    ok = 0
    card = make_card()
    keep_sys = SYSTEM_PROMPT.format(
        n_files=40, first="f00", last="f39", r0="store-a", r1="store-b",
        t1="/dst/200000/v1", t2="/dst/200000/v2")
    del_sys = keep_sys
    assert keep_sys == del_sys
    assert "store-a" in keep_sys and "store-b" in keep_sys
    print("[PASS] 两臂 system 提示逐字同，且两资源名常驻（D16 修法）"); ok += 1

    carrier = version_messages(card)
    blob = " ".join(m["content"] for m in carrier)
    assert "basis_version=1" in blob and "basis_version=2" in blob
    assert "store-a" not in blob and "store-b" not in blob
    print("[PASS] v3 载体只含版本映射，不含资源名（删臂仍可寻址）"); ok += 1

    envstat = EnvV3(card).stat(card)
    assert "store-a" not in json.dumps(envstat) and "plan_version" not in json.dumps(envstat)
    print("[PASS] stat 不泄漏版本/目标（D11.1 不变）"); ok += 1

    tr_k = run_episode(ScriptedClient(True), card, keep_carrier=True)
    assert tr_k["verdict"] == "RECOVERED", (tr_k["verdict"], tr_k["final"])
    print(f"[PASS] GREEN 版本映射在 → RECOVERED（{tr_k['final']['verified_count']}/40）"); ok += 1

    tr_d = run_episode(ScriptedClient(False), card, keep_carrier=False)
    assert tr_d["verdict"] == "STALE_FAILURE", (tr_d["verdict"], tr_d["final"])
    before = [s for s in tr_d["steps"] if tr_d["injection"] and s["step"] < tr_d["injection"]["step"]]
    ok_before = sum(1 for s in before for c in s["tool_calls"] if c["tool"] == "write" and c["ok"])
    assert ok_before > 0, ("v3 删臂注入前必须能成功写，否则 D16 混杂没除掉", ok_before)
    print(f"[PASS] RED 版本映射删 → STALE_FAILURE，且注入前成功写 {ok_before} 次（非 v2 零写）"); ok += 1

    # 假阳守卫：把载体里的版本映射抹掉（只剩资源名），删臂不得再 RECOVERED
    bad = ScriptedClient(False)
    tr_bad = run_episode(bad, card, keep_carrier=False)
    assert count_ok_writes(tr_bad) > 0 and tr_bad["verdict"] == "STALE_FAILURE"
    print("[PASS] 假阳守卫：只有资源名没有版本 → 仍 STALE，不误判为恢复"); ok += 1

    # 网格落盘自检：零 API 走 run_grid，剪断必须是「del 能写但版本错」
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        rep = run_grid("http://127.0.0.1:1/v1", "scripted/model", 2, 2,
                       pathlib.Path(td), resume=False, scripted=True)
        assert rep["n_records"] == 4, rep["n_records"]
        assert rep["cells"]["del"]["STALE_FAILURE"] == 2, rep["cells"]["del"]
        assert rep["cells"]["keep"]["RECOVERED"] == 2, rep["cells"]["keep"]
        # D16 判据落进报告：del 臂注入前成功写必须 > 0
        assert rep["writes"]["del"]["ok_before_injection_total"] > 0, rep["writes"]["del"]
        assert rep["writes"]["keep"]["ok_before_injection_total"] > 0, rep["writes"]["keep"]
        assert rep["schema"] == "l3-v3-report/v1"
        assert rep["version_only_carrier"] is True
        stage = pathlib.Path(td)
        assert len(list((stage / "judgements").glob("*.json"))) == 4
        assert len(list((stage / "traces").glob("*.json"))) == 4
        assert json.loads((stage / "state.json").read_text())["finished"] is True
    print("[PASS] 网格落盘：4 条 judgement/trace、del 2/2 STALE 且注入前成功写 > 0、state finished"); ok += 1

    print(f"SELFTEST PASS ({ok}/7)")


def _records_from_judgements(out: pathlib.Path) -> list[dict]:
    recs = []
    for q in sorted((out / "judgements").glob("*.json")):
        j = json.loads(q.read_text(encoding="utf-8"))
        recs.append({k: j[k] for k in ("card_id", "arm", "verdict", "slug", "tokens",
                                       "verified", "steps", "errors", "transport_loss")})
    return recs


def writes_block(judgements: list[dict]) -> dict:
    """v3 独有诊断：删臂必须能写（注入前成功写 > 0），否则 D16 混杂没除掉。"""
    out = {}
    for arm in ("keep", "del"):
        js = [j for j in judgements if j["arm"] == arm and not j["transport_loss"]]
        out[arm] = {
            "n": len(js),
            "episodes_with_ok_write": sum(1 for j in js if j.get("ok_writes", 0) > 0),
            "ok_before_injection_total": sum(j.get("ok_before_injection", 0) for j in js),
            "median_ok_writes": statistics.median([j.get("ok_writes", 0) for j in js]) if js else None,
        }
    return out


def run_grid(base_url: str, model: str, cards: int, workers: int, out: pathlib.Path,
             resume: bool, scripted: bool = False) -> dict:
    for sub in ("traces", "judgements"):
        (out / sub).mkdir(parents=True, exist_ok=True)
    card_list = [make_card(40, 200000 + i * 1000) for i in range(cards)]
    jobs = [(c, keep) for c in card_list for keep in (True, False)]
    slug_of = lambda c, k: (f"{model.replace('/', '_')}__{c['card_id']}__"
                           f"{'keep' if k else 'del'}__r0")
    done, recs = set(), []
    if resume:
        recs = _records_from_judgements(out)
        done = {r["slug"] for r in recs}
    lock = threading.Lock()
    t0 = time.time()
    state = {"finished": False, "planned": len(jobs), "done_slugs": sorted(done)}

    def write_state():
        tmp = out / "state.json.tmp"
        tmp.write_text(json.dumps(state, ensure_ascii=False, default=list), encoding="utf-8")
        tmp.replace(out / "state.json")

    write_state()

    def work(job):
        card, keep = job
        slug = slug_of(card, keep)
        if slug in done:
            return None
        client = (ScriptedClient(keep, card=card) if scripted
                  else v2.make_client(base_url, model))
        tr = run_episode(client, card, keep_carrier=keep)
        tr["slug"] = slug
        (out / "traces" / f"{slug}.json").write_text(
            json.dumps(tr, ensure_ascii=False, indent=1), encoding="utf-8")
        inj = tr["injection"]["step"] if tr["injection"] else None
        ok_w = count_ok_writes(tr)
        ok_b = sum(1 for s in tr["steps"] if inj is not None and s["step"] < inj
                   for c in s["tool_calls"] if c["tool"] == "write" and c["ok"])
        jm = {"schema": "l3-judgement-v3/v1", "slug": slug, "card_id": card["card_id"],
              "arm": "keep" if keep else "del", "carrier": "S_version:history",
              "verdict": tr["verdict"], "metrics": tr["final"],
              "tokens": tr["usage"]["prompt_tokens"] + tr["usage"]["completion_tokens"],
              "verified": tr["final"]["verified_count"],
              "steps": tr["final"]["trajectory_length"], "errors": tr["errors"],
              "transport_loss": any("transport" in str(e) for e in tr["errors"]),
              "ok_writes": ok_w, "ok_before_injection": ok_b}
        (out / "judgements" / f"{slug}.json").write_text(
            json.dumps(jm, ensure_ascii=False, indent=1), encoding="utf-8")
        with lock:
            recs.append({k: jm[k] for k in ("card_id", "arm", "verdict", "slug", "tokens",
                                           "verified", "steps", "errors", "transport_loss")})
            state["done_slugs"].append(slug)
            write_state()
        return jm

    with ThreadPoolExecutor(max_workers=workers) as pool:
        list(pool.map(work, jobs))

    recs.sort(key=lambda r: (r["card_id"], r["arm"]))
    state["finished"] = True
    write_state()
    judgements = [json.loads(q.read_text(encoding="utf-8"))
                  for q in sorted((out / "judgements").glob("*.json"))]
    summary = v2.summarize(recs)
    report = {"schema": "l3-v3-report/v1", "model": model, "cards": cards,
              "arms": ["keep", "del"], "carrier": "S_version:history",
              "version_only_carrier": True,
              "max_tokens": MAX_TOKENS, "inject_turn": INJECT_TURN,
              "wall_clock_s": round(time.time() - t0, 2),
              "writes": writes_block(judgements), **summary}
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1),
                                     encoding="utf-8")
    return report


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--base-url", default=v2.DEFAULT_BASE)
    ap.add_argument("--model", default="openrouter/minimax/minimax-m3.1-flash")
    ap.add_argument("--cards", type=int, default=40)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--out", default="runs/l3-v3-sc")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--scripted", action="store_true",
                    help="零 API 自检：用 ScriptedClient 走完整落盘路径")
    args = ap.parse_args()
    if args.selftest:
        selftest()
        return 0
    out = pathlib.Path(args.out)
    rep = run_grid(args.base_url, args.model, args.cards, args.workers, out,
                   args.resume, args.scripted)
    print(json.dumps({"cells": rep["cells"], "paired": rep["paired"],
                      "writes": rep["writes"]}, ensure_ascii=False, indent=1))
    print(f"records={rep['n_records']} wall={rep['wall_clock_s']}s out={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
