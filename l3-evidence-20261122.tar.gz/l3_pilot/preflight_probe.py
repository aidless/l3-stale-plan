#!/usr/bin/env python3
"""Magpie 通道 preflight 探针：连续 3 次 200 才把模型放进白名单。
防止当日额度耗尽的通道（如 deepseek 429）烧整批 resume 状态。
用法：
  python3 preflight_probe.py --base-url http://127.0.0.1:3425/v1 --models m1 m2 m3
  python3 preflight_probe.py --selftest
退出码：0 = 至少一个模型过探针；3 = 全部不可用。
"""
import argparse, json, sys, urllib.request, urllib.error

def probe_once(base_url, model, timeout=30):
    body = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": "reply with: ok"}],
        "max_tokens": 8,
        "temperature": 0,
    }).encode()
    req = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",
        data=body, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            j = json.loads(r.read().decode())
            return {"ok": True, "http": r.status,
                    "content": j["choices"][0]["message"].get("content")}
    except urllib.error.HTTPError as e:
        return {"ok": False, "http": e.code, "err": f"HTTPError {e.code}: {e.reason}"}
    except Exception as e:
        return {"ok": False, "http": None, "err": f"{type(e).__name__}: {e}"}

def preflight(base_url, models, tries=3, timeout=30):
    out = {}
    for m in models:
        results = [probe_once(base_url, m, timeout) for _ in range(tries)]
        all_ok = all(r["ok"] for r in results)
        out[m] = {"whitelisted": all_ok, "probes": results}
    return out

def selftest():
    # 2026-11-17 修复：GREEN 原来硬依赖公网模型 `group/difficulty-four`，
    # 该模型 11-17 变 404 后闸的 selftest 假红——闸的健康不该由外部通道决定。
    # 改为本地 http.server 夹具：同端口先 200（GREEN）再 429（RED），两者都不碰网络。
    import http.server
    import threading

    class Fixture(http.server.BaseHTTPRequestHandler):
        status = 200

        def do_POST(self):
            self.send_response(Fixture.status)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            if Fixture.status == 200:
                self.wfile.write(json.dumps({"choices": [
                    {"message": {"content": "ok"}}]}).encode())
            else:
                self.wfile.write(b'{"error":"Too Many Requests"}')

        def log_message(self, *a):
            pass

    srv = http.server.HTTPServer(("127.0.0.1", 0), Fixture)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    base = f"http://127.0.0.1:{srv.server_port}/v1"
    try:
        # RED 1：不存在的端口必须失败
        bad = probe_once("http://127.0.0.1:1/v1", "x", timeout=3)
        assert not bad["ok"], "不存在的端口必须失败"
        print("[PASS] RED 不存在的端口判失败：", bad.get("err"))

        # RED 2：429 连续 3 次必须不进白名单
        Fixture.status = 429
        throttled = preflight(base, ["fixture/throttled"], tries=3)
        assert not throttled["fixture/throttled"]["whitelisted"], "429 必须不进白名单"
        print("[PASS] RED 429 三连判不进白名单")

        # GREEN：200 连续 3 次必须进白名单（底物是本地夹具，与外部模型上下线无关）
        Fixture.status = 200
        good = preflight(base, ["fixture/ok"], tries=3)
        assert good["fixture/ok"]["whitelisted"], "200 三连必须进白名单"
        print("[PASS] GREEN 本地夹具 200 三连进白名单")
    finally:
        srv.shutdown()
        srv.server_close()
    print("SELFTEST PASS")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://127.0.0.1:3425/v1")
    ap.add_argument("--models", nargs="+", default=[
        "volcengine/glm-5.3-flash",
        "openrouter/minimax/minimax-m3.1-flash",
        "workbuddy/deepseek-v4.1-flash",
    ])
    ap.add_argument("--tries", type=int, default=3)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        selftest(); return 0
    res = preflight(a.base_url, a.models, a.tries)
    print(json.dumps(res, ensure_ascii=False, indent=2))
    wl = [m for m, v in res.items() if v["whitelisted"]]
    print("\n白名单：", wl or "（空）")
    return 0 if wl else 3

if __name__ == "__main__":
    sys.exit(main())
