# L3 v2 预注册（**已生效**）— 记忆载体有效性检验

> 状态：**APPROVED / IN FORCE（2026-11-17）**。生效范围：仅 v2 主线（S_c）。`PREREG_L3.md`（v1）与其冻结层 6 文件**原样保留、不被替换**——v2 是独立登记的新协议，v1 作为历史对照口径继续可引。
> 生效判据：编排层（v2 runner 及其工具链）单独登记哈希（§9），冻结层 6 文件哈希必须与 `PREREG_L3.md:11-16` 逐字一致。
> 依据：D6（提示混杂，记忆惰性）、D8.4（任务本质/免费纠错）、D10（量具截断）、D11（载体冗余与“不可恢复”判据）、D11.5 阳性对照实测（`l3_pilot/lab_v2_positive_control.py` selftest 6/6）、D12（S_c 主确证）、D12.4/D12.5（清污闸与第二确证）、D13（第五类判定实现与重判可比性）。
> 日期：2026-11-16 起草；2026-11-17 生效（用户 GO「全做」）。

## 1. 研究问题（v2）
在**提示逐字恒定**且**服务端不提供免费纠错**的环境下，删除一个“不可由工具调用/错误响应重建”的计划载体，是否使 stale 率显著上升？若阳性对照也测不出差异，结论只能是“该任务族的记忆需求不足以驱动行为”，**不得**写成“记忆机制无效”（D11.5）。

## 2. 载体选择与判据

**硬判据（D11.4）**：载体被删后，模型无法通过任何工具调用（含错误响应）重建它。

| 载体 | 判据 | 结论 |
|---|---|---|
| (b) 工具参数默认值 | 不满足（write 无 default，`stat`/错误可回授资源与目标，`agent_arm.py:44-79,187-192`） | **淘汰** |
| (a) 检索内容（retriever 现取） | **可满足（有条件）**：被删条目不在检索语料，且 `stat`/错误不泄露其字段 | 作为**敏感性臂** S_a |
| (c) KV 可见历史（plan 以历史 tool_result/消息形态出现，删除=裁剪历史） | **满足（最干净）**：历史无重放接口，删后不可重取 | 作为**主臂** S_c |

**主选择：S_c（KV 可见历史）**。理由：不依赖检索基础设施，删除语义明确（裁掉包含计划的历史片段），编排层可实现；S_a 需额外保证检索与 `stat` 无泄漏，作为敏感性验证。

## 3. 环境与量具修订（对 v1 的必要改动）

| 项 | v1（缺陷） | v2（规定） | 证据/位置 |
|---|---|---|---|
| 提示 | B/D 一次差三处 | **全臂逐字同一 system+注入提示**，仅载体不同 | D6；`agent_arm.py:124-125,128,130,313-332` |
| `stat` | 回 `{plan_version,target,resource}` 与 m-plan 冗余 | `stat` **不回** target/resource/plan 映射（仅回无计划信息的状态） | D11.1；`engine.py:24-30` |
| 错误回授 | `stale_basis` 带 `current_plan_version`，`wrong_target` 带 `current_target` | 错误**不含**正确 plan/target/resource | D11.2；`agent_arm.py:187-192` |
| 记忆执行性 | quota/jsonl 无执行点；m-plan 与 stat 冗余 | 载体必须承载**不可恢复**的决策信息（见 §4 阳性对照卡） | D11.3 |
| 输出长度 | `max_tokens=400` 截断 reasoning→空 tool_calls→假 INCOMPLETE | `max_tokens ≥ 1600` **或** `finish=length 且空 tool_calls` 时截断续跑（预注册锁定其一） | D10；`agent_arm.py:105`；repro 12/12 |
| 报告口径 | INCOMPLETE 混入完成率 | 单列 **量具截断型 INCOMPLETE**（`finish=length`/空尾率）与能力型分开 | D10 |
| 载体落盘 | 聚合可无 traces | 跑完当场落 `state/traces/judgements`，`verify_evidence_chain.py` 必须 exit 0 | D8/D10；铁律1 |

## 4. 阳性对照卡（D11.5，必做且先于主实验）

**目的**：证明“在本环境+本载体下，删记忆确实改变行为”。不先过阳性对照，不得解释主实验的 null。

- **卡设计**（已实现原型：`l3_pilot/lab_v2_positive_control.py::make_card`）：
  - m-plan 为**两行映射**：`plan v1: resource/store-a target/v1 basis=1` 与 `plan v2: resource/store-b target/v2 basis=2`（注入后仅 v2 行有效）。
  - `stat()` 回 `{"note": "no plan; consult memory"}`；`stale_basis/wrong_target` 不回正确值；注入在 `inject_after_files=4`。
  - 提示逐字同一；两臂仅差“保留/删除 m-plan（整段计划载体）”。
- **判定**：keep_plan 期望 RECOVERED；del_plan 期望 STALE_FAILURE 或（无法触发注入/无法形成有效写）INCOMPLETE 且 verified 显著低于 keep。
- **已测读数（本地，脚本客户端+真模型）**：selftest 6/6；`workbuddy/deepseek-v4.1-flash` 8 卡 keep 8/8 REC、inj 8/8、med tok 13.6k vs del 8/8 INC、inj 0/8、verified 0、med tok 103.6k（`runs/l3-v2-positive-control/report.json`）。→ 在不可恢复环境下效应可测。
- **预注册要求**：正式主实验前，用目标模型各跑 ≥20 卡阳性对照；keep 的 REC 率与 del 的退化率需同时满足预设阈值（建议 keep REC≥0.8 且 del 的 stale_or_fail 相对 keep 上升 ≥0.5），否则标记“该模型/任务族记忆需求不足”。

## 5. 因子设计与因子表

因素固定：提示恒定、注入时机恒定（`inject_after_files` 同卡）、`max_tokens` 与续跑策略恒定、`stat`/错误语义按 §3。

| 因子 | 水平 | 说明 |
|---|---|---|
| F1 载体形态 | `S_c`（主）/ `S_a`（敏感性，可选） | S_c=历史裁剪删除计划；S_a=从检索语料移除计划且保证无泄漏 |
| F2 载体存在 | `keep` / `del` | 同一载体形态下的核心对照 |
| F3 记忆内容类型（对照健全性） | `plan` / `nonculprit`（可选） | 删非关键条目应弱于删计划条目，否则“删除”效应不特异 |
| F4 模型 | **≥1 零折损 + ≥1 方向性佐证** | 见 §4.1 的改写理由（D12.2 实测） |

### 4.1 F4 条款改写（依据 D12.2/D12.5 实测，2026-11-17 更新）

**原条款「≥2 个零折损模型」在本机通道条件下不可执行**，实测证据（`DEVIATION_L3.md` D12.2/D12.5）：

| 通道 | 实测结果 |
|---|---|
| `openrouter/minimax/minimax-m3.1-flash` | 40 卡 keep 36 REC + 4 INC、del 40/40 STALE，**transport_loss=0** → 零折损确证 |
| `moonshotai/kimi-k2-thinking`（workers=3 + 每轮 purge TL） | 40 卡 **TL=3/80（3.75%）**，keep 34 REC / del **40/40 STALE**，配对 n_eff=33、diff 100pp、**p=2.33e-10**、cost 3.76× → **第二确证**（D12.5） |
| `moonshotai/kimi-k2-thinking`（无清污高折损批） | 40 卡 transport_loss 65/80 → 该批作废，仅作教训（D12.2） |
| `workbuddy/deepseek-v4.1-flash` | 2026-11-17 04:xx 两次点火均整窗 429（80 + 68 条全废，作废）；**同日 18:39 通道恢复，workers=2 + 轮次制监督器跑完 80/80 且 transport_loss=0**（keep 39 REC / del 40 STALE、配对 n_eff=40、diff 97.5pp、p=3.64e-12、cost 3.66×）→ **第二零折损确证**（D14）。**同一模型先废后成，证明通道状态是时间窗口属性，不是模型属性** |
| `group/difficulty-four`、`kiro/glm-5` | 2026-11-16 preflight 3×200，**2026-11-17 变 404**（模型下线） |

**改写后的当前达标状态（D14 后，2026-11-17 19:20 复核）**：

| 档位 | 要求 | 已达成 |
|---|---|---|
| 主确证 | ≥1 个 transport_loss=0 的模型，独立完成 keep/del 全配对，diff≥50pp 且 p<0.05 | `minimax-m3.1-flash` TL=0，n_eff=36，100pp，p=2.91e-11，cost 3.21× |
| 第二确证（最严读法已满足） | ≥1 个第二模型 TL≤20% 且方向一致 p<0.05 | `workbuddy/deepseek-v4.1-flash` **TL=0**，n_eff=40，97.5pp，p=3.64e-12，cost 3.66×（D14） |
| 第三方向确认 | TL≤20% 且方向一致 p<0.05 | `moonshotai/kimi-k2-thinking` 低速批 TL=3.75%，n_eff=33，100pp，p=2.33e-10，cost 3.76×（D12.5） |
| 方向性佐证（降档，仅附明细） | TL≤50% 且方向一致但 p 不显著 | 当前无 |

→ **三模型全部：del 臂有效单元 stale 率 1.00（112/112 全 STALE），keep 臂 0.00–0.025；成本 3.21× / 3.66× / 3.76× 三个模型同向反转。** 因此本条不再需要降档，原「≥2 个零折损模型」的**严格版本已实际达成**（minimax + workbuddy 两个 TL=0）。
- **方向性佐证**（降档）：`transport_loss ≤ 50%` 且有效子集方向一致但 p 不显著 → 只附明细不进确证表。
- **禁止**把「通道不可用」写成「该模型记忆需求不足」——前者是通道事实，后者需阳性对照过线后才可判。

**preflight 时效性（新硬规）**：白名单只在**点火前 5 分钟内**有效；任何超过 5 分钟的白名单结论必须重探。`preflight_probe.py` 连发 3×200 才算过线。**高折损批次可救**：`purge_v2_transport_loss.py --apply` 只清 transport_loss 格子后 `--resume` 重试（D12.4/D12.5：kimi 从 65/80 烧盘救回 3/80）。

### 4.2 第五类判定 `PRE_INJECTION_COMPLETION`（D12 限制 3 落地）

D12 中 4 条 keep 臂 INCOMPLETE 里有 3 条是 `verified_count=40/40` 但 `inject_after_turn=5` 之前就写满（8 writes/turn）→ 注入未触发即收工，当前被判 INCOMPLETE。这既不是能力缺失也不是量具截断，**必须在预注册中单列**：

- 定义：`verified_count == n_files` 且 `injection is None` 且**非量具截断** → `PRE_INJECTION_COMPLETION`（截断优先于 PIC；`v2_runner_sc.py::verdict_of` 已实现，selftest 8/8）。
- 处理：不进 stale 率分母，不进完成率分子；单独报计数与比率（report `cells[*].pre_injection_completion/pic_rate`）。
- **不对称性必须声明**：该类别只可能在「完成得快」的臂出现（minimax 3 条、kimi 4 条，全在 keep），del 臂结构上不可能出现；因此把它混进 INCOMPLETE 会系统性低估快臂。
- **跨批可比性**：旧 judgements/report 仍为四分口径（保持原载体可比）；`rejudge_v2_verdicts.py` 从落盘 traces 生成并列五分复核层（`runs/l3-v2-rejudged/`）。已验证重判只把 INCOMPLETE 内部分流为 PIC，STALE/REC 计数逐条不变（minimax 40 STALE/36 REC、kimi 40 STALE/34 REC），且 PIC 全在 keep 臂。

**主分析（最小可判定）**：2（keep/del）× 1（S_c）× 1 零折损模型确证 + 1 方向性佐证模型；配对同卡同 seed，佐证模型不进配对表。

| Cell | F1 | F2 | 预期（若记忆因果成立） |
|---|---|---|---|
| C1 | S_c | keep | 高 REC、低 STALE（对齐阳性对照 keep） |
| C2 | S_c | del | STALE/失败显著高于 C1（对齐阳性对照 del） |
| C3（可选） | S_a | keep | 与 C1 同向 |
| C4（可选） | S_a | del | 与 C2 同向（敏感性：结论不依赖单一载体实现） |

**主终点**：配对 stale 率差 `p_C2 - p_C1`（同卡 McNemar/配对符号检验）及完成率（剔除量具截断型 INCOMPLETE 与 `PRE_INJECTION_COMPLETION` 后）。**次终点**：token 成本比（在有效对上，口径同 D1/D7）。

**成本方向不得预设**（D12 实测反转）：v1 里「删除记忆」的一臂因为「失败得快」而**便宜**（Run A `cost_ratio_D_over_B=1.1479`）；v2 里同一操作变成「暴力试错到 turn 耗尽」而**贵 3.21×**（minimax del 76,931 tok vs keep 21,250 tok）。因此 v2 的成本条款只报比值与 CI，**不写「删除应省成本」的先验方向**；任何成本结论必须附「该臂是成功得快还是失败得贵」的机制说明。

## 6. 样本量与停止

- 成本/效应 CI：按 graham 警告，配对有效单元 **≥420** 才能把比值 CI 稳定收进 1.10 附近判断带（D1 记录 n=40 CI 宽）。
- H3b 型阈值若沿用：有效配对与 MDE 需按 `power_l3.py` 口径重算并写入定稿（当前锚点 140/720/MDE 0.066，需对 v2 环境重估）。
- 停止：任一模型阳性对照不过（§4）→ 该模型/任务族判“记忆需求不足”，不进主实验；量具截断型 INCOMPLETE 占比 >20% → 先修量具（提 max_tokens/续跑）不解释效应。
- **通道停止（D12.2 新增）**：任一批次 `transport_loss > 20%` → 该批次判**通道失效**，作废重跑（不得把 transport_loss 计成 INCOMPLETE 进分母）；`transport_loss > 50%` → 该模型降级为方向性佐证，不得进配对表。

## 7. 不变项与禁止事项
- STALE 语义：`judge.py:48-49` stale 分支优先于完成度（保留）。
- 判定围栏 D7 与证据链闸：照用，`--verify-provenance`/`verify_evidence_chain` 全绿。
- **禁止**：在未过阳性对照时下“记忆无效”结论；把量具截断型 INCOMPLETE 计入能力型完成率；在未落 traces/judgements/state 时出报告；改冻结层 6 文件而不更新预注册与哈希。

## 8. 批准与执行顺序
1. ✅ 主载体 **S_c** 单独跑（不加 S_a）；`max_tokens=1600`（v2 runner 常量，落在编排层、不改冻结层）；第二模型按 §4.1 的新条款已选（minimax 零折损主确证 + kimi 低折损第二确证）。
2. ✅ S_c（历史裁剪算子）与 §3 环境修订在编排层实现（`v2_runner_sc.py` + `make_card`），**冻结层 6 文件未动**；v2 runner 及其工具链哈希见 §9 登记。
3. ✅ 阳性对照（≥20 卡/模型）过线（minimax keep 17/20 REC、del 20/20 STALE；workbuddy 剔 429 后 keep 13/13 REC、del 9/10 STALE）→ 主实验已跑；每批当场落盘载体并跑 `verify_evidence_chain.py`（minimax/kimi 均 exit 0）。
4. ✅ 产出：配对表 + 截断率 + PIC 计数 + 证据链校验报告（D12/D12.4/D12.5 + `l3-v2-rejudged/`）。
5. 后续（可选，需再授权）：把 v2 结论写进论文/稿件；S_a 敏感性臂；把有效配对从 36/33 扩到 420（成本/效应 CI 收窄）。

## 9. 生效时刻的代码身份（D13，哈希登记）
冻结层 6 文件（须与 `PREREG_L3.md:11-16` 逐字一致，生效时实测 6/6 MATCH）：
- `judge.py` `0e09d9e1123236ad…`、`engine.py` `46e99ba8dd9a6f82…`、`cards.py` `cea89d856b3d2c1e5000…`、`cards_agent.py` `53e7d8f92408e2d7422d…`、`agent_arm.py` `6239b5d32d578122d9b1…`、`power_l3.py` `2fe1f54210f2848ff826…`（完整 64 位见 `DEVIATION_L3.md` D7 / `formal_runner.py::FROZEN_SHA256_EXPECTED`）。

v2 编排层（可随工程迭代，登记生效时刻值以便复核）：
- `v2_runner_sc.py` 617 行 `6eacf8c273f096e7…`（五分判定版，selftest 8/8）
- `rejudge_v2_verdicts.py` 122 行 `c317f02fbf8e45f0…`（并列五分重判闸，selftest 2/2）
- `purge_v2_transport_loss.py` 102 行 `7890a26d638016c7…`、`verify_evidence_chain.py` 169 行 `85c5e884aa4d1945…`、`preflight_probe.py` 108 行 `e2d997d3f08eadc5…`、`lab_v2_positive_control.py` 485 行 `f9f6b864bc25bf23…`

> 哈希仅为「身份标记」，每次引用前用 `sha256sum` 现算比对；改了任一编排文件必须更新本表并在 `DEVIATION_L3.md` 追加一条。

## 附：本地就绪产物
- 机制/围栏：`DEVIATION_L3.md` D1–D12，`REPRODUCE_CHECKS.md`（四闸全绿 + v2 段），`verify_evidence_chain.py`（v1/v2 双口径，selftest PASS），`preflight_probe.py`（**白名单 5 分钟内有效**）。
- 阳性对照原型：`lab_v2_positive_control.py`（selftest 6/6）与 `runs/l3-v2-positive-control/`（16 traces）；`v2_runner_sc.py`（selftest 8/8）为 S_c 主实验 runner（五分判定）。
- **已有 v2 实测**：`runs/l3-v2-sc-40-minimax/`（80 条，零折损，keep 36 REC / del 40 STALE，配对 n=36 diff 100pp p=2.91e-11）、`runs/l3-v2-sc-40-kimi-lowspeed/`（80 条，TL=3/80，keep 34 REC / del 40 STALE，配对 n_eff=33 diff 100pp p=2.33e-10）、`runs/l3-v2-sc-40-kimi/`（80 条，65 transport_loss，作废仅作教训）。
- 五分重判复核层：`runs/l3-v2-rejudged/`（minimax/kimi-lowspeed 各 80 条，PIC 3/4 全在 keep，STALE/REC 与原口径逐条一致）。
- 待你侧外部动作：`l3_pilot/USER_ACTIONS.md`（仅剩 PyPI 凭据上传；trainerlab 已于 2026-11-17 建仓并 CI 绿）。
