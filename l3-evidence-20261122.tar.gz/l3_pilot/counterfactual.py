#!/usr/bin/env python3
"""Counterfactual replay for H3a.

Does not modify frozen agent_arm.py. Each unit is a real-model episode whose
stored memory is edited before the run; the ruler is always the frozen judge.

The 40-card unit set is drawn deterministically from the registered manifest.
No formal H3b run is launched here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
from pathlib import Path

import agent_arm
import cf_episode

ROOT = Path(__file__).resolve().parent


def load_manifest(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def select_units(manifest: dict, n: int, seed: int = 0) -> list[dict]:
    rng = random.Random(seed)
    return rng.sample(manifest["cards"], n)


def load_card(cards_dir: Path, entry: dict) -> dict:
    path = cards_dir / entry["file"]
    card = json.loads(path.read_text(encoding="utf-8"))
    if hashlib.sha256(
        json.dumps(
            {key: value for key, value in card.items() if key != "card_sha256"},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest() != entry["sha256"]:
        raise ValueError(f"card hash mismatch: {entry['card_id']}")
    return card


def edited_card(card: dict, remove_id: str) -> dict:
    edited = json.loads(json.dumps(card))
    edited["memory"] = [entry for entry in card["memory"] if entry["id"] != remove_id]
    edited["card_id"] = f"{card['card_id']}-rm-{remove_id}"
    return edited


def run_unit(client, card: dict, removal_id: str, replay: int, max_turns: int) -> dict:
    condition = "culprit" if removal_id == "m-plan" else "random"
    return cf_episode.run_cf_episode(client, card, condition, removal_id, replay, max_turns)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="+", required=True)
    parser.add_argument("--cards-manifest", type=Path, default=ROOT / "runs" / "l3-registered-cards" / "manifest.json")
    parser.add_argument("--n-units", type=int, default=40)
    parser.add_argument("--selection-seed", type=int, default=0)
    parser.add_argument("--out", type=Path, default=ROOT / "runs" / "l3-counterfactual-smoke")
    parser.add_argument("--base-url", default=agent_arm.DEFAULT_BASE)
    parser.add_argument("--max-calls-per-episode", type=int, default=40)
    parser.add_argument("--max-turns", type=int, default=20)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()

    manifest = load_manifest(args.cards_manifest)
    cards_dir = args.cards_manifest.resolve().parent
    units = select_units(manifest, min(args.n_units, manifest["n_cards"]), args.selection_seed)
    if args.smoke:
        units = units[:1]
    out = args.out.resolve()
    traces_dir = out / "traces"
    judgements_dir = out / "judgements"
    traces_dir.mkdir(parents=True, exist_ok=True)
    judgements_dir.mkdir(parents=True, exist_ok=True)

    records = []
    for model in args.models:
        for unit in units:
            card = load_card(cards_dir, unit)
            conditions = [
                ("culprit", "m-plan"),
                ("random", "m-quota"),
                ("random", "m-format"),
            ]
            for condition, remove_id in conditions:
                for replay in range(2):
                    edited = edited_card(card, remove_id)
                    client = agent_arm.Client(args.base_url, model, args.max_calls_per_episode)
                    result = run_unit(client, edited, remove_id, replay, args.max_turns)
                    slug = f"{model.replace('/', '_')}__{unit['card_id']}__{condition}__{remove_id}__r{replay}"
                    trace_path = traces_dir / f"{slug}.json"
                    trace_path.write_text(
                        json.dumps(result["trace"], ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
                    )
                    judgement_path = judgements_dir / f"{slug}.json"
                    judgement = {key: value for key, value in result.items() if key != "trace"}
                    judgement["model"] = model
                    judgement["condition"] = condition
                    judgement["removed_memory_id"] = remove_id
                    judgement_path.write_text(
                        json.dumps(judgement, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
                    )
                    records.append(judgement)
                    print(
                        f"{slug}: {result['verdict']} calls={result['usage']['calls']}",
                        flush=True,
                    )

    report = {
        "schema": "l3-counterfactual-report/v1",
        "status": "PILOT_OR_SMOKE_ONLY",
        "source": "real_model",
        "base_url": args.base_url,
        "models": args.models,
        "n_units": len(units),
        "n_records": len(records),
        "smoke": args.smoke,
        "what_this_measures": (
            "whether removing the culprit plan changes the staleness verdict versus "
            "removing a random memory entry, under matched cards and seeds"
        ),
        "what_this_does_not_measure": (
            "no H3b claim; no attribution consistency model has been fit; "
            "this is the replay harness, not a formal run"
        ),
        "records": records,
    }
    report_path = out / "report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {len(records)} records -> {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
