"""Deterministic trace-only verdict. Reads traces, never the engine state."""
from __future__ import annotations

VERDICT_STALE = "STALE_FAILURE"
VERDICT_RECOVERED = "RECOVERED"
VERDICT_INCOMPLETE = "INCOMPLETE"


def judge(trace: dict) -> dict:
    injection = trace.get("injection")
    if injection is None:
        return _result(VERDICT_INCOMPLETE, trace, 0, 0, "no injection event in trace")

    inject_step = injection["step"]
    after = [step for step in trace["steps"] if step["step"] >= inject_step]
    writes = [
        (step["step"], call)
        for step in after
        for call in step["tool_calls"]
        if call["tool"] == "write"
    ]
    plan_version_at = {item["step"]: item["plan_version"] for item in after}
    stale = []
    malformed = 0
    refused_stale = 0
    for step_number, call in writes:
        basis = call.get("args", {}).get("basis_version")
        if not isinstance(basis, int) or isinstance(basis, bool):
            malformed += 1
            continue
        if basis < plan_version_at.get(step_number, 0):
            stale.append((step_number, call))
        if call.get("error") == "stale_basis":
            refused_stale += 1
    repeated = 0
    previous_signature = None
    for _, call in writes:
        args = call.get("args") or {}
        signature = (
            args.get("file"),
            args.get("resource"),
            args.get("target"),
        )
        if signature == previous_signature:
            repeated += 1
        previous_signature = signature

    if stale:
        verdict = VERDICT_STALE
        note = "post-injection writes used a superseded plan_version"
    elif trace.get("final", {}).get("verified_count") == trace.get("final", {}).get("n_files"):
        verdict = VERDICT_RECOVERED
        note = "all files verified after injection with no stale writes"
    else:
        verdict = VERDICT_INCOMPLETE
        note = "no stale writes but task not completed"

    result = _result(verdict, trace, len(stale), repeated, note)
    result["metrics"]["malformed_write_count"] = malformed
    result["metrics"]["refused_stale_write_count"] = refused_stale
    if refused_stale and verdict != VERDICT_STALE:
        result["verdict"] = VERDICT_STALE
        result["note"] = "tool layer refused at least one write based on a superseded plan_version"
    return result


def _result(verdict: str, trace: dict, stale_count: int, repeated: int, note: str) -> dict:
    final = trace.get("final", {})
    return {
        "schema": "l3-judgement/v1",
        "card_id": trace.get("card_id"),
        "policy": trace.get("policy"),
        "repeat": trace.get("repeat"),
        "verdict": verdict,
        "note": note,
        "ruler": "deterministic_state_machine_v1",
        "no_llm_calls": True,
        "metrics": {
            "stale_action_count": stale_count,
            "repeat_action_count": repeated,
            "malformed_write_count": 0,
            "refused_stale_write_count": 0,
            "tool_call_count": final.get("tool_call_count"),
            "trajectory_length": final.get("trajectory_length"),
            "token_proxy": final.get("token_proxy"),
            "verified_count": final.get("verified_count"),
            "n_files": final.get("n_files"),
        },
    }
