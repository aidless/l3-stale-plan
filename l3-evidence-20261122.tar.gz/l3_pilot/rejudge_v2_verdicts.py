#!/usr/bin/env python3
"""用第五类判定重判已落盘的 v2 traces，产出独立复核层（不改原 judgements/report，保持跨批可比）。

铁律 1：所有数字从落盘 traces 重算；原 report 仍是四分口径，本文件是并列复核层。
D13：验证 PIC 只在 keep 臂、STALE/REC 计数与旧口径逐条一致。
"""
import argparse
import collections
import glob
import hashlib
import json
import pathlib

import v2_runner_sc as v2


def rejudge_run(run_dir: pathlib.Path) -> dict:
    traces = sorted(glob.glob(str(run_dir / "traces" / "*.json")))
    rows = []
    old = collections.Counter()
    new = collections.Counter()
    arm_new = collections.Counter()
    mismatch = collections.Counter()
    missing_judge = []
    for tf in traces:
        t = json.load(open(tf, encoding="utf-8"))
        slug = t["slug"]
        jp = run_dir / "judgements" / (slug + ".json")
        if not jp.exists():
            missing_judge.append(slug)
            continue
        j = json.load(open(jp, encoding="utf-8"))
        nv = v2.verdict_of(t)
        ov = j["verdict"]
        old[ov] += 1
        new[nv] += 1
        arm_new[(j["arm"], nv)] += 1
        if nv != ov:
            mismatch[(ov, nv)] += 1
        rows.append({"slug": slug, "arm": j["arm"], "old": ov, "new": nv,
                     "transport_loss": j.get("transport_loss", False)})
    return {
        "schema": "l3-v2-rejudged/v1",
        "run_dir": str(run_dir),
        "traces": len(traces),
        "judged": len(rows),
        "missing_judge": missing_judge,
        "old_dist": dict(old),
        "new_dist": dict(new),
        "arm_new_dist": {f"{a}|{k}": c for (a, k), c in sorted(arm_new.items())},
        "mismatch": {f"{o}->{n}": c for (o, n), c in sorted(mismatch.items())},
        "rows": rows,
    }


def selftest() -> None:
    import tempfile, shutil
    root = pathlib.Path(__file__).resolve().parent
    src = root / "runs" / "l3-v2-sc-40-kimi-lowspeed"
    with tempfile.TemporaryDirectory() as td:
        d = pathlib.Path(td) / "run"
        (d / "traces").mkdir(parents=True)
        (d / "judgements").mkdir(parents=True)
        # GREEN 夹具：PIC + STALE 各一条，重判后 PIC 单列、STALE 不变
        t_pic = {"slug": "s_pic", "arm": "keep", "steps": [], "injection": None,
                 "final": {"empty_tail": False, "last_finish": "tool_calls",
                           "verified_count": 40, "n_files": 40}}
        t_stale = {"slug": "s_stale", "arm": "del", "steps": [{"step": 0, "plan_version": 2,
                    "tool_calls": [{"tool": "write", "args": {"basis_version": 1}}]}],
                   "injection": {"step": 0},
                   "final": {"empty_tail": False, "last_finish": "tool_calls",
                             "verified_count": 0, "n_files": 40}}
        for t, ov in ((t_pic, "INCOMPLETE"), (t_stale, "STALE_FAILURE")):
            (d / "traces" / (t["slug"] + ".json")).write_text(json.dumps(t), encoding="utf-8")
            (d / "judgements" / (t["slug"] + ".json")).write_text(
                json.dumps({"verdict": ov, "arm": t["arm"], "transport_loss": False}), encoding="utf-8")
        r = rejudge_run(d)
        assert r["new_dist"].get("PRE_INJECTION_COMPLETION") == 1, r["new_dist"]
        assert r["new_dist"].get("STALE_FAILURE") == 1, r["new_dist"]
        assert r["arm_new_dist"].get("del|STALE_FAILURE") == 1, r["arm_new_dist"]
        assert r["mismatch"].get("INCOMPLETE->PRE_INJECTION_COMPLETION") == 1, r["mismatch"]
        print("[PASS] GREEN 夹具 PIC 单列 + STALE 不变 + 臂归属正确")
        # RED 夹具：把 PIC 的 verified_count 改小 → 必须判 INCOMPLETE，不得误判 PIC
        t_pic["final"]["verified_count"] = 39
        (d / "traces" / "s_pic.json").write_text(json.dumps(t_pic), encoding="utf-8")
        r2 = rejudge_run(d)
        assert r2["new_dist"].get("PRE_INJECTION_COMPLETION", 0) == 0, r2["new_dist"]
        assert r2["new_dist"].get("INCOMPLETE", 0) == 1, r2["new_dist"]
        print("[PASS] RED 假阳守卫 verified<n_files 不判 PIC")
    print("SELFTEST PASS (2/2)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--runs", nargs="+", default=["l3-v2-sc-40-minimax", "l3-v2-sc-40-kimi-lowspeed"])
    ap.add_argument("--out", default="runs/l3-v2-rejudged")
    a = ap.parse_args()
    if a.selftest:
        selftest()
        return 0
    root = pathlib.Path(__file__).resolve().parent
    out = root / a.out
    out.mkdir(parents=True, exist_ok=True)
    all_rows = {}
    for run in a.runs:
        rd = root / "runs" / run
        res = rejudge_run(rd)
        # D13 断言：STALE/REC 计数与旧口径一致（新判定只动 INCOMPLETE 内部分流）
        assert res["old_dist"].get("STALE_FAILURE", 0) == res["new_dist"].get("STALE_FAILURE", 0), run
        assert res["old_dist"].get("RECOVERED", 0) == res["new_dist"].get("RECOVERED", 0), run
        # 断言：PIC 只在 keep 臂（§4.2 不对称性预言）
        pic_arms = {k.split("|")[0] for k in res["arm_new_dist"] if k.endswith("|PRE_INJECTION_COMPLETION")}
        assert pic_arms <= {"keep"}, (run, pic_arms)
        (out / (run + ".json")).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
        all_rows[run] = {k: res[k] for k in ("judged", "old_dist", "new_dist", "mismatch", "arm_new_dist")}
    print(json.dumps(all_rows, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
