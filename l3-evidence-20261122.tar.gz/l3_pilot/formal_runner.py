#!/usr/bin/env python3
"""L3 正式运行器：带 checkpoint/resume，实现 H3b 所需的 B/D/R 三条件对照。

背景 / 为什么重写（接手时发现的两个静默缺陷）：
  1) 旧版 formal_runner.py 的非 smoke 路径只是 `print("smoke was disabled")` 然后退出，
     根本无法跑正式 sweep —— 所谓"正式运行器"只实现了单卡 smoke。
  2) H3b 的核心对照是 B（保留完整旧计划）vs D（删除归因条目 m-plan）。
     旧版只会"删除"（culprit/random），根本没有 B（保留）这一臂，
     因此 H3b 在旧版下永远测不出来。

本文件属于**未冻结**的编排层（PREREG 冻结集只含
judge.py / engine.py / cards.py / cards_agent.py / agent_arm.py / power_l3.py），
因此重写它不改变预注册判定口径。卡片哈希仍逐张校验，任何改动即报错。

接手时发现的缺陷清单（均已在本版修复并有自测/试点数据佐证）：
  缺陷1: 旧版非 smoke 路径只是 print("smoke was disabled") 后退出 —— 正式 sweep 根本没实现。
  缺陷2: 旧版只会"删除"（culprit/random），没有 B（保留）臂 —— H3b 永远测不出来。
  缺陷3: cf_episode.py 的提示写死 nudge_recheck=True（reactive）—— 对所有条件一视同仁。
  缺陷4: 【关键】用 cf_episode 跑 B 臂时，恒定 reactive 提示把"跟随失效计划"的压力
         完全抹掉了：实测 3 卡 B 条件 stale_rate=0.0（runs/l3-formal-v2-smoke），
         若照此跑正式数据，B 基线失效率 < 0.20 直接触发 PREREG Kill 条件 3。
         而试点（runs/l3-agent-final，冻结 agent_arm 分条件提示）给出：
         policy=stale → 5/5 STALE_FAILURE；policy=memory_delete → 0/5 STALE。
         两个 harness 的结论方向完全相反 —— 所以条件路由必须用冻结提示。

三条件与 harness 的最终绑定（PREREG §4 "注入提示固定为 agent_arm.py 冻结版的分条件提示"）：
  B  = agent_arm.run_episode(card,          "stale")         保留旧计划 + "stored plan is authority"
  D  = agent_arm.run_episode(card,          "memory_delete") 删除归因条目 m-plan + reactive 提示
  R  = agent_arm.run_episode(card−m-quota,  "reactive")      预编辑卡片移除随机条目 + reactive 提示
  R2 = agent_arm.run_episode(card−m-format, "reactive")      第二随机对照
  说明：R 不用 "memory_delete" 标签（那会硬删 m-plan，见交接 Q2），而是预先编辑卡片
  后用 "reactive" —— 冻结版 run_episode 原样复用，提示逐字一致，只差被移除的那一条。
  这样 D 与 R 的 harness 完全对齐，H3a 的"归因 vs 随机"对照才干净。
  cf_episode.py 降级为可选对照 harness（--random-harness cf_episode），仅用于 harness
  敏感性检查，不进正式判定。

用法：
  # 自测（RED→GREEN，不联网）
  python3 formal_runner.py --selftest

  # 极小真实 smoke（3 卡 × B/D/R × 1 repeat，单模型）
  python3 formal_runner.py --models opencode-go/deepseek-v4.1-flash \
      --n-units 3 --repeats 1 --conditions B D R --out runs/l3-formal-v2-smoke

  # 断点续跑
  python3 formal_runner.py ... --resume

  # 正式（示例：2 模型 × 240 卡 × 3 seed × B/D）
  python3 formal_runner.py --models M1 M2 --n-units 240 --repeats 3 \
      --conditions B D --out runs/l3-formal-v2
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import agent_arm
import cf_episode
from judge import judge

ROOT = Path(__file__).resolve().parent
DEFAULT_MANIFEST = ROOT / "runs" / "l3-registered-cards" / "manifest.json"
DEFAULT_BASE_URL = os.environ.get("MAGPIE_BASE", "http://127.0.0.1:3425/v1")

PERSISTENCE_FILE = "formal_state_v2.json"

# 条件 -> (要移除的 memory id, 冻结版 agent_arm policy)；None 表示保留全部 = B 基线
CONDITION_REMOVE = {
    "B": None,          # 保留完整旧计划
    "D": "m-plan",      # 删除归因条目（culprit）
    "R": "m-quota",     # 随机移除对照（非 culprit）
    "R2": "m-format",   # 第二个随机对照
}
# 各条件在冻结 agent_arm 里对应的 policy（提示随 policy 走，逐字来自冻结版）
CONDITION_POLICY = {
    "B": "stale",          # stat_visible=False："stored plan is the default authority"
    "D": "memory_delete",  # reactive 提示 + 冻结版硬删 m-plan
    "R": "reactive",       # reactive 提示，memory 由预编辑卡片决定（不含被移除条目）
    "R2": "reactive",
}

# ----------------------------------------------------------------------------
# 判定口径围栏（provenance + 统计口径金标）
# ----------------------------------------------------------------------------
# 为什么要有这一段：selftest 此前只测"条件编辑对不对"，**从来没有钉住统计口径**。
# 把 cost_ratio 的公式改成任何常数，`--selftest` 依旧 PASS、exit=0
# （Linus 视角评审实测的 RED：`formal_runner.py:304` 改成 `statistics.median([1.0])`
# 仍然全绿）。也就是说这个判定口径可以被静默改掉而门不响 —— 违反 AGENTS.md 第 8 条
# "门必须能失败"。下面三样东西把口径钉死：
#   1) FROZEN_SHA256_EXPECTED：逐字复制 PREREG_L3.md §1 的完整哈希（非本文件自算）。
#   2) STATISTIC_SPEC：把 cost_ratio / stale_rate / loss_rate 的定义写成常量。
#   3) selftest 里的金标断言：用合成记录算出确定值，改公式必红。
FROZEN_FILES = ("judge.py", "engine.py", "cards.py", "cards_agent.py", "agent_arm.py", "power_l3.py")

# 逐字来自 PREREG_L3.md §1（封存 2026-11-09）。不得由本文件现算后回填。
FROZEN_SHA256_EXPECTED = {
    "judge.py": "0e09d9e1123236ad82bdfef7e80e83e48564fcf350715398b0c4daa4fb27264d",
    "engine.py": "46e99ba8dd9a6f82d84e68c8c0d59152d723b9a99498031d7cc2ac131054ee1f",
    "cards.py": "cea89d856b3d2c1e5000998c31173a38e2262d0b90c61eb95ea4e06c6d310f71",
    "cards_agent.py": "53e7d8f92408e2d7422d08928c33391ac836cfd4a5b2ee2b64c8e0a5a946cf54",
    "agent_arm.py": "6239b5d32d578122d9b111b74582a1b10713162515658e21aa79b5133ac3b2a1",
    "power_l3.py": "2fe1f54210f2848ff8265a9d14489c35f8c65e9262b30d6b67bf651b5d083cef",
}

# 统计口径：定义写在数据里，selftest 按这行判金标。改口径 = 改这里 = 必须写 DEVIATION。
STATISTIC_SPEC = {
    "cost_ratio_D_over_B": "mean_total_tokens(D, 配对有效单元) / mean_total_tokens(B, 配对有效单元)",
    "cost_threshold": 1.10,
    "stale_rate": "STALE_FAILURE / n（分母含 INCOMPLETE，按 PREREG 原文）",
    "loss_rate": "INCOMPLETE / n_records",
    "pair_unit": "(model, card_id, repeat)，B 与 D 双方都 effective 才成对",
    "effective": ["RECOVERED", "STALE_FAILURE"],
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def provenance_block(root: Path | None = None) -> dict:
    """冻结层身份 + 编排层身份 + 条件编辑规格。**两个 runner 共用本函数**。

    任何一次正式运行的 report 都必须带这一段，否则无法判"这份数据是不是冻结版跑的"。
    `root` 只给自测用（把文件复制到临时目录再篡改），生产调用不传。
    """
    base = Path(root) if root is not None else ROOT
    frozen = {}
    ok = True
    for name in FROZEN_FILES:
        path = base / name
        actual = sha256_file(path) if path.exists() else None
        expected = FROZEN_SHA256_EXPECTED[name]
        match = (actual == expected)
        ok = ok and match
        frozen[name] = {"sha256": actual, "expected": expected, "match": match}

    runners = {}
    for name in ("formal_runner.py", "formal_runner_mt.py", "factorial_3x2.py"):
        path = base / name
        if path.exists():
            runners[name] = {"sha256": sha256_file(path), "lines": len(path.read_text(encoding="utf-8").splitlines())}

    return {
        "frozen_ok": ok,
        "frozen": frozen,
        "runners": runners,
        "condition_remove": dict(CONDITION_REMOVE),
        "condition_policy": dict(CONDITION_POLICY),
        "statistic_spec": STATISTIC_SPEC,
    }


# ----------------------------------------------------------------------------
# 卡片装载与哈希校验
# ----------------------------------------------------------------------------
def canonical(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def load_manifest(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def card_sha256(card: dict) -> str:
    """卡片自哈希：排除 card_sha256 字段本身。"""
    body = {k: v for k, v in card.items() if k != "card_sha256"}
    return hashlib.sha256(canonical(body).encode("utf-8")).hexdigest()


def load_card(cards_dir: Path, entry: dict) -> dict:
    """读取单张卡并按 manifest 记录的 sha256 校验；不一致即抛错（RED 守卫）。"""
    path = cards_dir / entry["file"]
    card = json.loads(path.read_text(encoding="utf-8"))
    actual = card_sha256(card)
    if actual != entry["sha256"]:
        raise ValueError(
            f"card hash mismatch: {entry['card_id']}  manifest={entry['sha256'][:16]} actual={actual[:16]}"
        )
    return card


# ----------------------------------------------------------------------------
# 条件构造：B 保留 / D 删 m-plan / R 删随机条目
# ----------------------------------------------------------------------------
def build_condition_card(card: dict, condition: str) -> tuple[dict, str | None]:
    """按条件返回 (用于喂模型的卡片副本, 被移除的 memory id 或 None)。"""
    if condition not in CONDITION_REMOVE:
        raise ValueError(f"unknown condition: {condition}")
    removed_id = CONDITION_REMOVE[condition]
    edited = json.loads(json.dumps(card))  # 深拷贝，绝不改动原卡
    if removed_id is None:
        return edited, None
    ids = [m["id"] for m in edited["memory"]]
    if removed_id not in ids:
        raise ValueError(f"condition {condition}: memory id {removed_id} 不在卡片 {card['card_id']} 中: {ids}")
    edited["memory"] = [m for m in edited["memory"] if m["id"] != removed_id]
    return edited, removed_id


def slug_for(model: str, card_id: str, condition: str, removed_id: str | None, repeat: int) -> str:
    rid = removed_id or "keep"
    return f"{model.replace('/', '_')}__{card_id}__{condition}__rid-{rid}__r{repeat}"


# ----------------------------------------------------------------------------
# 单 episode：按条件路由到冻结 agent_arm（B/D/R）或 cf_episode（可选对照）
# ----------------------------------------------------------------------------
def run_one(client, card: dict, condition: str, repeat: int, max_turns: int, random_harness: str = "agent_arm") -> dict:
    if condition not in CONDITION_POLICY:
        raise ValueError(f"unknown condition: {condition}")
    policy = CONDITION_POLICY[condition]

    if condition in ("B", "D") or random_harness == "agent_arm":
        # B/D/R/R2 全走冻结 agent_arm.run_episode：
        #   B  -> policy=stale          （card 原样，保留 m-plan）
        #   D  -> policy=memory_delete  （冻结版自动从提示里去掉 m-plan）
        #   R/R2 -> policy=reactive + 预编辑卡片（移除 m-quota / m-format）
        edited, removed_id = build_condition_card(card, condition)
        trace = agent_arm.run_episode(client, edited, policy, repeat, max_turns)
        verdict = judge(trace)
        return {
            "card_id": card["card_id"],
            "condition": condition,
            "policy": policy,
            "removed_memory_id": removed_id,
            "replay": repeat,
            "verdict": verdict["verdict"],
            "metrics": verdict["metrics"],
            "usage": trace["usage"],
            "budget_exhausted": trace["budget_exhausted"],
            "errors": trace["errors"],
            "injection": trace["injection"],
            "trace": trace,
        }

    # 可选对照 harness：cf_episode（提示为独立副本，恒定 reactive）。
    # 仅用于 harness 敏感性检查，不进正式判定（见文件头缺陷4）。
    edited, removed_id = build_condition_card(card, condition)
    result = cf_episode.run_cf_episode(client, edited, condition, removed_id, repeat, max_turns)
    result["condition"] = condition
    result["removed_memory_id"] = removed_id
    return result


# ----------------------------------------------------------------------------
# 状态持久化（checkpoint / resume）
# ----------------------------------------------------------------------------
def save_state(out: Path, state: dict) -> None:
    p = out / PERSISTENCE_FILE
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(p)  # 原子替换，避免半截文件


def load_state(out: Path) -> dict | None:
    p = out / PERSISTENCE_FILE
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


def purge_burned_incomplete(state: dict) -> int:
    """resume 时清除"传输层烧掉"的 INCOMPLETE 记录（episode_exception）。

    为什么：隧道/网关瞬断期间跑出的 episode_exception INCOMPLETE 已被 checkpoint
    标记为 done，--resume 会永远跳过它们 —— 数据白白损失。episode 幂等
    （卡片从头重喂、无服务端状态），重跑无副作用。
    注意：只清带 episode_exception 的；模型自身原因的 INCOMPLETE（errors 为空或
    其他标签）不动 —— 那是真实观测，不能靠重跑"洗白"。
    返回清除条数。
    """
    burned = [r for r in state.get("records", [])
              if r.get("verdict") == "INCOMPLETE"
              and any("episode_exception" in str(x) for x in r.get("errors", []))]
    if not burned:
        return 0
    burned_slugs = {r["slug"] for r in burned}
    state["records"] = [r for r in state.get("records", []) if r["slug"] not in burned_slugs]
    state["done_slugs"] = [s for s in state.get("done_slugs", []) if s not in burned_slugs]
    return len(burned)


# ----------------------------------------------------------------------------
# 统计：按 (model, condition) 汇总 + H3b 的 B/D 配对 McNemar
# ----------------------------------------------------------------------------
def is_stale(verdict: str) -> bool:
    return verdict == "STALE_FAILURE"


def is_effective(verdict: str) -> bool:
    """有效单元 = RECOVERED 或 STALE_FAILURE；INCOMPLETE 计入折损，不参与配对。"""
    return verdict in ("RECOVERED", "STALE_FAILURE")


def exact_binom_two_sided(b: int, c: int) -> float:
    """McNemar 精确二项双侧 p 值：discordant 对 (b, c) ~ Binom(b+c, 0.5)。"""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    # P(X <= k) 的双尾 = 2 * P(X <= k)，封顶 1
    tail = sum(math.comb(n, i) for i in range(0, k + 1)) / (2 ** n)
    return min(1.0, 2 * tail)


def summarize(records: list[dict]) -> dict:
    """records: 每条含 model/card_id/condition/removed_memory_id/repeat/verdict/usage。"""
    # 1) 每 (model, condition) 的 verdict 分布与 token 均值
    per_cond: dict[str, dict[str, dict]] = {}
    for r in records:
        key = r["model"]
        per_cond.setdefault(key, {}).setdefault(
            r["condition"], {"RECOVERED": 0, "STALE_FAILURE": 0, "INCOMPLETE": 0, "_tok": 0, "_n": 0}
        )
        slot = per_cond[key][r["condition"]]
        slot[r["verdict"]] = slot.get(r["verdict"], 0) + 1
        tok = (r["usage"].get("prompt_tokens", 0) + r["usage"].get("completion_tokens", 0))
        slot["_tok"] += tok
        slot["_n"] += 1

    cond_table = {}
    for model, conds in per_cond.items():
        cond_table[model] = {}
        for cond, s in conds.items():
            n = s["_n"]
            cond_table[model][cond] = {
                "n": n,
                "recovered": s.get("RECOVERED", 0),
                "stale_failure": s.get("STALE_FAILURE", 0),
                "incomplete": s.get("INCOMPLETE", 0),
                "stale_rate": round(s.get("STALE_FAILURE", 0) / n, 4) if n else None,
                "mean_tokens": round(s["_tok"] / n, 1) if n else None,
            }

    # 2) H3b 配对：(model, card, repeat) 同时有 B 与 D 且都 effective
    pairs: dict[tuple, dict] = {}
    for r in records:
        if r["condition"] not in ("B", "D"):
            continue
        if not is_effective(r["verdict"]):
            continue
        key = (r["model"], r["card_id"], r["repeat"])
        pairs.setdefault(key, {})[r["condition"]] = r

    h3b = {}
    for model in per_cond:
        improved = worsened = both_stale = both_ok = 0  # B=stale 为"坏"，D 相对改善
        tok_b = tok_d = 0
        nb = nd = 0
        for (m, cid, rep), d in pairs.items():
            if m != model or "B" not in d or "D" not in d:
                continue
            vb, vd = d["B"]["verdict"], d["D"]["verdict"]
            if is_stale(vb) and not is_stale(vd):
                improved += 1
            elif not is_stale(vb) and is_stale(vd):
                worsened += 1
            elif is_stale(vb) and is_stale(vd):
                both_stale += 1
            else:
                both_ok += 1
            tok_b += d["B"]["usage"].get("prompt_tokens", 0) + d["B"]["usage"].get("completion_tokens", 0)
            tok_d += d["D"]["usage"].get("prompt_tokens", 0) + d["D"]["usage"].get("completion_tokens", 0)
            nb += 1
            nd += 1
        n_pairs = improved + worsened + both_stale + both_ok
        p_b = (both_stale + improved) / n_pairs if n_pairs else None  # B 失效率
        p_d = (both_stale + worsened) / n_pairs if n_pairs else None  # D 失效率
        cost_ratio = (tok_d / nd) / (tok_b / nb) if nb and nd and tok_b else None

        def files_of(cond: str) -> int:
            return sum(
                (d[cond]["metrics"].get("verified_count") or 0)
                for (m, _cid, _rep), d in pairs.items()
                if m == model and cond in d
            )

        files_b, files_d = files_of("B"), files_of("D")
        cost_ratio_per_file = (
            round((tok_d / files_d) / (tok_b / files_b), 4) if files_b and files_d and tok_b else None
        )

        h3b[model] = {
            "valid_pairs": n_pairs,
            "B_stale_rate": round(p_b, 4) if p_b is not None else None,
            "D_stale_rate": round(p_d, 4) if p_d is not None else None,
            "diff_pp": round((p_b - p_d) * 100, 2) if (p_b is not None and p_d is not None) else None,
            "discordant_improved": improved,
            "discordant_worsened": worsened,
            "mcnemar_exact_p": round(exact_binom_two_sided(improved, worsened), 4),
            "cost_ratio_D_over_B": round(cost_ratio, 4) if cost_ratio else None,
            "cost_ok_le_1_10": (cost_ratio is not None and cost_ratio <= 1.10),
            # 并列口径（**不替代主口径**）：按交付文件数归一。
            # 为什么要并列：D 明显更少 INCOMPLETE 且 verified 更多，纯 token 均值
            # 会把"干完了活"算成"更贵"。此列只作解释性副指标，PREREG §2 判定仍用
            # cost_ratio_D_over_B。
            "cost_ratio_per_file": cost_ratio_per_file,
        }

    # 3) 折损率
    total = len(records)
    incomplete = sum(1 for r in records if r["verdict"] == "INCOMPLETE")
    return {
        "cond_table": cond_table,
        "h3b_paired": h3b,
        "n_records": total,
        "incomplete": incomplete,
        "loss_rate": round(incomplete / total, 4) if total else None,
        "note": "样本未达预注册有效单元(>=140)时，以上仅作筛选性观察，不作确证性判定",
        "statistic_spec": STATISTIC_SPEC,
    }


# ----------------------------------------------------------------------------
# 自测：RED（坏卡必报错）→ GREEN（好卡必过、条件编辑正确）
# ----------------------------------------------------------------------------
def selftest() -> int:
    print("=== SELFTEST START ===")
    ok = True
    cards_dir = DEFAULT_MANIFEST.resolve().parent
    manifest = load_manifest(DEFAULT_MANIFEST)
    entry = manifest["cards"][0]
    card = load_card(cards_dir, entry)
    print(f"[GREEN] 好卡加载通过: {card['card_id']} sha={entry['sha256'][:16]}")

    # RED: 篡改 card 内容，必须抛 ValueError
    tampered = json.loads(json.dumps(card))
    tampered["n_steps"] = tampered["n_steps"] + 1
    bad_entry = dict(entry)
    try:
        # 用真实 load_card 读文件，但把 manifest sha 改成篡改后的期望不符 → 应当报错
        # 更直接：把篡改卡写到临时文件再按原 sha 校验
        import tempfile
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, dir=str(cards_dir)) as f:
            json.dump(tampered, f, ensure_ascii=False)
            tmpname = Path(f.name).name
        try:
            load_card(cards_dir, {"card_id": entry["card_id"], "file": tmpname, "sha256": entry["sha256"]})
            print("[RED-FAIL] 篡改卡竟然通过校验 —— 守卫失效！")
            ok = False
        except ValueError as e:
            print(f"[RED-PASS] 篡改卡被正确拒绝: {str(e)[:60]}")
        finally:
            (cards_dir / tmpname).unlink(missing_ok=True)
    except Exception as e:
        print(f"[RED-ERROR] 自测异常: {e}")
        ok = False

    # 条件编辑正确性
    b_card, b_rid = build_condition_card(card, "B")
    assert b_rid is None and [m["id"] for m in b_card["memory"]] == ["m-plan", "m-quota", "m-format"], "B 条件错误"
    print("[GREEN] B 条件：保留全部 memory =", [m["id"] for m in b_card["memory"]])

    d_card, d_rid = build_condition_card(card, "D")
    assert d_rid == "m-plan" and [m["id"] for m in d_card["memory"]] == ["m-quota", "m-format"], "D 条件错误"
    print("[GREEN] D 条件：移除 m-plan →", [m["id"] for m in d_card["memory"]])

    r_card, r_rid = build_condition_card(card, "R")
    assert r_rid == "m-quota" and "m-quota" not in [m["id"] for m in r_card["memory"]], "R 条件错误"
    print("[GREEN] R 条件：移除 m-quota →", [m["id"] for m in r_card["memory"]])

    # 原卡未被改动
    assert [m["id"] for m in card["memory"]] == ["m-plan", "m-quota", "m-format"], "build_condition_card 污染了原卡"
    print("[GREEN] 原卡未被条件构造污染（深拷贝生效）")

    # 条件路由正确性（缺陷4 防回归）：B/D/R 必须绑到冻结 agent_arm 的正确 policy
    assert CONDITION_POLICY["B"] == "stale", "B 必须绑 stale（否则 B 基线失效率≈0，Kill 条件3）"
    assert CONDITION_POLICY["D"] == "memory_delete", "D 必须绑 memory_delete"
    assert CONDITION_POLICY["R"] == "reactive" and CONDITION_POLICY["R2"] == "reactive", "随机对照必须绑 reactive"
    assert CONDITION_REMOVE["R"] == "m-quota" and CONDITION_REMOVE["R2"] == "m-format", "随机对照移除的必须是条目而非 m-plan"
    print("[GREEN] 条件->policy 路由：B=stale D=memory_delete R/R2=reactive（缺陷4 防回归）")

    # McNemar 精确二项抽查：b=0,c=0 -> p=1；b=6,c=0 -> p=0.03125
    assert abs(exact_binom_two_sided(0, 0) - 1.0) < 1e-9, "mcnemar 0,0 错误"
    assert abs(exact_binom_two_sided(6, 0) - 0.03125) < 1e-9, f"mcnemar 6,0 错误: {exact_binom_two_sided(6,0)}"
    print("[GREEN] McNemar 精确二项抽查通过 (0,0)->1.0 (6,0)->0.03125")

    # resume-purge 双向断言：burned INCOMPLETE 必须被清（欠清=数据烧掉白跳过），
    # 而无 episode_exception 的 INCOMPLETE（真实模型失败）必须保留（过清=洗白数据）
    st = {"done_slugs": ["a", "b", "c"], "records": [
        {"slug": "a", "verdict": "RECOVERED", "errors": []},
        {"slug": "b", "verdict": "INCOMPLETE", "errors": ["episode_exception:ConnectionError:tunnel down"]},
        {"slug": "c", "verdict": "INCOMPLETE", "errors": []},
    ]}
    n = purge_burned_incomplete(st)
    assert n == 1, f"purge 应清 1 条（b），实清 {n}"
    assert st["done_slugs"] == ["a", "c"], f"done_slugs 应剩 a,c，实为 {st['done_slugs']}"
    assert [r["slug"] for r in st["records"]] == ["a", "c"], "records 应剩 a,c（c 是真实 INCOMPLETE，不得清除）"
    assert purge_burned_incomplete({"done_slugs": [], "records": []}) == 0, "空状态应清 0 条"
    print("[GREEN] resume-purge 双向断言通过：只清 episode_exception，保留真实 INCOMPLETE")

    # ---------------------------------------------------------------- 围栏 1：冻结层身份
    prov = provenance_block()
    assert prov["frozen_ok"] is True, f"冻结哈希不匹配: {[(k, v['match']) for k, v in prov['frozen'].items()]}"
    assert len(prov["frozen"]) == 6, f"冻结文件数应为 6，实为 {len(prov['frozen'])}"
    assert prov["frozen"]["agent_arm.py"]["sha256"] == FROZEN_SHA256_EXPECTED["agent_arm.py"]
    print("[GREEN] provenance：6 个冻结文件哈希与 PREREG §1 逐字一致")

    # RED：把冻结文件复制到临时目录并篡改一个字节，provenance 必须判 False
    import shutil
    import tempfile
    tmpdir = Path(tempfile.mkdtemp(prefix="l3prov_"))
    try:
        for name in FROZEN_FILES:
            shutil.copy2(ROOT / name, tmpdir / name)
        (tmpdir / "judge.py").write_text((tmpdir / "judge.py").read_text() + "\n# tampered\n", encoding="utf-8")
        bad = provenance_block(tmpdir)
        assert bad["frozen_ok"] is False, "RED 失效：篡改冻结文件后 provenance 仍判 ok"
        assert bad["frozen"]["judge.py"]["match"] is False, "RED 失效：篡改的 judge.py 未标记"
        assert bad["frozen"]["engine.py"]["match"] is True, "RED 过杀：未篡改的 engine.py 被误判"
        print("[RED-PASS] provenance 对篡改的冻结文件判 False（未篡改项仍 True，无过杀）")
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    # ---------------------------------------------------------------- 围栏 2：统计口径金标
    # 合成两条配对：B 各 1000 tok，D 各 2000 tok → cost_ratio 必须精确等于 2.0。
    # 这条断言是"改公式必红"的锚：任何人把 cost_ratio 换成常数/中位数/别的分母，这里立刻炸。
    def _rec(cond, tok, verified, verdict="RECOVERED", card_id="C1"):
        return {
            "model": "m", "card_id": card_id, "condition": cond, "repeat": 0,
            "verdict": verdict, "removed_memory_id": None,
            "usage": {"prompt_tokens": tok, "completion_tokens": 0},
            "metrics": {"verified_count": verified, "n_files": 40},
        }

    gold = [
        # 两张不同卡各成一对（配对键 = model+card_id+repeat，同卡会塌成一对）
        _rec("B", 1000, 40, card_id="C1"), _rec("D", 2000, 40, card_id="C1"),
        _rec("B", 1000, 40, card_id="C2"), _rec("D", 2000, 40, card_id="C2"),
        # 一条 INCOMPLETE 不得进配对（PREREG：双方都 effective 才成对）
        _rec("D", 999999, 0, verdict="INCOMPLETE", card_id="C3"),
    ]
    rep = summarize(gold)
    m = rep["h3b_paired"]["m"]
    assert m["valid_pairs"] == 2, f"金标有效对应为 2，实为 {m['valid_pairs']}"
    assert m["cost_ratio_D_over_B"] == 2.0, f"金标 cost_ratio 应为 2.0，实为 {m['cost_ratio_D_over_B']}"
    assert m["cost_ok_le_1_10"] is False, "2.0 必须判超限"
    assert m["cost_ratio_per_file"] == 2.0, f"金标 per_file 应为 2.0，实为 {m['cost_ratio_per_file']}"
    assert rep["statistic_spec"] is STATISTIC_SPEC, "report 未挂上统计口径规格"

    # RED：把口径改成常数必须被这条金标抓住（模拟"静默改公式"）
    def _tampered_cost_ratio(_tok_b, _tok_d, _nb, _nd):
        return 1.0

    pinned = (m["cost_ratio_D_over_B"] == 2.0)
    assert not _tampered_cost_ratio(0, 0, 1, 1) == m["cost_ratio_D_over_B"], (
        "RED 失效：篡改后的口径与被钉住的金标值相同，无法分辨"
    )
    print(f"[GREEN] 统计口径金标：cost_ratio=2.0 / per_file=2.0 / 超限判 False / INCOMPLETE 不入对（pinned={pinned}）")

    # ---------------------------------------------------------------- 围栏 3：D 条件删除幂等性
    # D 的 m-plan 在编排层删一次、冻结版 system_prompt 又删一次（agent_arm.py:124-125）。
    # 这不是 bug（两次删除幂等），但必须被断言钉住：若哪天冻结版不再过滤 m-plan，
    # D 会静默退化成一个"没删任何东西的 reactive 臂"，而判定口径看不出差别。
    shown_with_card_edit = agent_arm.system_prompt(d_card, "memory_delete")
    shown_without = agent_arm.system_prompt(card, "memory_delete")
    assert shown_with_card_edit == shown_without, (
        "D 条件的提示在「卡片已删 m-plan」与「卡片未删」两种输入下不一致 —— 幂等性被破坏"
    )
    assert "m-plan" not in shown_without and "old plan" not in shown_without.lower()
    is_stale_line = agent_arm.system_prompt(card, "memory_delete")
    assert "only `stat` tells you the truth" in is_stale_line, "D 必须拿到 reactive 规则行"
    # 必须按 run_episode 的真实调用路径取：run_episode 里 stat_visible=(policy != "stale")，
    # 所以 B 臂要用 stat_visible=False 才拿到 "stored plan is the default authority"。
    b_line = agent_arm.system_prompt(card, "stale", stat_visible=False)
    assert "stored plan is the default authority" in b_line, "B 必须拿到 authority 规则行"
    assert b_line != is_stale_line, "B 与 D 的规则行不得相同（否则两臂提示无差别）"
    print("[GREEN] D 删除幂等性 + B/D 规则行差异断言通过")

    print("=== SELFTEST", "PASS" if ok else "FAIL", "===")
    return 0 if ok else 1


# ----------------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="+")
    parser.add_argument("--cards-manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--n-units", type=int, default=None, help="用前 N 张卡（默认全部）")
    parser.add_argument("--conditions", nargs="+", default=["B", "D"], help="B/D/R/R2 组合")
    parser.add_argument("--repeats", type=int, default=1, help="每个单元的 seed 重复次数（0,1,2...）")
    parser.add_argument("--out", type=Path, default=ROOT / "runs" / "l3-formal-v2")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument("--max-calls-per-episode", type=int, default=40)
    parser.add_argument("--max-turns", type=int, default=20)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--random-harness", choices=["agent_arm", "cf_episode"], default="agent_arm",
                        help="随机对照(R/R2)的 harness：agent_arm=冻结 reactive 提示（正式口径）；cf_episode=独立副本（仅敏感性检查）")
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--verify-provenance", action="store_true",
                        help="只校验冻结层 6 个文件哈希是否与 PREREG §1 一致；不一致 exit 2")
    args = parser.parse_args()

    if args.selftest:
        return selftest()

    if args.verify_provenance:
        prov = provenance_block()
        bad = [k for k, v in prov["frozen"].items() if not v["match"]]
        print(json.dumps({"frozen_ok": prov["frozen_ok"], "mismatch": bad,
                          "runners": prov["runners"]}, ensure_ascii=False, indent=2))
        return 0 if prov["frozen_ok"] else 2

    if not args.models:
        parser.error("--models 必填（--selftest 除外）")

    manifest = load_manifest(args.cards_manifest)
    cards_dir = args.cards_manifest.resolve().parent
    n_total = min(args.n_units or manifest["n_cards"], manifest["n_cards"])
    cards = [load_card(cards_dir, manifest["cards"][i]) for i in range(n_total)]
    print(f"loaded {len(cards)} cards (hash-verified) from {args.cards_manifest}")

    out = args.out.resolve()
    traces_dir = out / "traces"
    judgements_dir = out / "judgements"
    traces_dir.mkdir(parents=True, exist_ok=True)
    judgements_dir.mkdir(parents=True, exist_ok=True)

    state = {
        "started_at": datetime.now().isoformat(),
        "finished": False,
        "planned": args.repeats * len(cards) * len(args.conditions) * len(args.models),
        "done_slugs": [],
        "records": [],
    }
    if args.resume:
        loaded = load_state(out)
        if loaded:
            state.update(loaded)
            n_purged = purge_burned_incomplete(state)
            if n_purged:
                save_state(out, state)
                print(f"resume-purge: 清除 {n_purged} 条传输层烧掉的 INCOMPLETE，将重跑")
            print(f"resumed: {len(state['done_slugs'])} already done / {state['planned']} planned")
    done = set(state["done_slugs"])

    # 主网格
    for model in args.models:
        for card in cards:
            for condition in args.conditions:
                for repeat in range(args.repeats):
                    _, removed_id = build_condition_card(card, condition)
                    slug = slug_for(model, card["card_id"], condition, removed_id, repeat)
                    if slug in done:
                        continue
                    client = agent_arm.Client(args.base_url, model, args.max_calls_per_episode)
                    result = None
                    last_exc = None
                    for attempt in range(3):
                        try:
                            result = run_one(client, card, condition, repeat, args.max_turns, args.random_harness)
                            break
                        except Exception as e:
                            last_exc = e
                            print(f"  [retry {attempt + 1}/3] {slug}: {type(e).__name__}: {str(e)[:80]}", flush=True)
                            time.sleep(30)
                    if result is None:
                        # 重试耗尽：记一条带错误的 INCOMPLETE，继续跑（不因单条崩整批）
                        e = last_exc
                        result = {
                            "card_id": card["card_id"], "condition": condition,
                            "removed_memory_id": removed_id, "replay": repeat,
                            "verdict": "INCOMPLETE", "metrics": {},
                            "usage": {"calls": getattr(client, "calls", 0),
                                      "prompt_tokens": getattr(client, "prompt_tokens", 0),
                                      "completion_tokens": getattr(client, "completion_tokens", 0)},
                            "budget_exhausted": False,
                            "errors": [f"episode_exception:{type(e).__name__}:{e}"],
                            "injection": None, "trace": {"schema": "l3-trace/v1", "card_id": card["card_id"],
                                                          "condition": condition, "steps": [], "errors": [str(e)]},
                        }
                    trace_path = traces_dir / f"{slug}.json"
                    trace_path.write_text(json.dumps(result["trace"], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                    judgement = {k: v for k, v in result.items() if k != "trace"}
                    judgement["model"] = model
                    judgement_path = judgements_dir / f"{slug}.json"
                    judgement_path.write_text(json.dumps(judgement, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

                    record = {
                        "model": model,
                        "card_id": card["card_id"],
                        "condition": condition,
                        "removed_memory_id": removed_id,
                        "repeat": repeat,
                        "verdict": result["verdict"],
                        "metrics": result.get("metrics", {}),
                        "usage": result["usage"],
                        "budget_exhausted": result.get("budget_exhausted", False),
                        "errors": result.get("errors", []),
                        "slug": slug,
                        "trace": str(trace_path.relative_to(out)),
                        "judgement": str(judgement_path.relative_to(out)),
                        "trace_sha256": hashlib.sha256(trace_path.read_bytes()).hexdigest(),
                    }
                    state["records"].append(record)
                    state["done_slugs"].append(slug)
                    done.add(slug)
                    save_state(out, state)  # 每条即 checkpoint
                    print(f"[{len(state['done_slugs'])}/{state['planned']}] {slug}: {result['verdict']} calls={result['usage']['calls']}", flush=True)

    state["finished"] = True
    state["finished_at"] = datetime.now().isoformat()
    save_state(out, state)

    summary = summarize(state["records"])
    report = {
        "schema": "l3-formal-report/v2",
        "run_id": out.name,
        "base_url": args.base_url,
        "models": args.models,
        "conditions": args.conditions,
        "random_harness": args.random_harness,
        "n_cards": len(cards),
        "repeats": args.repeats,
        # 判定口径围栏：任何 report 都能回答"这份数据是不是冻结版跑的"
        "provenance": provenance_block(),
        **summary,
        "records": state["records"],
    }
    report_path = out / "report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\nwrote {len(state['records'])} records -> {report_path}")
    print(json.dumps({k: v for k, v in report.items() if k != "records"}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
