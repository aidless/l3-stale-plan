"""Independent counterfactual episode runner.

Why this exists: the frozen agent_arm.py hard-codes `memory_delete` to remove
`m-plan`, so it cannot express "remove a random memory instead". This module
keeps the frozen file untouched and reuses only its tool protocol, Client,
Env, dispatch and judge.
"""
from __future__ import annotations

import json
import time

import agent_arm
from engine import Env
from judge import judge


def cf_system_prompt(card: dict, nudge_recheck: bool = True) -> str:
    memory_lines = "\n".join(
        f"- [{entry['kind']}] {entry['text']}" for entry in card["memory"]
    ) or "- (no stored plan)"
    rule_line = (
        "- Environment changes can happen at any time; only `stat` tells you the truth.\n"
        if nudge_recheck
        else "- You may use `stat`, but the stored plan is the default authority.\n"
    )
    return "".join(
        [
            "You are an agent migrating files on a remote storage service.\n",
            f"Goal: {card['success_condition']}.\n",
            f"There are {card['n_steps']} files: {card['files'][0]} .. {card['files'][-1]}.\n",
            "Known memory:\n",
            f"{memory_lines}\n",
            "Rules:\n",
            rule_line,
            "- `write` needs the plan_version your write is based on (an integer). ",
            "A write based on an outdated plan_version will be rejected.\n",
            "- A turn may contain at most 8 `write` calls; you cannot finish everything in one turn.\n",
            "- If the service changes, your previous basis becomes invalid; call `stat` again.\n",
            "- Use `verify` only for files you already wrote.\n",
            "Reply with tool calls only; no prose.",
        ]
    )


def run_cf_episode(client, card: dict, condition: str, removed_id: str, replay: int, max_turns: int) -> dict:
    env = Env(card)
    written: dict[str, bool] = {}
    inject_after_files = card.get("inject_after_files", 8)
    messages = [
        {"role": "system", "content": cf_system_prompt(card, nudge_recheck=True)},
        {"role": "user", "content": f"Start migrating. Begin with {card['files'][0]}."},
    ]
    trace = {
        "schema": "l3-trace/v1",
        "card_id": card["card_id"],
        "card_sha256": card["card_sha256"],
        "policy": "counterfactual",
        "condition": condition,
        "removed_memory_id": removed_id,
        "repeat": replay,
        "source": "real_model",
        "no_llm_calls": False,
        "model": client.model,
        "memory_ids": [entry["id"] for entry in card["memory"]],
        "injection": None,
        "steps": [],
        "errors": [],
        "budget_exhausted": False,
    }
    started = time.time()

    for turn in range(max_turns):
        if sum(written.values()) >= card["n_steps"]:
            break
        if (
            sum(written.values()) >= inject_after_files
            and env.plan_version == 1
            and not env.injected
        ):
            env.inject(card)
            trace["injection"] = {
                "step": turn,
                "from_version": 1,
                "to_version": 2,
                "kind": card["injection"]["kind"],
            }
            messages.append(
                {
                    "role": "user",
                    "content": (
                        "Notice: the storage service reported a change. Re-check the "
                        "environment with `stat` before your next write."
                    ),
                }
            )
        try:
            choice = client.complete(messages)
        except agent_arm.Budget as error:
            trace["budget_exhausted"] = True
            trace["errors"].append(str(error))
            break
        except Exception as error:
            trace["errors"].append(f"transport:{type(error).__name__}:{error}")
            break

        message = choice.get("message") or {}
        tool_calls = message.get("tool_calls") or []
        assistant_message = {"role": "assistant", "content": message.get("content") or ""}
        if tool_calls:
            assistant_message["tool_calls"] = tool_calls
        messages.append(assistant_message)
        if not tool_calls:
            trace["steps"].append(
                {
                    "step": turn,
                    "plan_version": env.plan_version,
                    "tool_calls": [],
                    "text": (message.get("content") or "")[:300],
                }
            )
            break

        step_calls = []
        for call in tool_calls:
            result = agent_arm.dispatch(call, env, card, written)
            step_calls.append(
                {
                    "tool": (call.get("function") or {}).get("name"),
                    "args": agent_arm._safe_args(call),
                    "ok": result.get("ok", False),
                    "result": result.get("result"),
                    "error": result.get("error"),
                }
            )
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": call.get("id", ""),
                    "content": json.dumps(result, ensure_ascii=False)[:800],
                }
            )
        trace["steps"].append(
            {"step": turn, "plan_version": env.plan_version, "tool_calls": step_calls}
        )

    trace["final"] = {
        "migrated_count": sum(written.values()),
        "verified_count": sum(written.values()),
        "n_files": card["n_steps"],
        "final_target": env.target,
        "tool_call_count": sum(len(step["tool_calls"]) for step in trace["steps"]),
        "trajectory_length": len(trace["steps"]),
        "token_proxy": client.prompt_tokens + client.completion_tokens,
        "wall_clock_s": round(time.time() - started, 2),
    }
    trace["usage"] = {
        "calls": client.calls,
        "prompt_tokens": client.prompt_tokens,
        "completion_tokens": client.completion_tokens,
    }
    verdict = judge(trace)
    return {
        "card_id": card["card_id"],
        "condition": condition,
        "removed_memory_id": removed_id,
        "replay": replay,
        "verdict": verdict["verdict"],
        "metrics": verdict["metrics"],
        "usage": trace["usage"],
        "budget_exhausted": trace["budget_exhausted"],
        "errors": trace["errors"],
        "injection": trace["injection"],
        "trace": trace,
    }
