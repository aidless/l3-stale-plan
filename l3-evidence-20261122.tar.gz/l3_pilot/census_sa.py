#!/usr/bin/env python3
"""census-before-recommending-a-build: 盘上是否已有满足 S_a 判据的落地字节。

谓词 P（可复算，须两份字节同时成立）：
  SRC: 一份 runner 源码，其载体构造逻辑从「检索语料/检索内容/corpus/retriever」
       移除计划条目（不是 S_c 历史裁剪，也不是 memory 行删除）。
  CAR: 至少一份 judgement 载体，其 carrier 字段指向 S_a/retriever/corpus 实现。
P = SRC ∧ CAR。三态：ALREADY_BUILT / REGISTRATION_SUPERSEDED / MUST_BUILD_NEW。
"""
import argparse, hashlib, json, pathlib, re, sys, glob as globmod

ROOT = pathlib.Path("/home/liuzewen/research-plan-20261108/l3_pilot")
DEFAULT_GLOBS = [
    str(ROOT / "*.py"),
    str(ROOT / "runs" / "*" / "report.json"),
    str(ROOT / "runs" / "*" / "state.json"),
    str(ROOT / "runs" / "*" / "judgements" / "*.json"),
    "/tmp/*/census_sa_fixture/**",          # 显式含临时根
]
BUDGET_FILES, BUDGET_BYTES = 6000, 2_000_000
WINDOW_FROM = 0  # 全时段（S_a 从未落地，无需当代窗口；窗口外计数仍登记）

# 判据正则（现读语义，不手打具体卡/模型名）
RE_CORPUS = re.compile(r"retriev\w*|corpus|检索|检索语料", re.I)
RE_REMOVE = re.compile(r"remove|removed|移除|删除|删去|del_", re.I)
RE_CAR_SA = re.compile(r"S_a|S-a|retriev|corpus", re.I)


def sha(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def expand(globs):
    seen = set()
    out = []
    capped = False
    for g in globs:
        for m in globmod.glob(g, recursive=True):
            p = pathlib.Path(m)
            if not p.is_file():
                continue
            # 自指排除：普查脚本自身含判据关键词，不是候选 runner
            if p.name == "census_sa.py":
                continue
            if len(out) >= BUDGET_FILES:
                capped = True
                break
            if p.stat().st_size > BUDGET_BYTES:
                continue
            if p not in seen:
                seen.add(p)
                out.append(p)
    return out, capped


def src_predicate(p: pathlib.Path):
    """源码判据：载体构造上下文里同时出现检索语料与移除语义。"""
    try:
        txt = p.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return False, ""
    # 逐函数/逐段粗筛：同一"载体/历史/语料"函数里同时命中两类词
    lines = txt.splitlines()
    for i, ln in enumerate(lines):
        window = "\n".join(lines[i:i + 30])
        if RE_CORPUS.search(window) and RE_REMOVE.search(window) and re.search(
            r"def .*(carrier|corpus|retriev|memory|message|context)", window, re.I
        ):
            return True, sha(p)
    return False, ""


def car_predicate(p: pathlib.Path):
    """载体判据：judgement/state 里 carrier 字段指向 S_a。"""
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return False, ""
    carrier = ""
    if isinstance(d, dict):
        carrier = str(d.get("carrier", ""))
        for key in ("cells", "arms", "records"):
            v = d.get(key)
            if isinstance(v, dict):
                carrier += " " + " ".join(str(x.get("carrier", "")) for x in v.values() if isinstance(x, dict))
            elif isinstance(v, list):
                carrier += " " + " ".join(str(x.get("carrier", "")) for x in v if isinstance(x, dict))
    return bool(RE_CAR_SA.search(carrier)), sha(p)


def census(globs):
    files, capped = expand(globs)
    candidates, skipped = [], []
    src_hits, car_hits = [], []
    digests = {}
    for p in files:
        s = sha(p)
        digests.setdefault(s, []).append(str(p))
        if p.suffix == ".py":
            ok, h = src_predicate(p)
            if ok:
                src_hits.append({"path": str(p), "sha": h})
        elif p.name in ("report.json", "state.json") or p.parent.name == "judgements":
            ok, h = car_predicate(p)
            if ok:
                car_hits.append({"path": str(p), "sha": h})
    verdict = "ALREADY_BUILT_vs_current_best" if (src_hits and car_hits) else "MUST_BUILD_NEW"
    if capped and not (src_hits and car_hits):
        verdict = "PARSE_CAPPED_INCONCLUSIVE"
    return {
        "scan_domain": globs,
        "budget": {"files": BUDGET_FILES, "bytes": BUDGET_BYTES, "used_files": len(files), "capped": capped},
        "window_from": WINDOW_FROM,
        "landed_digests": sorted(digests.keys()),
        "candidates": [{"path": str(p), "sha": sha(p), "bytes": p.stat().st_size,
                        "mtime": p.stat().st_mtime} for p in files[:200]],
        "skipped_not_candidate": skipped,
        "src_hits": src_hits, "car_hits": car_hits,
        "verdict": verdict,
        "cost": "0 发（登记/发货）" if verdict.startswith("ALREADY") else "1 发（新建）",
        "interpretation_MUST_read_before_quoting":
            "绿≠可发：普查只答『字节满足谓词』，不答额度/身份闸/评测；"
            "INCONCLUSIVE≠必须新建：上限用尽或只跑筛查遍时不得折成 MUST_BUILD。",
    }


def selftest():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        t = pathlib.Path(td)
        # 正控：一份满足 SRC 的源码 + 一份 carrier=S_a 的 judgement
        src = t / "sa_runner.py"
        src.write_text(
            "def carrier_messages(card):\n"
            "    # 从检索语料 retriever corpus 中 remove 计划条目\n"
            "    corpus = card['retriever_corpus']\n"
            "    corpus = [x for x in corpus if x['kind'] != 'plan']  # remove\n"
            "    return corpus\n", encoding="utf-8")
        jd = t / "judgements"
        jd.mkdir()
        (jd / "x.json").write_text(json.dumps({"carrier": "S_a:retriever-corpus", "verdict": "RECOVERED"}))
        g_pos = [str(t / "*.py"), str(jd / "*.json")]
        r = census(g_pos)
        assert r["verdict"] == "ALREADY_BUILT_vs_current_best", f"正控失败 {r['verdict']}"
        # 注入1：真实 v3 runner（S_c）不应命中 SRC 判据（其载体从历史裁剪，无检索语料 remove）
        v3 = ROOT / "v3_runner.py"
        if v3.exists():
            ok, _ = src_predicate(v3)
            assert not ok, "S_c runner 被误判成 S_a"
        # 注入2：复发——同摘要两份只算一支
        r2 = census(g_pos)
        assert r2["verdict"] == r["verdict"], "复发判定不稳"
        # 漏根负控：域外 fixture 看不见
        outside = t.parent / "census_outside_fixture"
        outside.mkdir(exist_ok=True)
        (outside / "sa_runner.py").write_text(src.read_text())
        g_out = [str(ROOT / "*.py")]  # 不含 temp 域
        r3 = census(g_out)
        assert all(outside.as_posix() not in h["path"] for h in r3["candidates"]), "漏根负控失败"
    print("SELFTEST PASS (正控 ALREADY / S_c 不误判 / 复发稳 / 漏根负控)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "runs" / "sa_census.json"))
    a = ap.parse_args()
    if a.selftest:
        selftest(); return
    r = census(DEFAULT_GLOBS)
    pathlib.Path(a.out).write_text(json.dumps(r, ensure_ascii=False, indent=2))
    print(json.dumps({"verdict": r["verdict"], "src_hits": r["src_hits"],
                      "car_hits": r["car_hits"], "files_scanned": r["budget"]["used_files"],
                      "capped": r["budget"]["capped"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
