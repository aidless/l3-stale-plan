#!/usr/bin/env python3
"""D16 独立层：把「零成功写」从 STALE_FAILURE 里切出来。

为什么不改 rejudge_v2_verdicts.py：它是 D13 起登记为跨批可比的判定层
（L3_V2_PREREG_REVIEWABLE.md §9 钉了 v2_runner_sc.py 的身份，重判层同理）。
把新判据塞进去会让 runs/l3-v2-rejudged/ 这个注册载体变味——D14 的三批
读数、skin 表、稿件里的 119/119 都挂在它上面。所以本层只读不让写：

    输入  runs/<batch>/traces/*.json          （真 trace）
          runs/l3-v2-rejudged/<batch>.json    （注册重判产物，只读）
    输出  runs/l3-v2-d16/<batch>.json         （并列复核层，不改上面两者）

判据（三条同时成立才重标 NO_VALID_WRITE）：
    1) 注册层已判 STALE_FAILURE
    2) 全 episode 无一次成功写（tool_calls 里 write 的 ok 全为假）
    3) 无一次 stale-basis 尝试（basis_version < 当步 plan_version）
第 2 条是关键：del 臂在注入之前就 0 成功写，说明失败发生在「不知道资源名」，
不是「知道名字但写错了版本」。第 3 条排掉「既没写成也没试过旧版本」的情况
——那种连 stale 尝试都不存在，判 STALE 在语义上无据。

用法：
    cd l3_pilot && python3 d16_zero_write_layer.py                 # 三批
    cd l3_pilot && python3 d16_zero_write_layer.py --selftest
反证：注入一条「有成功写」的伪 trace，必须仍判 STALE_FAILURE（尺子量成功写
次数，不量 verdict 标签）。
"""
from __future__ import annotations

import argparse
import collections
import glob
import json
import pathlib

NO_VALID_WRITE = "NO_VALID_WRITE"

BATCHES = [
    "l3-v2-sc-40-minimax",
    "l3-v2-sc-40-kimi-lowspeed",
    "l3-v2-sc-40-workbuddy2",
]


def _write_ok(call: dict) -> bool:
    if call.get("tool") != "write":
        return False
    if call.get("ok"):
        return True
    result = call.get("result") or {}
    return bool(result.get("ok"))


def count_writes(trace: dict) -> dict:
    """返回 {ok, total, pre_ok, pre_total, stale_basis}，全部从 steps 现算。"""
    ok = total = pre_ok = pre_total = stale = 0
    inj_step = None
    inj = trace.get("injection")
    if isinstance(inj, dict):
        inj_step = inj.get("step")
    pv = {s.get("step"): s.get("plan_version") for s in trace.get("steps") or []}
    for s in trace.get("steps") or []:
        step = s.get("step")
        for c in s.get("tool_calls") or []:
            if c.get("tool") != "write":
                continue
            total += 1
            hit = _write_ok(c)
            if hit:
                ok += 1
            if inj_step is None or (isinstance(step, int) and step < inj_step):
                pre_total += 1
                if hit:
                    pre_ok += 1
            basis = (c.get("args") or {}).get("basis_version")
            if isinstance(basis, int) and not isinstance(basis, bool):
                live = pv.get(step)
                if isinstance(live, int) and basis < live:
                    stale += 1
    return {"ok": ok, "total": total, "pre_ok": pre_ok, "pre_total": pre_total,
            "stale_basis": stale}


def relabel(registered_verdict: str, counts: dict) -> str:
    """注册判定 + 计数 → D16 判定。只可能把 STALE 单向迁出。"""
    if registered_verdict != "STALE_FAILURE":
        return registered_verdict
    if counts["ok"] == 0 and counts["stale_basis"] == 0:
        return NO_VALID_WRITE
    return registered_verdict


def layer_run(run_dir: pathlib.Path) -> dict:
    traces = sorted(glob.glob(str(run_dir / "traces" / "*.json")))
    rows = []
    reg = collections.Counter()
    d16 = collections.Counter()
    arm_d16 = collections.Counter()
    moved = collections.Counter()
    for tf in traces:
        t = json.load(open(tf, encoding="utf-8"))
        slug = t["slug"]
        jp = run_dir / "judgements" / (slug + ".json")
        if not jp.exists():
            continue
        j = json.load(open(jp, encoding="utf-8"))
        counts = count_writes(t)
        nv = relabel(j["verdict"], counts)
        reg[j["verdict"]] += 1
        d16[nv] += 1
        arm_d16[(j["arm"], nv)] += 1
        if nv != j["verdict"]:
            moved[(j["verdict"], nv)] += 1
        rows.append({"slug": slug, "arm": j["arm"],
                     "registered": j["verdict"], "d16": nv,
                     "transport_loss": j.get("transport_loss", False),
                     "writes": counts})
    return {
        "schema": "l3-v2-d16/v1",
        "run_dir": str(run_dir),
        "traces": len(traces),
        "judged": len(rows),
        "registered_dist": dict(reg),
        "d16_dist": dict(d16),
        "arm_d16_dist": {f"{a}|{k}": c for (a, k), c in sorted(arm_d16.items())},
        "moved": {f"{o}->{n}": c for (o, n), c in sorted(moved.items())},
        "rows": rows,
    }


def selftest() -> None:
    # GREEN：零成功写 + 零 stale 尝试 → NO_VALID_WRITE
    z = {"ok": 0, "total": 3322, "pre_ok": 0, "pre_total": 224, "stale_basis": 0}
    assert relabel("STALE_FAILURE", z) == NO_VALID_WRITE, z
    # RED-1：有一条成功写 → 不许重标（尺子量成功写，不量标签）
    one = {"ok": 1, "total": 100, "pre_ok": 1, "pre_total": 50, "stale_basis": 0}
    assert relabel("STALE_FAILURE", one) == "STALE_FAILURE", one
    # RED-2：有 stale-basis 尝试 → 是真的写错过版本，不许重标
    st = {"ok": 0, "total": 100, "pre_ok": 0, "pre_total": 20, "stale_basis": 3}
    assert relabel("STALE_FAILURE", st) == "STALE_FAILURE", st
    # RED-3：非 STALE 判定一律原样传递（只碰兜底分支）
    for v in ("RECOVERED", "INCOMPLETE", "PRE_INJECTION_COMPLETION",
              "INCOMPLETE_TRUNCATED"):
        assert relabel(v, z) == v, v
    # count_writes 两条：注入切分与 stale-basis 计数
    trace = {"injection": {"step": 2}, "steps": [
        {"step": 0, "plan_version": 1, "tool_calls": [
            {"tool": "write", "args": {"basis_version": 1}, "ok": True}]},
        {"step": 1, "plan_version": 2, "tool_calls": [
            {"tool": "write", "args": {"basis_version": 1}, "ok": False,
             "result": {"ok": False, "error": "resource_unavailable"}}]},
        {"step": 2, "plan_version": 2, "tool_calls": [
            {"tool": "write", "args": {"basis_version": 2},
             "result": {"ok": True}}]},
    ]}
    c = count_writes(trace)
    assert c == {"ok": 2, "total": 3, "pre_ok": 1, "pre_total": 2,
                 "stale_basis": 1}, c
    print("[PASS] GREEN 零成功写+零 stale 尝试 → NO_VALID_WRITE")
    print("[PASS] RED-1 有成功写不许重标 / RED-2 有 stale 尝试不许重标")
    print("[PASS] RED-3 非 STALE 判定原样传递 + count_writes 切分正确")
    print("SELFTEST PASS (3/3)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--runs", nargs="+", default=BATCHES)
    ap.add_argument("--out", default="runs/l3-v2-d16")
    a = ap.parse_args()
    if a.selftest:
        selftest()
        return 0
    root = pathlib.Path(__file__).resolve().parent
    out = root / a.out
    out.mkdir(parents=True, exist_ok=True)
    summary = {}
    moved_total = 0
    for run in a.runs:
        res = layer_run(root / "runs" / run)
        # 断言 1：只许 STALE 单向迁出 —— registered_stale == d16_stale + nvw
        rs = res["registered_dist"].get("STALE_FAILURE", 0)
        ds = res["d16_dist"].get("STALE_FAILURE", 0)
        nvw = res["d16_dist"].get(NO_VALID_WRITE, 0)
        assert rs == ds + nvw, (run, rs, ds, nvw)
        moved_total += nvw
        # 断言 2：NO_VALID_WRITE 只可能在 del 臂
        arms = {k.split("|")[0] for k in res["arm_d16_dist"]
                if k.endswith("|" + NO_VALID_WRITE)}
        assert arms <= {"del"}, (run, arms)
        # 断言 3：REC / PIC 一条都不许动
        for v in ("RECOVERED", "PRE_INJECTION_COMPLETION"):
            assert res["registered_dist"].get(v, 0) == res["d16_dist"].get(v, 0), (run, v)
        (out / (run + ".json")).write_text(
            json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
        summary[run] = {k: res[k] for k in
                        ("judged", "registered_dist", "d16_dist", "moved")}
    assert moved_total > 0, "D16 层全局未改到任何一条，判据未生效"
    print(json.dumps(summary, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
