#!/usr/bin/env python3
"""追加 D7（判定口径围栏 + D 臂删除幂等性）到 DEVIATION_L3.md。O_APPEND 单写 + 前缀断言。"""
import hashlib
import os
from pathlib import Path

DOC = Path(__file__).resolve().parent.parent / "DEVIATION_L3.md"

BLOCK = """
## D7（2026-11-10）：判定口径围栏（口径可被静默改掉的红线）+ D 臂删除幂等性

### D7.1 问题：这个门不会红

Linus 视角评审（`persona-board/reviews/linus-torvalds.md`）实测的 RED：
把 `formal_runner.py` 里 `cost_ratio = (tok_d / nd) / (tok_b / nb)` 改成任意常数
（如 `statistics.median([1.0])`），`--selftest` **依旧 PASS、exit=0**。
即：判定口径可以被静默改掉而门不响 —— 违反 AGENTS.md 第 8 条「门必须能失败」与
第 21 条「RED→GREEN 双向」。

主会话复验证实：原 selftest 只测"条件编辑对不对 / McNemar 数字 / resume-purge"，
**从未钉住统计口径**，也没在任何 report 里留下"这份数据是不是冻结版跑的"身份。

### D7.2 修法（只动未冻结编排层）

`l3_pilot/formal_runner.py` 新增三样东西，`formal_runner_mt.py` 通过
`fr.provenance_block()` **共用同一个实现**（不各写一份，避免两份口径漂移）：

1. **`FROZEN_SHA256_EXPECTED`**：6 个冻结文件的完整 sha256，**逐字复制自
   `PREREG_L3.md` §1**（不是本文件现算后回填，避免循环自证）。
2. **`STATISTIC_SPEC`**：把 `cost_ratio_D_over_B` / `stale_rate` / `loss_rate` /
   配对单元 / effective 集合的定义写成常量，并挂进每一份 report。
3. **`provenance_block(root=None)`**：产出 `frozen_ok` / 逐文件 `{sha256, expected, match}` /
   三个 runner 的 sha256 与行数 / `condition_remove` / `condition_policy` / `statistic_spec`。
   两个 runner 的 `report.json` 都带这一段；新增 `--verify-provenance`（不一致 exit 2）。

另加 `cost_ratio_per_file`（按 `metrics.verified_count` 归一的**并列**口径，标注
"不替代主口径"，PREREG §2 判定仍用 `cost_ratio_D_over_B`）。

### D7.3 RED 证据（门真的会红，不是装饰）

在 `formal_runner.py` 注入 `cost_ratio = 1.0  # MAGIC-1.0 静默改口径`，跑 `--selftest`：

```
File "formal_runner.py", line 541, in selftest
    assert m["cost_ratio_D_over_B"] == 2.0, f"金标 cost_ratio 应为 2.0，实为 {m['cost_ratio_D_over_B']}"
AssertionError: 金标 cost_ratio 应为 2.0，实为 1.0
```

恢复后 `sha256` 与注入前逐字一致（`HASH_MATCH`），`--selftest` 回到 PASS。

金标夹具：两张不同卡各一对，B 各 1000 tok、D 各 2000 tok → `cost_ratio` 必须精确
`2.0`、`cost_ratio_per_file` 必须 `2.0`、`cost_ok_le_1_10` 必须 `False`；
另塞一条 `INCOMPLETE`（999,999 tok）**不得进配对** —— 顺手钉住"分母不含未完成单元"。

> 夹具自身也抓到我一个 bug：最初两张合成卡用同一个 `card_id="C"`，配对键
> `(model, card_id, repeat)` 让它们塌成一对，`valid_pairs` 断言当场炸（1≠2）。
> 已改成 C1/C2。这条 incident 保留在此，作为"金标夹具必须先自证"的实例。

### D7.4 D 臂删除幂等性：不改代码，改加断言

`m-plan` 确实被删两次：编排层 `formal_runner.py` 的 `CONDITION_REMOVE["D"] = "m-plan"`
删一次，冻结层 `agent_arm.py:124-125`（`policy == "memory_delete"`）再删一次。

**裁决：不改。（与 Linus 建议不同。）** 理由两条，都可核：

1. **两次删除幂等**：`system_prompt(card, "memory_delete")` 与
   `system_prompt(card − m-plan, "memory_delete")` 产出的提示**逐字相同**（已写成断言
   `shown_with_card_edit == shown_without`）。所以对测量对象零影响。
2. **改 `CONDITION_REMOVE["D"] = None` 会改 slug**（`rid-m-plan` → `rid-keep`）——
   Run A 的 150 条 judgement/state 全部带 `rid-m-plan`，改了就断掉跨批次可比性与 resume 对账。
   为一个零影响的代码洁癖付这个代价不划算。

真正的风险不是"删两次"，而是**哪天冻结版不再过滤 m-plan**时，D 会静默退化成
"没删任何东西的 reactive 臂"，而判定口径看不出差别。所以改成断言（变红才动）：

- `shown_with_card_edit == shown_without`（幂等性）
- `system_prompt(card,"memory_delete")` 含 `only \`stat\` tells you the truth`（D 的规则行）
- `system_prompt(card,"stale",stat_visible=False)` 含 `stored plan is the default authority`（B 的规则行）
- `b_line != is_stale_line`（两臂提示必须有差别，否则 B/D 无区分度）

### D7.5 与 D6 的关系

D6 已裁定**不投 2880 全量确认性跑**（混杂未分离）。本 D7 的围栏不是为那次跑准备的，
而是为**设计 v2 任何一个批次**准备的：v2 必须有 `provenance.frozen_ok` 与钉住的口径，
否则下一代数据同样无法判"是不是冻结版跑的、用的是哪条公式"。

### D7.6 复核命令

```bash
cd l3_pilot
python3 formal_runner.py --verify-provenance   # frozen_ok=true，exit 0
python3 formal_runner.py --selftest            # 含 3 条 RED + 统计金标 + 幂等性断言
python3 formal_runner_mt.py --selftest         # 并发版，共用同一个 provenance_block
python3 power_l3.py --check                    # PREREG 锚点
```

### D7.7 未处理的已知项（照实记，不在本偏离内动手）

- **429 毒化 resume**：`purge_burned_incomplete()` 只认 `episode_exception`，不认
  `transport:HTTPError 429`。Run A 的 `loss_rate 0.54` 就是模型 2 全 429 后 resume
  永久跳过造成的。修法（Linus/Carmack 都提了）需要在 purge 里加 429/URLError 分支，
  但这会改变"什么算可重跑"，属于判定口径变更 → 留到 v2 预注册一起定。
- **反事实成本投影 1.1061**：Linus 按 D 把 10 条 INCOMPLETE 也干完（447.70 tok/文件 × 40 文件）
  投影出全 50 对 `cost_ratio = 1.1061`，仍 >1.10 → 成本条款的红不是"未完成稀释"造成的。
  该数标 **INFERRED**（投影，非实测），未进任何判定。
"""


def main() -> int:
    before = DOC.read_bytes()
    before_hash = hashlib.sha256(before).hexdigest()
    assert b"## D7" not in before, "D7 已存在，拒绝重复追加"
    payload = BLOCK.encode("utf-8")
    fd = os.open(DOC, os.O_WRONLY | os.O_APPEND)
    try:
        os.write(fd, payload)
    finally:
        os.close(fd)
    after = DOC.read_bytes()
    assert after.startswith(before), "追加后前缀不一致"
    assert hashlib.sha256(after[: len(before)]).hexdigest() == before_hash, "前缀哈希不一致"
    assert b"## D7" in after
    print(f"OK: D7 appended, {len(payload)} bytes; {len(before)} -> {len(after)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
