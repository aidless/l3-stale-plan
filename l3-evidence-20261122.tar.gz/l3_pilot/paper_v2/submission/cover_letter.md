# Cover letter — arXiv submission

**Title:** What deleting an agent's memory actually removes: evidence from three preregistered iterations

**Author:** Liu Zewen (ORCID 0009-0003-2981-9888; github.com/aidless)

**Date:** 21 November 2026

Dear editor,

This paper reports a three-iteration preregistered study, plus a carrier-sensitivity replication, of a question that is usually taken for granted: that deleting a stale memory entry helps an agent. Across the successive designs, every apparent benefit of deletion dissolved into a different, independently measured cause. The contribution is therefore not a new deletion method but an honest decomposition of why deletion looks helpful when it is not.

In the first iteration, a packaged comparison appeared to confirm the preregistered mechanism — removing a plan-attribution entry cut stale-plan following from 40/40 to 0/40, at a token cost ratio of 1.1479. A factorial decomposition showed the packaged contrast was confounded: changing only the instruction prompt moved the stale rate from 5/6 to 0/6 cells, while holding the prompt fixed and swapping the culprit entry for an unrelated one changed almost nothing (193 paired episodes, 1.0 percentage point). The named mechanism was not what produced the effect, so this design was not scaled.

In the second iteration, a conversation-history carrier made the two arms differ in exactly one visible object. Deletion produced 119 of 119 stale failures at 3.2–3.8 times the token cost — but reading the traces showed the deletion arm landed no accepted write at all, because the resource identifiers needed to write existed only inside the deleted carrier. The manipulation removed the vocabulary for acting, not a misleading belief. This is a measurement artifact with a general lesson: an intervention can look like a belief change while actually removing the means to act.

In the third iteration, resource identifiers were moved permanently into the system prompt so that both arms could always write, leaving only a version mapping in the carrier. With that confound removed, deletion still raised stale-plan writes (2 of 159 versus 53 of 159 effective pairs, +32.1 percentage points, McNemar p = 1.2e-14, 159 effective pairs exceeding the preregistered minimum of 140) — yet both arms delivered all 40 files (99.5% versus 100.0%), the deletion arm wrote successfully 1481 times before invalidation, and the token ratio fell to 1.0177, comfortably within the preregistered 1.10 cost bound. The 32-point difference measures whether a stale write was ever produced, not whether the task was completed: the deletion arm reached the same destination by trial and error rather than by following an out-of-date plan.

A fourth design, run as a carrier-sensitivity replication rather than a fourth preregistered iteration, moves the surviving version mapping out of conversation history and into a retrieval corpus, keeping the resource identifiers fixed in the system prompt. The stale-write effect survives (+47.3 points on 146 effective pairs, 79 versus 10, p = 3.7e-18) — and for the first time deletion costs the task itself: delivery falls to 135 of 147 against 147 of 147, at a token ratio of 1.2622. Fifty deletion-arm episodes never land an accepted write at all, spending the episode querying the corpus and proposing rejected writes; conditioning on the 97 pairs in which the deletion arm does write before invalidation brackets the third iteration at +25.8 points (30 versus 5, p = 4.6e-6, token ratio 1.2452). The two readings are reported together because neither alone is the estimate.

Four features make this suitable for publication. First, all three iterations were preregistered, including the mechanism that failed; the frozen analysis code and its hashes are recorded, and the negative result is reported rather than suppressed. The replication is labelled as a sensitivity result with its stopping rule (306 of 400 planned episodes, all three model endpoints rate-limited in the same window) stated in the Limitations. Second, every headline number is recomputed from per-episode judgements and traces, and an independent evidence-chain gate verifies that reported counts match the carrier files. Third, the through-line is a caution about interpretation with broad relevance to agent-memory research: deletion has no fixed effect; its consequence is determined by what else the memory happened to carry. Reporting only the stale-failure rate would have supported the wrong conclusion three times. Fourth, each apparent effect came with a diagnostic that the next design had to satisfy, so the sequence is reproducible rather than anecdotal.

The paper is a full empirical report (12 pages, 5 tables, 22 verified references). All experimental carriers, the three preregistrations and the original one, the deviation log (D1–D30), and reproduction commands are publicly available from the author's GitHub (github.com/aidless); an archival copy with a DOI will accompany the camera-ready version.

Sincerely,

Liu Zewen
