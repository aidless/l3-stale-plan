#!/usr/bin/env python3
"""D16 诊断层：从落盘 traces 现算「成功写 / 注入前成功写 / 首次成功写位置」。

铁律 1：所有数字从 traces 重算，不手抄。产出 paper_v2/evidence/success_writes.json。
RED 守卫：注入一个伪造 trace（声称 STALE 但零成功写）必须被计进 never_ok，
证明本尺量的是成功写次数，不是 verdict。
"""
from __future__ import annotations

import argparse
import glob
import json
import pathlib

BATCHES = [
    ("minimax", "l3-v2-sc-40-minimax"),
    ("kimi", "l3-v2-sc-40-kimi-lowspeed"),
    ("workbuddy", "l3-v2-sc-40-workbuddy2"),
]


def is_ok(call: dict) -> bool:
    r = call.get("result") or {}
    return bool(call.get("ok") or (isinstance(r, dict) and r.get("ok")))


def measure_traces(traces: list[dict]) -> dict:
    out = {}
    for arm in ("keep", "del"):
        eps = [t for t in traces if t.get("arm") == arm]
        ok_pre = ok_post = tot_pre = tot_post = 0
        with_ok = 0
        first_ok: dict[int, int] = {}
        used_correct = 0
        for t in eps:
            inj = (t.get("injection") or {}).get("step")
            seen_ok = False
            for s in t.get("steps") or []:
                step = s.get("step", 0)
                pre = inj is None or step < inj
                for c in s.get("tool_calls") or []:
                    if c.get("tool") != "write":
                        continue
                    if pre:
                        tot_pre += 1
                    else:
                        tot_post += 1
                    if not is_ok(c):
                        continue
                    if pre:
                        ok_pre += 1
                    else:
                        ok_post += 1
                    if not seen_ok:
                        seen_ok = True
                        first_ok[step] = first_ok.get(step, 0) + 1
            if seen_ok:
                with_ok += 1
            res = {str(c.get("args", {}).get("resource", "")) for s in t.get("steps") or []
                   for c in s.get("tool_calls") or [] if c.get("tool") == "write"}
            if res & {"store-a", "store-b"}:
                used_correct += 1
        n = len(eps)
        out[arm] = {
            "n": n,
            "episodes_with_ok_write": with_ok,
            "episodes_never_ok": n - with_ok,
            "writes_pre_inject_ok": ok_pre,
            "writes_pre_inject_total": tot_pre,
            "writes_post_inject_ok": ok_post,
            "writes_post_inject_total": tot_post,
            "first_ok_step_dist": {str(k): v for k, v in sorted(first_ok.items())},
            "episodes_using_store_resource": used_correct,
        }
    return out


def load_traces(run_dir: pathlib.Path) -> list[dict]:
    return [json.load(open(f, encoding="utf-8"))
            for f in sorted(glob.glob(str(run_dir / "traces" / "*.json")))]


def build(root: pathlib.Path) -> dict:
    cells = {}
    for name, run in BATCHES:
        cells[name] = measure_traces(load_traces(root / "runs" / run))
    return {
        "schema": "l3-v2-success-writes/v1",
        "note": ("del 臂零成功写且注入前零成功写 => 失败不是 stale-plan 跟随，"
                 "是资源标识符随载体一起被删掉。资源名只出现在 carrier_messages。"),
        "batches": cells,
    }


def selftest() -> None:
    fake = {"arm": "del", "injection": {"step": 1}, "steps": [
        {"step": 0, "tool_calls": [
            {"tool": "write", "ok": False, "result": {"ok": False, "error": "resource_unavailable"},
             "args": {"resource": "default"}}]},
        {"step": 1, "tool_calls": [
            {"tool": "write", "ok": False, "result": {"ok": False, "error": "stale_basis"},
             "args": {"resource": "store-a"}}]},
    ]}
    m = measure_traces([fake])["del"]
    assert m["episodes_with_ok_write"] == 0, m
    assert m["episodes_never_ok"] == 1, m
    assert m["writes_pre_inject_total"] == 1 and m["writes_pre_inject_ok"] == 0, m
    # RED：给它一个成功写，never_ok 必须变 0（证明尺子量的是成功写，不是 verdict）
    fake2 = json.loads(json.dumps(fake))
    fake2["steps"][0]["tool_calls"][0]["ok"] = True
    m2 = measure_traces([fake2])["del"]
    assert m2["episodes_with_ok_write"] == 1, m2
    print("[PASS] GREEN 零成功写计入 never_ok")
    print("[PASS] RED 注入一条成功写后 never_ok 归零（尺子量成功写，不量 verdict）")
    print("SELFTEST PASS (2/2)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="paper_v2/evidence/success_writes.json")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    root = pathlib.Path(__file__).resolve().parent.parent.parent
    if a.selftest:
        selftest()
        return 0
    d = build(root)
    out = root / a.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(d["batches"], ensure_ascii=False, indent=1))
    print("wrote", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
