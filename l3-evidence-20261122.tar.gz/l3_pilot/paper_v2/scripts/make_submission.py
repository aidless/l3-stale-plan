#!/usr/bin/env python3
"""Assemble the arXiv submission package under paper_v2/submission/.

The source tarball produced by arxiv_package_check.sh is already bit-identical
to the manuscript on disk (verified by sha256 per file). This script copies it
into the submission directory, records a checksum manifest, and verifies that
the ancillary documents exist. It never modifies the manuscript or the tarball.

  python3 paper_v2/scripts/make_submission.py            # assemble + verify
  python3 paper_v2/scripts/make_submission.py --selftest  # RED/GREEN on the verifier
"""
import hashlib
import json
import pathlib
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]          # l3_pilot/
PAPER = ROOT / "paper_v2" / "paper"
SUB = ROOT / "paper_v2" / "submission"
TARBALL = PAPER / ".arxiv-check" / "l3-v7.tar.gz"

# files inside the arXiv tarball that must match the on-disk copy
MEMBERS = ["main.tex", "main.bbl",
           "tables/tab_cells.tex", "tables/tab_paired.tex",
           "tables/tab_writes.tex", "tables/tab_v3.tex",
           "tables/tab_sa.tex", "tables/tab_sa_strat.tex"]
# ancillary documents that must exist in the submission directory
ANCILLARY = ["cover_letter.md", "REPRODUCIBILITY.md"]


def sha16(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


def sha_file(p: pathlib.Path) -> str:
    return sha16(p.read_bytes())


def verify_tarball(tarball: pathlib.Path | None = None) -> dict:
    """Return {member: (disk_sha, tar_sha, match)} and raise on mismatch."""
    import tarfile
    tball = tarball or TARBALL
    if not tball.exists():
        raise SystemExit(f"[submission] tarball missing: {tball}")
    rows = {}
    with tarfile.open(tball, "r:gz") as tf:
        names = set(tf.getnames())
        for m in MEMBERS:
            if m not in names:
                raise SystemExit(f"[submission] tarball lacks {m}")
            tar_bytes = tf.extractfile(m).read()
            disk_path = PAPER / m
            if not disk_path.exists():
                raise SystemExit(f"[submission] disk lacks {m}")
            d, t = sha_file(disk_path), sha16(tar_bytes)
            rows[m] = {"disk": d, "tar": t, "match": d == t}
    bad = [m for m, r in rows.items() if not r["match"]]
    if bad:
        raise SystemExit(f"[submission] tarball out of date: {bad}")
    return rows


def assemble() -> dict:
    rows = verify_tarball()
    SUB.mkdir(parents=True, exist_ok=True)
    dst = SUB / "l3-source.tar.gz"
    shutil.copyfile(TARBALL, dst)
    anc = {}
    for name in ANCILLARY:
        p = SUB / name
        anc[name] = {"exists": p.exists(), "sha16": sha_file(p) if p.exists() else None}
    missing = [n for n, r in anc.items() if not r["exists"]]
    if missing:
        raise SystemExit(f"[submission] ancillary missing: {missing}")
    manifest = {
        "schema": "l3-arxiv-submission/v1",
        "source_tarball": {"path": str(dst.relative_to(ROOT)),
                           "sha256_16": sha_file(dst),
                           "bytes": dst.stat().st_size},
        "members": rows,
        "ancillary": anc,
        "note": "arXiv source tarball is bit-identical to the manuscript on disk; "
                "upload l3-source.tar.gz as the source, main.pdf (from paper/) as the preview.",
    }
    (SUB / "submission_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return manifest


def selftest() -> None:
    """GREEN: real tarball verifies. RED: a corrupted copy must be rejected."""
    rows = verify_tarball()
    assert all(r["match"] for r in rows.values()), "GREEN: all members must match"

    # RED-1: rebuild a tarball whose main.tex differs by one byte -> verify must fail
    import tarfile, tempfile
    with tempfile.TemporaryDirectory() as td:
        bad = pathlib.Path(td) / "bad.tar.gz"
        with tarfile.open(TARBALL, "r:gz") as src, tarfile.open(bad, "w:gz") as dst:
            for info in src.getmembers():
                data = src.extractfile(info).read() if info.isfile() else None
                if info.name == "main.tex" and data is not None:
                    data = data + b"\n% tampered\n"
                    # tarfile writes exactly info.size bytes; without this the
                    # appended bytes are silently dropped and the RED test passes
                    # for the wrong reason.
                    info.size = len(data)
                dst.addfile(info, __import__("io").BytesIO(data) if data is not None else None)
        try:
            verify_tarball(bad)
        except SystemExit as e:
            assert "out of date" in str(e), f"RED-1: unexpected message: {e}"
        else:
            raise AssertionError("RED-1: tampered tarball was accepted")

    # RED-2: missing member must be rejected
    with tempfile.TemporaryDirectory() as td:
        bad2 = pathlib.Path(td) / "short.tar.gz"
        with tarfile.open(TARBALL, "r:gz") as src, tarfile.open(bad2, "w:gz") as dst:
            for info in src.getmembers():
                if info.name == "tables/tab_v3.tex":
                    continue
                data = src.extractfile(info).read() if info.isfile() else None
                dst.addfile(info, __import__("io").BytesIO(data) if data is not None else None)
        try:
            verify_tarball(bad2)
        except SystemExit as e:
            assert "lacks" in str(e), f"RED-2: unexpected message: {e}"
        else:
            raise AssertionError("RED-2: tarball without a table was accepted")

    print("SELFTEST PASS (green 1 / red 2): tarball verified; tampered and truncated copies rejected")


def main() -> int:
    if "--selftest" in sys.argv:
        selftest()
        return 0
    m = assemble()
    print(json.dumps(m, ensure_ascii=False, indent=1))
    print(f"[submission] wrote {SUB/'submission_manifest.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
