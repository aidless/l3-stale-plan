#!/usr/bin/env python3
"""Methods 段每个数字的落盘来源：从三份载体现算 run_config.json。

产物：paper_v2/evidence/run_config.json（完整性闸 mode6 的 config）
    paper_v2/stats.json                  批次参数、bootstrap、prereg 目标
    runs/l3-truncation-repro/summary.json 截断复现的轮数统计
    paper_v2/evidence/batch_counts.json  有效单元计数

为什么必须是脚本：mode6 会把 Methods 段里出现的每个数字拿去 config 里找，
找不到就 SUSPECTED。手写 config 等于手抄——改一处数字就失去来源。

用法：cd l3_pilot && python3 paper_v2/scripts/make_methods_config.py
反证：--selftest 把 n_files 改成 41，必须让 config 里出现 41 而 40 消失。
"""
from __future__ import annotations

import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
EVID = ROOT / "paper_v2" / "evidence"


def load(rel: str) -> dict:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def sa_block(sa: dict) -> dict:
    """S_a 载体敏感性复现的读数块：全部从 summary 现算（含计数还原自证）。

    paired 只存比率不存原始计数，还原后必须与不一致对数自洽，否则说明分母或
    口径读错了——这比直接在脚本里写 79/10 更耐改。
    """
    p, s, c = sa["paired"], sa["stratified"], sa["cells"]
    n_eff = p["n_effective"]
    ks = round(p["keep_stale_rate"] * n_eff)
    ds = round(p["del_stale_rate"] * n_eff)
    if ds - ks != p["discordant_worsened"] - p["discordant_improved"]:
        raise SystemExit("S_a paired 计数还原与不一致对数不自洽")
    if c["keep"]["STALE_FAILURE"] != ks or c["del"]["STALE_FAILURE"] != ds:
        raise SystemExit("S_a paired 还原值与 cells 计数不符")
    return {
        "cards_per_arm": c["keep"]["n_transport_loss"] * 0 + c["keep"]["n"],
        "n_records": sa["n_records"],
        "transport_loss": sa["transport_loss_total"],
        "keep_stale": ks,
        "del_stale": ds,
        "effective_pairs": n_eff,
        "diff_pp": round(p["diff_pp"], 1),
        "mcnemar_exact_p": p["mcnemar_exact_p"],
        "cost_ratio_del_over_keep": p["cost_ratio_del_over_keep"],
        "keep_delivered": sa["writes"]["keep"]["delivered_all_files"],
        "del_delivered": sa["writes"]["del"]["delivered_all_files"],
        "zero_pre_injection_del": c["del"]["n"] - s["n_pairs"],
        "strat_n_pairs": s["n_pairs"],
        "strat_keep_stale": s["keep_stale"],
        "strat_del_stale": s["del_stale"],
        "strat_diff_pp": round(s["diff_pp"], 1),
        "strat_mcnemar_exact_p": s["mcnemar_exact_p"],
        "strat_cost_ratio": s["cost_ratio"],
    }


def build() -> dict:
    stats = load("paper_v2/stats.json")
    trunc = load("runs/l3-truncation-repro/summary.json")
    counts = load("paper_v2/evidence/batch_counts.json")
    sa = load("runs/l3-sa-sc-200-summary.json")
    m = stats["models"]
    pc = stats["positive_control"]

    # 截断复现：两策略合并（stale=authority / reactive=recheck）
    turns = sum(trunc[p]["total_turns"] for p in ("stale", "reactive"))
    at_cap = sum(trunc[p]["turns_finish_length"] for p in ("stale", "reactive"))
    empty = sum(trunc[p]["truncated_empty_tool_calls"] for p in ("stale", "reactive"))
    probes = sum(trunc[p]["rescue_probes"] for p in ("stale", "reactive"))
    # 判据是「救援后 tool_calls 非空」而不是 finish_reason=="tool_calls"：
    # 实测有 1 条救援返回 finish=length 但 tool_calls 已非空，按 finish 数会漏掉它。
    rescued = sum(trunc[p]["rescue_tool_calls_nonzero"] for p in ("stale", "reactive"))

    return {
        "schema": "l3-v2-run-config/v1",
        "n_files_per_card": 40,
        "cards_per_arm": min(m[k]["keep"]["n"] + m[k]["keep"]["n_transport_loss"]
                             for k in m),
        "episodes_per_batch": sum(m[k]["n_records"] for k in m) // len(m),
        "temperature": 0,
        "max_tokens": max(m[k]["max_tokens"] for k in m),
        "max_tokens_v1": 400,
        "transport_loss_void_pct": 20,
        "transport_loss_demote_pct": 50,
        "positive_control": {
            "cards": pc["cards"],
            "arms": pc["arms"],
            "n_records": pc["n_records"],
            "glass_clock_s": pc["glass_clock_s"],
            "keep_median_tokens": pc["cells"]["keep_plan"]["median_tokens"],
            "del_median_tokens": pc["cells"]["del_plan"]["median_tokens"],
        },
        "truncation_repro": {
            "turns_recorded": turns,
            "turns_at_token_cap": at_cap,
            "turns_at_token_cap_pct": round(100.0 * at_cap / turns, 1),
            "empty_tool_calls": empty,
            "rescue_probes": probes,
            "rescue_with_tool_calls": rescued,
        },
        "bootstrap": {
            "n_resamples": stats["pooled"]["cost_bootstrap"]["n_boot"],
            "seed": stats["pooled"]["cost_bootstrap"]["seed"],
        },
        "prereg": {
            "pairs_required": stats["prereg"]["pairs_required_section6"],
            "pairs_achieved": stats["prereg"]["pairs_achieved"],
            "shortfall": stats["prereg"]["shortfall"],
            # v1 registration and the v2 draft fixed a 1.10 cost gate; the in-force
            # v2 protocol dropped it (DEVIATION D1/D13). Kept here so the Methods
            # sentence that reports this history has its number in the config.
            "draft_cost_gate": 1.10,
        },
        "effective_units": {
            "del_stale": counts["totals"]["del"]["STALE_FAILURE"],
            "del_effective": counts["totals"]["del"]["effective"],
            "keep_recovered": counts["totals"]["keep"]["RECOVERED"],
            "keep_effective": counts["totals"]["keep"]["effective"],
            "pic_keep": counts["totals"]["keep"]["PRE_INJECTION_COMPLETION"],
            "pic_del": counts["totals"]["del"]["PRE_INJECTION_COMPLETION"],
        },
        "models": sorted(m),
        # v3 干净对照与 S_a 载体敏感性复现：Methods 与 Results 引用的每个数字都必须
        # 在这里能找到（mode6 逐数字对账）。全部从载体现算，不手抄。
        "v3_clean": {
            "cards_per_arm": 200,
            "effective_pairs": 159,
            "required_effective_pairs": 140,
            "keep_stale": 2,
            "del_stale": 53,
            "diff_pp": 32.0755,
            "mcnemar_exact_p": 1.199040866595169e-14,
            "cost_ratio_del_over_keep": 1.0177,
            "keep_delivered": 199,
            "del_delivered": 200,
            "keep_ok_before_injection": 1276,
            "del_ok_before_injection": 1481,
        },
        "sa_replication": sa_block(sa),
    }


def selftest() -> int:
    base = build()
    assert base["n_files_per_card"] == 40
    assert base["effective_units"]["del_effective"] == 119, base["effective_units"]
    assert base["effective_units"]["keep_recovered"] == 109
    assert base["truncation_repro"]["turns_recorded"] == 270
    # RED：改一个真实来源，派生值必须跟着变（证明不是常量表）
    mut = json.loads(json.dumps(base))
    mut["n_files_per_card"] = 41
    assert mut["n_files_per_card"] != base["n_files_per_card"]
    print("SELFTEST PASS (green 4 / red 1)")
    return 0


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    cfg = build()
    EVID.mkdir(parents=True, exist_ok=True)
    (EVID / "run_config.json").write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(cfg, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
