#!/usr/bin/env python3
"""生成后两闸的声明：experiment_provenance.json 与 figure_trace.json。

为什么必须脚本生成而不是手抄：
  · figure 闸的 transformation.hash 必须是生成器脚本字节的 sha256 前缀；
  · caption_claim 必须与本 label 自己的 \\caption{} 归一后全等——手抄会漂移；
  · provenance 闸的 claims[].text 前 60 字必须能在正文里定位（扛 LaTeX 硬换行）。
三样都从盘上现取，任何一处改了，声明也要重生成。

产物：
  paper_v2/experiment_provenance.json
  paper_v2/figure_trace.json
  paper_v2/positive_control_ablation.json   （mode4 的边界工件，可复算）

用法：cd l3_pilot && python3 paper_v2/scripts/make_declarations.py
反证：--selftest 篡改一条 claim 的前半段，provenance 闸必须报 NOT_SUPPORTED。
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]          # l3_pilot/
PAPER = ROOT / "paper_v2" / "paper" / "main.tex"
OUT_PROV = ROOT / "paper_v2" / "experiment_provenance.json"
OUT_FIG = ROOT / "paper_v2" / "figure_trace.json"
OUT_PC = ROOT / "paper_v2" / "positive_control_ablation.json"

TABLES = ROOT / "paper_v2" / "scripts" / "make_tables.py"
BATCHES = [
    ("minimax", "runs/l3-v2-sc-40-minimax"),
    ("kimi", "runs/l3-v2-sc-40-kimi-lowspeed"),
    ("workbuddy", "runs/l3-v2-sc-40-workbuddy2"),
]


def sha256_prefix(p: pathlib.Path, n: int = 16) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:n]


def extracted_captions() -> dict[str, str]:
    """从稿件抽 (label -> caption 正文)，不手抄。"""
    sys.path.insert(0, str(ROOT.parent / "scripts"))
    text = PAPER.read_text(encoding="utf-8")
    out: dict[str, str] = {}
    i = 0
    while True:
        k = text.find(r"\caption{", i)
        if k < 0:
            break
        j = k + len(r"\caption{")
        depth = 1
        while depth > 0:
            if text[j] == "{":
                depth += 1
            elif text[j] == "}":
                depth -= 1
            j += 1
        body = text[k + len(r"\caption{"):j - 1]
        tail = text[j:j + 400]
        m = tail.find(r"\label{")
        label = ""
        if m >= 0:
            e = tail.find("}", m)
            label = tail[m + len(r"\label{"):e]
        if label:
            out[label] = body
        i = j
    return out


def prov_decl() -> dict:
    counts = json.loads((ROOT / "paper_v2" / "evidence" / "batch_counts.json")
                        .read_text(encoding="utf-8"))
    experiments = []
    for name, rel in BATCHES:
        experiments.append({
            "id": f"batch-{name}",
            "log": "paper_v2/evidence/verify-batches.log",
            "config": "paper_v2/evidence/run_config.json",
            "env": "paper_v2/evidence/env.txt",
            "artifact": f"{rel}/report.json",
            "status": "completed",
        })
    experiments.append({
        "id": "truncation-repro",
        "log": "runs/l3-truncation-repro/repro.log",
        "config": "paper_v2/evidence/run_config.json",
        "env": "paper_v2/evidence/env.txt",
        "artifact": "runs/l3-truncation-repro/summary.json",
        "status": "completed",
    })
    experiments.append({
        "id": "v3-clean",
        "log": "paper_v2/evidence/v3_main.json",
        "config": "paper_v2/evidence/run_config.json",
        "env": "paper_v2/evidence/env.txt",
        "artifact": "runs/l3-v3-sc-200-minimax/report.json",
        "status": "completed",
    })
    experiments.append({
        "id": "sa-carrier-replication",
        "log": "paper_v2/evidence/verify-sa.log",
        "config": "paper_v2/evidence/run_config.json",
        "env": "paper_v2/evidence/env.txt",
        "artifact": "runs/l3-sa-sc-200/report.json",
        "status": "completed",
    })
    ac = counts["abstract_counts"]
    claims = [
        {"id": "c1",
         "text": "deletion produced 119 of 119 stale-write episodes at 3.2--3.8 times the token cost",
         "experiment_ids": [f"batch-{n}" for n, _ in BATCHES]},
        {"id": "c2",
         "text": "deletion landed no accepted write: the manipulation removed the vocabulary "
                 "for acting, not a misleading belief",
         "experiment_ids": [f"batch-{n}" for n, _ in BATCHES]},
        {"id": "c3",
         "text": "The deletion arm produced no recovered episode in any batch.",
         "experiment_ids": [f"batch-{n}" for n, _ in BATCHES]},
        {"id": "c4",
         "text": "We observed 7 such episodes (3 minimax, 4 kimi, 0 workbuddy), all in the retention arm",
         "experiment_ids": [f"batch-{n}" for n, _ in BATCHES]},
        {"id": "c5",
         "text": "an 8-card positive control is run on a model that is known to expose "
                 "the contrast",
         "experiment_ids": ["batch-workbuddy"]},
        {"id": "c6",
         "text": "48 of 270 recorded turns (17.8\\%) hit the cap",
         "experiment_ids": ["truncation-repro"]},
        {"id": "c7",
         "text": "a 1600-token cap produced tool calls in 12 of 12 such turns",
         "experiment_ids": ["truncation-repro"]},
        {"id": "c8",
         "text": "Holding memory fixed and changing the prompt from authority to recheck "
                 "moved the stale-write incidence from 5 of 6 cells to 0 of 6",
         "experiment_ids": ["batch-minimax"],
         "kind": "archived"},
        {"id": "c9",
         "text": "The cost statistic is the ratio of mean per-episode tokens, "
                 "reported with a paired bootstrap interval (10000 resamples, seed 20261117).",
         "experiment_ids": [f"batch-{n}" for n, _ in BATCHES]},
        {"id": "c10",
         "text": "deletion writes 1481 times before invalidation",
         "experiment_ids": ["v3-clean"]},
        {"id": "c11",
         "text": "deletion still raises stale writes (2 of 159 versus 53 of 159, +32.1 percentage points",
         "experiment_ids": ["v3-clean"]},
        {"id": "c12",
         "text": "delivery is statistically indistinguishable (199 of 200 versus 200 of 200)",
         "experiment_ids": ["v3-clean"]},
        {"id": "c13",
         "text": "the token ratio falls to 1.0177",
         "experiment_ids": ["v3-clean"]},
        {"id": "c14",
         "text": "there deletion again raises stale writes (79 of 146 effective pairs versus 10, +47.3 points)",
         "experiment_ids": ["sa-carrier-replication"]},
        {"id": "c15",
         "text": "delivery falls for the first time (135 of 147 versus 147 of 147)",
         "experiment_ids": ["sa-carrier-replication"]},
        {"id": "c16",
         "text": "Conditioning on that subgroup gives 30 of 97 versus 5 for retention, a difference of +25.8 percentage points (exact McNemar $p=4.6\\times10^{-6}$) at a token ratio of 1.2452",
         "experiment_ids": ["sa-carrier-replication"]},
        {"id": "c17",
         "text": "Fifty of the 147 deletion-arm episodes land no accepted write before the invalidation event at all",
         "experiment_ids": ["sa-carrier-replication"]},
    ]
    return {
        "schema": "experiment-provenance-declaration/1",
        "experiment_intake_declaration": {"mode": "run_experiments"},
        "experiments": experiments,
        "claims": claims,
    }


LIMITS = [
    "The second iteration's preregistered cost target was 420 effective pairs; its three batches achieved 109",
    "all three second-iteration models were reached through one gateway with one provider configuration "
    "per model",
    "the third iteration is a single-model replication (minimax)",
    "the carrier-sensitivity replication stopped at 306 of 400 planned episodes when all three model "
    "endpoints hit rate limits in the same window",
]


def fig_decl(caps: dict[str, str]) -> dict:
    hash16 = sha256_prefix(TABLES)
    traces = [
        {
            "artifact_id": "tab-1",
            "source_data": "paper_v2/evidence/batch_counts.json",
            "transformation": {
                "script": "paper_v2/scripts/make_tables.py",
                "hash": f"sha256:{hash16}",
            },
            "caption_claim": caps["tab:1"],
            "supported_manuscript_claims": [
                "Table 1 gives the per-batch cell counts.",
                "the retention arm produced one stale-write episode across 110 effective episodes",
            ],
            "limitations": LIMITS,
        },
        {
            "artifact_id": "tab-2",
            "source_data": "paper_v2/stats.json",
            "transformation": {
                "script": "paper_v2/scripts/make_tables.py",
                "hash": f"sha256:{hash16}",
            },
            "caption_claim": caps["tab:2"],
            "supported_manuscript_claims": [
                "Table 2 gives the paired statistics.",
                "The per-model difference is between 97.5 and 100 percentage points",
            ],
            "limitations": LIMITS,
        },
        {
            "artifact_id": "tab-3",
            "source_data": "paper_v2/evidence/success_writes.json",
            "transformation": {
                "script": "paper_v2/scripts/make_tables.py",
                "hash": f"sha256:{hash16}",
            },
            "caption_claim": caps["tab:3"],
            "supported_manuscript_claims": [
                "Table 3 reports how many \\texttt{write} calls the environment accepted.",
                "The deletion arm landed no successful write in any of the three batches",
            ],
            "limitations": LIMITS,
        },
        {
            "artifact_id": "tab-4",
            "source_data": "paper_v2/evidence/v3_main.json",
            "transformation": {
                "script": "paper_v2/scripts/make_tables.py",
                "hash": f"sha256:{hash16}",
            },
            "caption_claim": caps["tab:4"],
            "supported_manuscript_claims": [
                "Table 4 gives the cell counts.",
                "Delivery rates are 199/200 in retention and 200/200 in deletion",
            ],
            "limitations": LIMITS,
        },
        {
            "artifact_id": "tab-5",
            "source_data": "runs/l3-sa-sc-200-summary.json",
            "transformation": {
                "script": "paper_v2/scripts/make_tables.py",
                "hash": f"sha256:{hash16}",
            },
            "caption_claim": caps["tab:5"],
            "supported_manuscript_claims": [
                "Table 5 gives the cell counts.",
                "The deletion arm produces stale writes in 79 of 146 effective pairs versus 10 for retention",
            ],
            "limitations": LIMITS,
        },
        {
            "artifact_id": "tab-6",
            "source_data": "runs/l3-sa-sc-200-summary.json",
            "transformation": {
                "script": "paper_v2/scripts/make_tables.py",
                "hash": f"sha256:{hash16}",
            },
            "caption_claim": caps["tab:6"],
            "supported_manuscript_claims": [
                "Conditioning on that subgroup gives 30 of 97 versus 5 for retention",
                "Fifty of the 147 deletion-arm episodes land no accepted write before the invalidation event at all",
            ],
            "limitations": LIMITS,
        },
    ]
    return {
        "schema": "figure-trace-manifest/1",
        "artifacts": [{"artifact_id": "tab-1"}, {"artifact_id": "tab-2"},
                      {"artifact_id": "tab-3"}, {"artifact_id": "tab-4"},
                      {"artifact_id": "tab-5"}, {"artifact_id": "tab-6"}],
        "figure_table_trace": traces,
    }


def pc_ablation() -> dict:
    """mode4 的边界工件：证明「删掉载体」这一步确实是被消融的机制本身。"""
    stats = json.loads((ROOT / "paper_v2" / "stats.json").read_text(encoding="utf-8"))
    pc = stats["positive_control"]
    return {
        "schema": "l3-v2-positive-control-ablation/v1",
        "ablated_object": "S_c:history carrier messages (two conversation messages)",
        "not_ablated": [
            "instruction prompt (byte-identical across arms)",
            "task card (byte-identical across arms)",
            "tool return values (audited by reading payloads)",
            "invalidation notice (byte-identical across arms)",
            "sampling parameters (temperature 0, max_tokens 1600)",
        ],
        "control_cells": pc["cells"],
        "control_cards": pc["cards"],
        "control_model": pc["model"],
        "note": "同一张卡、同一 prompt、同一工具面：只切换载体在不在历史里。",
    }


def main() -> int:
    caps = extracted_captions()
    for need in ("tab:1", "tab:2", "tab:3", "tab:4", "tab:5"):
        if need not in caps:
            raise SystemExit(f"稿件里抽不到 {need} 的 caption")
    if "--selftest" in sys.argv:
        d = prov_decl()
        paper = PAPER.read_text(encoding="utf-8")
        norm = lambda s: " ".join(str(s).split()).lower()
        ptext = norm(paper)
        ok = sum(1 for c in d["claims"] if norm(c["text"])[:60] in ptext)
        # 一条都不许脱节：开始时写成「允许一条定位不到」，正是这一条宽限让
        # c9 手写句子与稿件真实措辞不一致而没被自己的 selftest 抓住。
        assert ok == len(d["claims"]), \
            f"只有 {ok}/{len(d['claims'])} 条 claim 能在正文定位，声明与稿件脱节"
        f = fig_decl(caps)
        for t in f["figure_table_trace"]:
            assert t["transformation"]["hash"] == f"sha256:{sha256_prefix(TABLES)}"
            assert norm(t["caption_claim"]) in ptext, f"{t['artifact_id']} caption 不在稿件里"
        # RED：把一条 claim 的前半段改掉，它就不该再能在正文定位
        bad = json.loads(json.dumps(d))
        bad["claims"][0]["text"] = "completely different sentence that is not in the paper"
        assert norm(bad["claims"][0]["text"])[:60] not in ptext, "RED 未触发"
        print(f"SELFTEST PASS (green {ok + 2} / red 1)")
        return 0
    OUT_PROV.write_text(json.dumps(prov_decl(), ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    OUT_FIG.write_text(json.dumps(fig_decl(caps), ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8")
    OUT_PC.write_text(json.dumps(pc_ablation(), ensure_ascii=False, indent=2) + "\n",
                      encoding="utf-8")
    print(f"wrote {OUT_PROV.name} {OUT_FIG.name} {OUT_PC.name}")
    print(f"tables hash sha256:{sha256_prefix(TABLES)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
