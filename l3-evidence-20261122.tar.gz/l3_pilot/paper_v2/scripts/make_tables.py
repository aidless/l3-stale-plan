#!/usr/bin/env python3
"""两张表的唯一生成器：从五分重判的 rows 与 stats.json 现算 tabular 体。

产物（供 main.tex \\input，caption/label 留在稿件里，图闸按 label 对账）：
    paper_v2/paper/tab_cells.tex    各批各臂的五分类计数
    paper_v2/paper/tab_paired.tex   配对差、McNemar p、成本比与 bootstrap 区间
    paper_v2/paper/tab_writes.tex   成功写计数（注入前/后，零成功写诊断）

为什么表必须由脚本生成而不是手抄：图闸要求 transformation = {script, hash}
且 hash 与盘上生成器逐字节相符（HASH_STALE 会阻断）。手抄的表没有生成器，
任何一版数字改了都没有可追溯的来源。

用法：cd l3_pilot && python3 paper_v2/scripts/make_tables.py
反证：--selftest 篡改一条 row 的 verdict，计数必须随之变化（证明不是常量表）。
"""
from __future__ import annotations

import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]          # l3_pilot/
REJUDGED = ROOT / "runs" / "l3-v2-rejudged"
STATS = ROOT / "paper_v2" / "stats.json"
SUCCESS_WRITES = ROOT / "paper_v2" / "evidence" / "success_writes.json"
V3_EV = ROOT / "paper_v2" / "evidence" / "v3_main.json"
SA_EV = ROOT / "runs" / "l3-sa-sc-200-summary.json"
OUTDIR = ROOT / "paper_v2" / "paper" / "tables"

BATCHES = [
    ("minimax", "minimax", "l3-v2-sc-40-minimax.json"),
    ("kimi", "kimi", "l3-v2-sc-40-kimi-lowspeed.json"),
    ("workbuddy", "workbuddy", "l3-v2-sc-40-workbuddy2.json"),
]

VERDICTS = ["RECOVERED", "STALE_FAILURE", "INCOMPLETE",
            "INCOMPLETE_TRUNCATED", "PRE_INJECTION_COMPLETION"]
SHORT = {"RECOVERED": "REC", "STALE_FAILURE": "STALE", "INCOMPLETE": "INC",
         "INCOMPLETE_TRUNCATED": "TRUNC", "PRE_INJECTION_COMPLETION": "PIC"}


def cells_from_rows(rows: list[dict]) -> dict[str, dict]:
    """按臂分箱：transport_loss 单独成列，不进 n（n 是非传输样本数）。"""
    out: dict[str, dict] = {}
    for r in rows:
        arm = r["arm"]
        c = out.setdefault(arm, {"n": 0, "tl": 0, **{v: 0 for v in VERDICTS}})
        if r.get("transport_loss"):
            c["tl"] += 1
            continue
        c["n"] += 1
        v = r["new"]
        if v not in c:
            raise SystemExit(f"未知 verdict {v!r}（slug={r.get('slug')}）")
        c[v] += 1
    return out


def load_rows(fn: str) -> list[dict]:
    p = REJUDGED / fn
    d = json.loads(p.read_text(encoding="utf-8"))
    rows = d["rows"]
    if len(rows) != d["traces"]:
        raise SystemExit(f"{fn}: rows {len(rows)} != traces {d['traces']}（重判不完整）")
    return rows


def tab_cells(batches: list[tuple[str, dict[str, dict]]]) -> str:
    lines = [r"\begin{tabular}{llrrrrrrr}",
             r"\toprule",
             r"Batch & Arm & $n$ & TL & REC & STALE & INC & TRUNC & PIC \\",
             r"\midrule"]
    for i, (name, cells) in enumerate(batches):
        for j, arm in enumerate(("keep", "del")):
            c = cells[arm]
            head = (rf"\multirow{{2}}{{*}}{{{name}}}" if j == 0 else "")
            arm_tex = "keep" if arm == "keep" else "del "
            lines.append(
                f"{head} & {arm_tex} & {c['n']} & {c['tl']} & " +
                " & ".join(str(c[v]) for v in VERDICTS) + r" \\")
        if i != len(batches) - 1:
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}"]
    return "\n".join(lines) + "\n"


def _p_tex(p: float) -> str:
    """McNemar 精确 p 的排版形态：2.91\\times10^{-11}。"""
    if p == 0:
        return "0"
    exp = 0
    m = p
    while m < 1.0 and exp > -30:
        m *= 10.0
        exp -= 1
    while m >= 10.0:
        m /= 10.0
        exp += 1
    return rf"${m:.2f}\times10^{{{exp}}}$"


def tab_paired(stats: dict) -> str:
    lines = [r"\begin{tabular}{lrrrrrr}", r"\toprule",
             r"Batch & pairs & keep stale & del stale & $\Delta$ (pp) & "
             r"McNemar $p$ & cost ratio [95\% CI] \\",
             r"\midrule"]
    for name, key, _fn in BATCHES:
        m = stats["models"][key]
        p = m["paired"]
        boot = m["cost_bootstrap"]
        lines.append(
            f"{name} & {p['n_effective']} & {p['keep_stale_rate']:.3f} & "
            f"{p['del_stale_rate']:.3f} & {p['diff_pp']:.1f} & {_p_tex(p['mcnemar_exact_p'])} & "
            f"{m['cost_recomputed_sum_ratio']:.2f} "
            f"[{boot['ci95_lo']:.2f}, {boot['ci95_hi']:.2f}] \\\\")
    pl = stats["pooled"]
    pb = pl["cost_bootstrap"]
    lines += [r"\midrule",
              rf"pooled & {pl['n_pairs']} & --- & --- & --- & --- & "
              rf"{pl['cost_ratio_pooled']:.2f} [{pb['ci95_lo']:.2f}, {pb['ci95_hi']:.2f}] \\",
              r"\bottomrule", r"\end{tabular}"]
    return "\n".join(lines) + "\n"


def tab_writes(sw: dict) -> str:
    """成功写表：完全由 evidence/success_writes.json 现算，不手抄。

    三列读数分别对应 D16 的三条独立证据：
      pre ok/total  注入前有多少 write 被服务接受（del 臂全 0 → 与计划版本无关）
      post ok/total 注入后同上
      never_ok      整条 episode 一次都没写成的条数
    """
    lines = [r"\begin{tabular}{llrrrr}", r"\toprule",
             r"Batch & Arm & pre ok/total & post ok/total & never ok & $n$ \\",
             r"\midrule"]
    for name, _key, _fn in BATCHES:
        b = sw["batches"][name]
        for j, arm in enumerate(("keep", "del")):
            c = b[arm]
            head = (rf"\multirow{{2}}{{*}}{{{name}}}" if j == 0 else "")
            arm_tex = "keep" if arm == "keep" else "del "
            lines.append(
                f"{head} & {arm_tex} & "
                f"{c['writes_pre_inject_ok']}/{c['writes_pre_inject_total']} & "
                f"{c['writes_post_inject_ok']}/{c['writes_post_inject_total']} & "
                f"{c['episodes_never_ok']}/{c['n']} & {c['n']} " + r"\\")
        if name != BATCHES[-1][0]:
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}"]
    return "\n".join(lines) + "\n"


def tab_v3(v3: dict) -> str:
    """v3 干净对照表：从 evidence/v3_main.json 现算，不手抄。

    两臂唯一差异是版本映射在不在对话历史里（资源名常驻系统提示）。
    列：n / REC / STALE / delivered(搬完40) / ok-before-inj(注入前成功写) / med tok。
    """
    lines = [r"\begin{tabular}{lrrrrrr}", r"\toprule",
             r"Arm & $n$ & REC & STALE & delivered & ok before inj. & median tok. \\",
             r"\midrule"]
    for arm in ("keep", "del"):
        c = v3["cells"][arm]
        arm_tex = "keep" if arm == "keep" else "del "
        lines.append(
            f"{arm_tex} & {c['n']} & {c['RECOVERED']} & {c['STALE_FAILURE']} & "
            f"{c['delivered_all_files']}/200 & {c['ok_writes_before_injection']} & "
            f"{c['median_tokens']:,}" + r" \\")
    p = v3["paired"]
    lines += [r"\midrule",
              rf"paired & {p['n_effective_pairs']} & --- & {p['del_stale']} vs {p['keep_stale']} "
              rf"& --- & --- & $\times${p['cost_ratio_del_over_keep']:.4f} \\",
              r"\bottomrule", r"\end{tabular}"]
    return "\n".join(lines) + "\n"


def build_v3(v3: dict | None = None) -> str:
    v3 = v3 if v3 is not None else json.loads(V3_EV.read_text(encoding="utf-8"))
    if v3.get("paired", {}).get("n_effective_pairs", 0) < 140:
        raise SystemExit("v3 有效配对 < 140，不足以进表")
    return tab_v3(v3)


def tab_sa(sa: dict) -> str:
    """S_a 敏感性臂表：从 runs/l3-sa-sc-200-summary.json 现算，不手抄。

    载体换成检索语料（版本映射在语料里，资源名仍常驻系统提示，继承 v3 的 D16 修正）。
    末行是全样本配对。后处理分层（del 臂注入前是否成功写过）是对被操纵
    变量条件化，有选择性，正文不报；它移到 tab_sa_strat() 的附录表。
    """
    lines = [r"\begin{tabular}{lrrrrrr}", r"\toprule",
             r"Arm & $n$ & REC & STALE & delivered & ok before inj. & median tok. \\",
             r"\midrule"]
    for arm in ("keep", "del"):
        c = sa["cells"][arm]
        w = sa["writes"][arm]
        arm_tex = "keep" if arm == "keep" else "del "
        lines.append(
            f"{arm_tex} & {c['n']} & {c['RECOVERED']} & {c['STALE_FAILURE']} & "
            f"{w['delivered_all_files']}/{c['n']} & "
            f"{w['ok_before_injection_total']} & {c['median_tokens']:,}" + r" \\")
    p = sa["paired"]
    # paired 块只存比率，不存原始计数；从 n_effective × 比率还原，并用不一致对数
    # 自证（del_stale − keep_stale 必须等于 worsened − improved，否则分母/口径读错了）。
    n_eff = p["n_effective"]
    ks = round(p["keep_stale_rate"] * n_eff)
    ds = round(p["del_stale_rate"] * n_eff)
    if ds - ks != p["discordant_worsened"] - p["discordant_improved"]:
        raise SystemExit(
            "S_a paired 计数还原与不一致对数不自洽："
            f"ds-ks={ds - ks} != worsened-improved="
            f"{p['discordant_worsened'] - p['discordant_improved']}")
    lines += [r"\midrule",
              rf"paired & {n_eff} & --- & {ds} vs {ks} "
              rf"& --- & --- & $\times${p['cost_ratio_del_over_keep']:.4f} \\",
              r"\bottomrule", r"\end{tabular}"]
    return "\n".join(lines) + "\n"



def tab_sa_strat(sa: dict) -> str:
    """S_a 后处理分层（post-treatment subgroup）表：只进附录，描述性。

    分层对「del 臂注入前是否成功写过」这一被操纵变量条件化，是有选择的；
    正文不把它当估计量，此表仅作描述。数字现算自 summary，不手抄。
    """
    s = sa["stratified"]
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule",
             r"Subgroup & $n$ & STALE (del vs keep) & $\Delta$ pp & $\times$ tok \\",
             r"\midrule",
             rf"post-treatment & {s['n_pairs']} & {s['del_stale']} vs {s['keep_stale']} "
             rf"& +{s['diff_pp']:.1f} & $\times${s['cost_ratio']:.4f} \\",
             r"\bottomrule", r"\end{tabular}"]
    return "\n".join(lines) + "\n"


def build_sa(sa: dict | None = None) -> str:
    sa = sa if sa is not None else json.loads(SA_EV.read_text(encoding="utf-8"))
    if sa.get("paired", {}).get("n_effective", 0) < 100:
        raise SystemExit("S_a 有效配对 < 100，不足以进表")
    return tab_sa(sa)



def build_sa_strat(sa: dict | None = None) -> str:
    sa = sa if sa is not None else json.loads(SA_EV.read_text(encoding="utf-8"))
    if sa.get("stratified", {}).get("n_pairs", 0) < 50:
        raise SystemExit("S_a 分层配对 < 50，不足以进附录表")
    return tab_sa_strat(sa)


def build_writes(sw: dict | None = None) -> str:
    sw = sw if sw is not None else json.loads(SUCCESS_WRITES.read_text(encoding="utf-8"))
    for name, _k, _fn in BATCHES:
        if name not in sw["batches"]:
            raise SystemExit(f"success_writes.json 缺批 {name}")
    return tab_writes(sw)


def build(stats: dict | None = None) -> tuple[str, str, str, str, str, str]:
    stats = stats if stats is not None else json.loads(STATS.read_text(encoding="utf-8"))
    batches = [(name, cells_from_rows(load_rows(fn))) for name, _k, fn in BATCHES]
    for name, cells in batches:
        for arm in ("keep", "del"):
            if arm not in cells:
                raise SystemExit(f"{name}: 缺臂 {arm}")
    return (tab_cells(batches), tab_paired(stats), build_writes(), build_v3(),
            build_sa(), build_sa_strat())


def selftest() -> int:
    cells_tex, paired_tex, writes_tex, v3_tex, sa_tex, sa_strat_tex = build()
    assert cells_tex.count(r"\multirow{2}") == 3, cells_tex
    assert "pooled" in paired_tex
    assert "1481" in v3_tex and "1199" not in v3_tex, "v3 注入前成功写未进表"
    # RED：篡改一条 row 的 verdict，计数必须跟着变（证明表是现算的，不是常量）
    rows = load_rows(BATCHES[0][2])
    base = cells_from_rows(rows)
    mut = json.loads(json.dumps(rows))
    for r in mut:
        if r["arm"] == "keep" and r["new"] == "RECOVERED" and not r.get("transport_loss"):
            r["new"] = "INCOMPLETE"
            break
    else:
        raise SystemExit("RED 夹具无法构造：keep 臂没有 RECOVERED 行")
    after = cells_from_rows(mut)
    assert after["keep"]["RECOVERED"] == base["keep"]["RECOVERED"] - 1, \
        "RED 未触发：改了 verdict 而 REC 计数未变 ⇒ 表是常量"
    assert after["keep"]["INCOMPLETE"] == base["keep"]["INCOMPLETE"] + 1, \
        "RED 未触发：INC 计数未随篡改增加"
    # RED（第三表）：把 del 臂的成功写改成非零，表里的 never ok 必须跟着变
    sw = json.loads(SUCCESS_WRITES.read_text(encoding="utf-8"))
    base_w = tab_writes(sw)
    sw2 = json.loads(json.dumps(sw))
    sw2["batches"]["minimax"]["del"]["writes_pre_inject_ok"] = 7
    sw2["batches"]["minimax"]["del"]["episodes_never_ok"] = 33
    after_w = tab_writes(sw2)
    assert after_w != base_w, "RED 未触发：改了成功写而表未变 ⇒ 表是常量"
    assert "0/224" in base_w and "7/224" in after_w, "RED 未触发：注入前成功写列未随之改变"
    # RED（第四表）：把 del 的注入前成功写清零，表必须跟着变
    v3 = json.loads(V3_EV.read_text(encoding="utf-8"))
    base_v = tab_v3(v3)
    v3b = json.loads(json.dumps(v3))
    v3b["cells"]["del"]["ok_writes_before_injection"] = 0
    v3b["cells"]["del"]["delivered_all_files"] = 123
    assert tab_v3(v3b) != base_v, "RED 未触发：改了 v3 读数而表未变 ⇒ 常量表"
    assert "1481" in base_v and "0 & 16,086" in tab_v3(v3b), "RED 未触发：v3 注入前列未变"
    # RED（第五、六表）：篡改 paired 成本比与分层读数，各自的表必须跟着变
    sa = json.loads(SA_EV.read_text(encoding="utf-8"))
    base_s = tab_sa(sa)
    base_ss = tab_sa_strat(sa)
    sa2 = json.loads(json.dumps(sa))
    sa2["paired"]["cost_ratio_del_over_keep"] = 9.9999
    assert tab_sa(sa2) != base_s, "RED 未触发：改了 S_a paired 读数而表未变 ⇒ 常量表"
    assert "1.2622" in base_s and "9.9999" in tab_sa(sa2), "RED 未触发：paired 成本比未变"
    sa3 = json.loads(json.dumps(sa))
    sa3["stratified"]["del_stale"] = 0
    assert tab_sa_strat(sa3) != base_ss, "RED 未触发：改了分层读数而附录表未变 ⇒ 常量表"
    assert "30 vs 5" in base_ss and "0 vs 5" in tab_sa_strat(sa3), "RED 未触发：分层行未变"
    assert base_s.count("paired") == 1 and "stratified" not in base_s, base_s
    assert "post-treatment" in base_ss, base_ss
    print(f"SELFTEST PASS (green 6 / red 6)  cells={len(cells_tex.splitlines())} "
          f"paired={len(paired_tex.splitlines())} writes={len(writes_tex.splitlines())} "
          f"v3={len(v3_tex.splitlines())} sa={len(sa_tex.splitlines())} "
          f"sa_strat={len(sa_strat_tex.splitlines())} lines")
    return 0


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    cells_tex, paired_tex, writes_tex, v3_tex, sa_tex, sa_strat_tex = build()
    OUTDIR.mkdir(parents=True, exist_ok=True)
    (OUTDIR / "tab_cells.tex").write_text(cells_tex, encoding="utf-8")
    (OUTDIR / "tab_paired.tex").write_text(paired_tex, encoding="utf-8")
    (OUTDIR / "tab_writes.tex").write_text(writes_tex, encoding="utf-8")
    (OUTDIR / "tab_v3.tex").write_text(v3_tex, encoding="utf-8")
    (OUTDIR / "tab_sa.tex").write_text(sa_tex, encoding="utf-8")
    (OUTDIR / "tab_sa_strat.tex").write_text(sa_strat_tex, encoding="utf-8")
    print(cells_tex)
    print(paired_tex)
    print(writes_tex)
    print(v3_tex)
    print(sa_tex)
    print(sa_strat_tex)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
