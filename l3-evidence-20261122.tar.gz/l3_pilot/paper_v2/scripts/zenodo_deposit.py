#!/usr/bin/env python3
"""Deposit the evidence bundle to Zenodo via the REST API.

Never publishes by default: the first call creates a deposition and uploads
files but leaves it in "unsubmitted" state so the record can be inspected on
the web before it goes public. Pass --publish to actually mint the DOI.
--sandbox targets sandbox.zenodo.org so the whole flow can be rehearsed
without creating a permanent record.

  ZENODO_SANDBOX=1 ZENODO_TOKEN=<tok> python3 zenodo_deposit.py --files a.tar.gz
  ZENODO_TOKEN=<tok> python3 zenodo_deposit.py --files a.tar.gz b --publish

  python3 zenodo_deposit.py --selftest   # RED/GREEN against a local stub

Requires a token with deposit:write scope. The token is read from the
environment only; it is never written to any file by this script.
"""
import json
import os
import pathlib
import sys
import urllib.error
import urllib.request

SANDBOX = "https://sandbox.zenodo.org/api"
PROD = "https://zenodo.org/api"

META = {
    "metadata": {
        "title": "Evidence bundle: What deleting an agent's memory actually removes",
        "upload_type": "dataset",
        "description": (
            "Per-episode judgements and traces, preregistrations, deviation log "
            "and analysis code for a three-iteration preregistered study of memory "
            "deletion in agents, plus a carrier-sensitivity replication. Verify "
            "file integrity with SHA256SUMS."
        ),
        "creators": [{"name": "Liu, Zewen",
                      "orcid": "0009-0003-2981-9888"}],
        "license": "cc-by-4.0",
        "keywords": ["agent memory", "preregistration", "replication",
                     "stale plan", "LLM evaluation"],
    }
}


def base() -> str:
    return SANDBOX if os.environ.get("ZENODO_SANDBOX", "").strip() not in ("", "0") else PROD


def token() -> str:
    t = os.environ.get("ZENODO_TOKEN", "").strip()
    if not t:
        raise SystemExit("[zenodo] ZENODO_TOKEN is not set "
                         "(create a token with deposit:write at zenodo.org/account/settings/applications)")
    return t


def call(method: str, url: str, tok: str, data: bytes | None = None,
         ctype: str = "application/json") -> dict:
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {tok}")
    if data is not None:
        req.add_header("Content-Type", ctype)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            body = r.read()
            return json.loads(body) if body else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:400]
        raise SystemExit(f"[zenodo] HTTP {e.code} on {method} {url}\n{detail}")


def upload(files: list[pathlib.Path], publish: bool = False,
           api: str | None = None, tok: str | None = None) -> dict:
    api = api or base()
    tok = tok or token()
    dep = call("POST", f"{api}/deposit/depositions", tok, b"{}")
    dep_id = dep["id"]
    bucket = dep.get("links", {}).get("bucket")
    for f in files:
        if not f.exists():
            raise SystemExit(f"[zenodo] missing file: {f}")
        if bucket:
            req = urllib.request.Request(f"{bucket}/{f.name}",
                                         data=f.read_bytes(), method="PUT")
            req.add_header("Authorization", f"Bearer {tok}")
            req.add_header("Content-Type", "application/octet-stream")
            try:
                with urllib.request.urlopen(req, timeout=600) as r:
                    r.read()
            except urllib.error.HTTPError as e:
                raise SystemExit(f"[zenodo] upload HTTP {e.code} for {f.name}: "
                                 f"{e.read().decode('utf-8','replace')[:300]}")
        else:                                    # legacy files API fallback
            call("POST", f"{api}/deposit/depositions/{dep_id}/files", tok,
                 json.dumps({"filename": f.name}).encode())
    call("PUT", f"{api}/deposit/depositions/{dep_id}", tok,
         json.dumps(META).encode())
    if publish:
        out = call("POST", f"{api}/deposit/depositions/{dep_id}/actions/publish", tok)
        return {"id": dep_id, "published": True, "doi": out.get("doi"),
                "url": out.get("links", {}).get("html")}
    return {"id": dep_id, "published": False,
            "url": dep.get("links", {}).get("html"),
            "note": "Draft only. Inspect on the web, then re-run with --publish to mint the DOI."}


def selftest() -> None:
    """RED/GREEN against a local stub server — never touches Zenodo."""
    import http.server, tempfile, threading

    state = {"published": False, "uploads": []}

    class H(http.server.BaseHTTPRequestHandler):
        def _send(self, obj, code=200):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            if self.path.endswith("/actions/publish"):
                state["published"] = True
                return self._send({"doi": "10.5281/zenodo.TEST", "links": {"html": "x"}})
            return self._send({"id": 42, "links": {"bucket": f"http://127.0.0.1:{PORT}/bucket/42",
                                                  "html": "http://draft"}})

        def do_PUT(self):
            if "/bucket/" in self.path:
                state["uploads"].append(self.path.rsplit("/", 1)[-1])
                return self._send({})
            return self._send({})

        def log_message(self, *a):
            pass

    srv = http.server.HTTPServer(("127.0.0.1", 0), H)
    PORT = srv.server_address[1]
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    try:
        with tempfile.TemporaryDirectory() as td:
            f = pathlib.Path(td) / "bundle.tar.gz"
            f.write_bytes(b"payload")
            api = f"http://127.0.0.1:{PORT}/api"
            GREEN = upload([f], publish=False, api=api, tok="dummy")
            assert GREEN["published"] is False and GREEN["id"] == 42, "GREEN: draft upload"
            assert state["uploads"] == ["bundle.tar.gz"], "GREEN: file reached bucket"
            assert state["published"] is False, "GREEN: must not publish without --publish"
            RED = upload([f], publish=True, api=api, tok="dummy")
            assert RED["published"] is True and state["published"] is True, "RED: --publish must publish"
            try:
                upload([pathlib.Path(td) / "nope.bin"], api=api, tok="dummy")
            except SystemExit as e:
                assert "missing file" in str(e), f"RED: unexpected {e}"
            else:
                raise AssertionError("RED: missing file was accepted")
    finally:
        srv.shutdown()
    print("SELFTEST PASS (green 2 / red 1): draft upload by default; --publish mints the DOI; missing file rejected")


def main() -> int:
    args = sys.argv[1:]
    if "--selftest" in args:
        selftest()
        return 0
    if "--files" not in args:
        print(__doc__)
        return 2
    i = args.index("--files")
    files, j = [], i + 1
    while j < len(args) and not args[j].startswith("--"):
        files.append(pathlib.Path(args[j]))
        j += 1
    out = upload(files, publish="--publish" in args)
    print(json.dumps(out, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
