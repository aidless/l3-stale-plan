#!/usr/bin/env python3
"""三批的逐条复核：从 judgements 与重判件现算五分类计数，落 batch_counts.json + 日志。

产物（供三闸引用，是稿件数字的落盘日志）：
    paper_v2/evidence/batch_counts.json   每批每臂的 verdict 计数与汇总
    paper_v2/evidence/verify-batches.log  本脚本的原始输出（含 exit_code 依据）

为什么需要它：完整性闸的 mode1 要求「每条数值结果都挂一份落盘 log 且 exit_code=0」。
稿件里的 119/119、109/110 是**计数**，必须有能重跑出它们的记录，否则闸看见的只是
作者自述。本脚本同时做一件更强的事：把**原始四分判定**（judgements/）与**五分重判**
（runs/l3-v2-rejudged/）逐条对账 —— 重判只允许把 INCOMPLETE 切成 INC/TRUNC/PIC，
STALE 与 REC 的计数必须一字不变；transport_loss 行一律不进分母（预注册 §6）。

用法：cd l3_pilot && python3 paper_v2/scripts/verify_batches.py
反证：--selftest 篡改一条 verdict 必须让计数变化（证明不是常量）；
      篡改一条 STALE→REC 必须让对账断言失败（证明对账不是装饰）。
"""
from __future__ import annotations

import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]          # l3_pilot/
EVID = ROOT / "paper_v2" / "evidence"
REJUDGED = ROOT / "runs" / "l3-v2-rejudged"

BATCHES = [
    ("minimax", "runs/l3-v2-sc-40-minimax", "l3-v2-sc-40-minimax.json"),
    ("kimi", "runs/l3-v2-sc-40-kimi-lowspeed", "l3-v2-sc-40-kimi-lowspeed.json"),
    ("workbuddy", "runs/l3-v2-sc-40-workbuddy2", "l3-v2-sc-40-workbuddy2.json"),
]

VERDICTS = ["RECOVERED", "STALE_FAILURE", "INCOMPLETE",
            "INCOMPLETE_TRUNCATED", "PRE_INJECTION_COMPLETION"]
FOUR = ["RECOVERED", "STALE_FAILURE", "INCOMPLETE"]


def load_raw(rel: str) -> list[dict]:
    """原始判定：四分口径，transport_loss 标记在行上。"""
    d = ROOT / rel
    files = sorted((d / "judgements").glob("*.json"))
    rows = [json.loads(p.read_text(encoding="utf-8")) for p in files]
    n_tr = len(list((d / "traces").glob("*.json")))
    if n_tr != len(rows):
        raise SystemExit(f"{rel}: traces {n_tr} != judgements {len(rows)}（载体不齐）")
    return rows


def load_rejudged(fn: str) -> list[dict]:
    """五分重判：rows[i] = {slug, arm, old, new, transport_loss, ...}。"""
    p = REJUDGED / fn
    d = json.loads(p.read_text(encoding="utf-8"))
    rows = d["rows"]
    if len(rows) != d["traces"]:
        raise SystemExit(f"{fn}: rows {len(rows)} != traces {d['traces']}（重判不完整）")
    return rows


def arm_of(row: dict) -> str:
    return "keep" if "__keep__" in str(row.get("slug", "")) else "del"


def tally(rows: list[dict], key: str, universe: list[str]) -> dict[str, dict]:
    """按臂分箱。transport_loss 行只计 tl，不进 n（不进任何分母）。"""
    out: dict[str, dict] = {}
    for r in rows:
        arm = arm_of(r)
        c = out.setdefault(arm, {"n": 0, "tl": 0, **{v: 0 for v in universe}})
        if r.get("transport_loss"):
            c["tl"] += 1
            continue
        c["n"] += 1
        v = str(r.get(key))
        if v not in c:
            raise SystemExit(f"未知 verdict {v!r}（slug={r.get('slug')}）")
        c[v] += 1
    return out


def effective(c: dict) -> int:
    return c["RECOVERED"] + c["STALE_FAILURE"]


def reconcile(raw: dict[str, dict], rej: dict[str, dict]) -> None:
    """四分 vs 五分：只有 INCOMPLETE 允许被切开，STALE/REC 必须逐臂相等。"""
    for arm in ("keep", "del"):
        if arm not in raw or arm not in rej:
            raise SystemExit(f"对账缺臂：raw={sorted(raw)} rej={sorted(rej)}")
        for v in ("RECOVERED", "STALE_FAILURE"):
            if raw[arm][v] != rej[arm][v]:
                raise SystemExit(
                    f"对账失败（{arm}/{v}）：原始 {raw[arm][v]} != 重判 {rej[arm][v]}"
                    "——重判只允许切 INCOMPLETE")
        split = (rej[arm]["INCOMPLETE"] + rej[arm]["INCOMPLETE_TRUNCATED"]
                 + rej[arm]["PRE_INJECTION_COMPLETION"])
        if raw[arm]["INCOMPLETE"] != split:
            raise SystemExit(
                f"对账失败（{arm}/INCOMPLETE）：原始 {raw[arm]['INCOMPLETE']} != 切分后合计 {split}")
        if raw[arm]["n"] != rej[arm]["n"]:
            raise SystemExit(f"对账失败（{arm}/n）：{raw[arm]['n']} != {rej[arm]['n']}")


def build() -> dict:
    out = {"schema": "l3-v2-batch-counts/v1", "batches": {}, "verdicts": VERDICTS}
    tot = {"keep": {"n": 0, "effective": 0, "tl": 0, "RECOVERED": 0, "STALE_FAILURE": 0,
                    "PRE_INJECTION_COMPLETION": 0},
           "del": {"n": 0, "effective": 0, "tl": 0, "RECOVERED": 0, "STALE_FAILURE": 0,
                   "PRE_INJECTION_COMPLETION": 0}}
    for name, rel, fn in BATCHES:
        raw = tally(load_raw(rel), "verdict", FOUR)
        rej = tally(load_rejudged(fn), "new", VERDICTS)
        reconcile(raw, rej)
        for arm in ("keep", "del"):
            rej[arm]["effective"] = effective(rej[arm])
            for k in ("n", "effective", "tl", "RECOVERED", "STALE_FAILURE",
                      "PRE_INJECTION_COMPLETION"):
                tot[arm][k] += rej[arm][k]
        out["batches"][name] = {
            "run_dir": rel, "rejudged": str(REJUDGED / fn),
            "n_records": raw["keep"]["n"] + raw["del"]["n"] + raw["keep"]["tl"] + raw["del"]["tl"],
            "raw": raw, "rejudged": rej,
        }
    out["totals"] = tot
    # 稿件摘要里的两条计数 claim，直接从 totals 现算，避免手抄
    out["abstract_counts"] = {
        "del_effective_stale": f"{tot['del']['STALE_FAILURE']}/{tot['del']['effective']}",
        "keep_effective_recovered": f"{tot['keep']['RECOVERED']}/{tot['keep']['effective']}",
        "del_stale_num": tot["del"]["STALE_FAILURE"],
        "del_effective_den": tot["del"]["effective"],
        "keep_rec_num": tot["keep"]["RECOVERED"],
        "keep_effective_den": tot["keep"]["effective"],
        "pic_total": tot["keep"]["PRE_INJECTION_COMPLETION"] + tot["del"]["PRE_INJECTION_COMPLETION"],
    }
    return out


def selftest() -> int:
    base = build()
    # GREEN：与稿件摘要一致
    assert base["abstract_counts"]["del_effective_stale"] == "119/119", \
        base["abstract_counts"]
    assert base["abstract_counts"]["keep_effective_recovered"] == "109/110", \
        base["abstract_counts"]
    assert base["totals"]["keep"]["PRE_INJECTION_COMPLETION"] == 7, base["totals"]["keep"]
    assert base["totals"]["del"]["PRE_INJECTION_COMPLETION"] == 0, base["totals"]["del"]

    # RED-1：改一条 del 的 STALE→INCOMPLETE，计数必须跟着动（证明表是现算的）
    rows = load_rejudged(BATCHES[0][2])
    b = tally(rows, "new", VERDICTS)
    mut = [dict(r) for r in rows]
    for r in mut:
        if arm_of(r) == "del" and r.get("new") == "STALE_FAILURE" and not r.get("transport_loss"):
            r["new"] = "INCOMPLETE"
            break
    else:
        raise SystemExit("RED 夹具构造失败：del 臂没有非 TL 的 STALE_FAILURE")
    a = tally(mut, "new", VERDICTS)
    assert a["del"]["STALE_FAILURE"] == b["del"]["STALE_FAILURE"] - 1, \
        "RED 未触发：改 verdict 而计数不变 ⇒ 计数是常量"

    # RED-2：改一条 STALE→RECOVERED，四分/五分对账必须失败（证明对账不是装饰）
    raw_c = tally(load_raw(BATCHES[0][1]), "verdict", FOUR)
    raw_mut = {k: dict(v) for k, v in raw_c.items()}
    raw_mut["del"]["STALE_FAILURE"] -= 1
    raw_mut["del"]["RECOVERED"] += 1
    try:
        reconcile(raw_mut, tally(rows, "new", VERDICTS))
    except SystemExit as exc:
        assert "对账失败" in str(exc), exc
    else:
        raise SystemExit("RED 未触发：把 STALE 改成 REC 而对账仍然通过 ⇒ 对账是装饰")
    print("SELFTEST PASS (green 4 / red 2)")
    return 0


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    data = build()
    EVID.mkdir(parents=True, exist_ok=True)
    (EVID / "batch_counts.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    t = data["totals"]
    lines = ["l3-v2 batch verification — recomputed from judgements + rejudged carriers", ""]
    for name, b in data["batches"].items():
        k, d = b["rejudged"]["keep"], b["rejudged"]["del"]
        lines.append(
            f"{name:10s} n_records={b['n_records']:3d} "
            f"keep[REC={k['RECOVERED']:2d} STALE={k['STALE_FAILURE']:2d} "
            f"INC={k['INCOMPLETE']:2d} TRUNC={k['INCOMPLETE_TRUNCATED']:2d} "
            f"PIC={k['PRE_INJECTION_COMPLETION']:2d} TL={k['tl']:2d}] "
            f"del[REC={d['RECOVERED']:2d} STALE={d['STALE_FAILURE']:2d} "
            f"INC={d['INCOMPLETE']:2d} PIC={d['PRE_INJECTION_COMPLETION']:2d} TL={d['tl']:2d}]")
    lines += ["",
              f"del  effective={t['del']['effective']}  STALE={t['del']['STALE_FAILURE']}",
              f"keep effective={t['keep']['effective']}  REC={t['keep']['RECOVERED']}",
              f"PIC  keep={t['keep']['PRE_INJECTION_COMPLETION']} del={t['del']['PRE_INJECTION_COMPLETION']}",
              f"abstract: del {data['abstract_counts']['del_effective_stale']} stale, "
              f"keep {data['abstract_counts']['keep_effective_recovered']} recovered",
              "reconcile: four-class vs five-class OK (STALE/REC unchanged)",
              "EXIT 0"]
    text = "\n".join(lines) + "\n"
    (EVID / "verify-batches.log").write_text(text, encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
