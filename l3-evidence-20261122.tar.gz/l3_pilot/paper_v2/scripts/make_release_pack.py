#!/usr/bin/env python3
"""Assemble a publication-ready evidence bundle for the L3 study.

Packs the carriers the paper cites (per-episode judgements + traces for every
batch), the analysis code, the three governing documents, and the arXiv source
tarball into one archive with per-file SHA-256, a top-level SHA256SUMS, and a
CITATION.cff. Emits the exact commands to publish it on GitHub Releases or
Zenodo; it never uploads anything by itself.

  python3 paper_v2/scripts/make_release_pack.py            # build bundle
  python3 paper_v2/scripts/make_release_pack.py --selftest  # RED/GREEN on the verifier
  python3 paper_v2/scripts/make_release_pack.py --verify <tar.gz>

Refuses to build if any cited batch is missing or if a carrier does not match
the count recorded in its report.json (the same rule verify_evidence_chain.py
enforces).
"""
import hashlib
import json
import pathlib
import sys
import tarfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[2]      # l3_pilot/
PROJECT = ROOT.parent                                   # research-plan-20261108/
OUT = ROOT / "paper_v2" / "submission"

# batches the manuscript reports on
BATCHES = {
    "l3-runA-50x2x3": 300,
    "l3-v2-sc-40-minimax": 80,
    "l3-v2-sc-40-kimi-lowspeed": 80,
    "l3-v2-sc-40-workbuddy2": 80,
    "l3-v3-sc-200-minimax": 400,
    "l3-truncation-repro": None,       # diagnostic, count not fixed
    "l3-v3-pc40-minimax": 80,
    "l3-v2-positive-control": 16,
    "l3-v2-rejudged": None,
    "l3-v2-d16": None,
    "l3-fact-240x6x2-analysis": None,
    "l3-factorial-3x2-smoke": None,
    "l3-sa-sc-40": 80,                 # carrier-sensitivity pilot (Table 5 source)
    "l3-sa-sc-200": 306,               # carrier-sensitivity replication (stopped at 306/400)
}
# governing documents: DEVIATION lives at project root, the rest under l3_pilot/
DOCS_PROJECT = ["DEVIATION_L3.md", "PREREG_L3.md"]
DOCS_PILOT = ["REPRODUCE_CHECKS.md", "L3_V3_PREREG.md",
              "L3_V2_PREREG_REVIEWABLE.md"]
# paper-side evidence the tables are generated from
PAPER_EVIDENCE = ["paper_v2/stats.json",
                  "paper_v2/evidence/v3_main.json",
                  "paper_v2/evidence/batch_counts.json",
                  "paper_v2/evidence/success_writes.json",
                  "paper_v2/evidence/run_config.json",
                  "paper_v2/evidence/verify-sa.log",
                  "runs/l3-sa-sc-200-summary.json",
                  "runs/l3-sa-sc-40-stratified.json",
                  "runs/sa_census.json",
                  "paper_v2/submission/submission_manifest.json"]


def sha256_file(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def check_batch(name: str, expect: int | None) -> dict:
    d = ROOT / "runs" / name
    if not d.is_dir():
        raise SystemExit(f"[release] batch missing: runs/{name}")
    n_j = len(list((d / "judgements").glob("*.json"))) if (d / "judgements").is_dir() else 0
    n_t = len(list((d / "traces").glob("*.json"))) if (d / "traces").is_dir() else 0
    rep = d / "report.json"
    n_rec = None
    if rep.exists():
        try:
            n_rec = json.loads(rep.read_text()).get("n_records")
        except Exception:
            n_rec = None
    # a batch may carry judgements (verdicts) or only traces (positive control
    # was produced before the judgement layer existed); accept either as the
    # carrier count, but never accept a disagreement between them.
    n_carrier = n_j if n_j else n_t
    if n_j and n_t and n_j != n_t:
        raise SystemExit(
            f"[release] carrier mismatch runs/{name}: judgements={n_j} traces={n_t}")
    if expect is not None and n_carrier != expect:
        raise SystemExit(
            f"[release] carrier mismatch runs/{name}: carriers={n_carrier} "
            f"(judgements={n_j} traces={n_t}) expected={expect}")
    if n_rec is not None and n_carrier != n_rec:
        raise SystemExit(
            f"[release] report disagrees with carriers runs/{name}: "
            f"n_records={n_rec} carriers={n_carrier}")
    return {"batch": name, "judgements": n_j, "traces": n_t,
            "n_records": n_rec, "agree": (n_rec is None or n_rec == n_carrier)}


def collect() -> list[pathlib.Path]:
    files: list[pathlib.Path] = []
    for name in BATCHES:
        d = ROOT / "runs" / name
        for sub in ("judgements", "traces"):
            files.extend(sorted((d / sub).glob("*.json")) if (d / sub).is_dir() else [])
        # every top-level artefact of the batch directory (analysis JSONs such as
        # l3-v2-rejudged/*.json and l3-v2-d16/*.json live here, not under judgements/)
        for p in sorted(d.glob("*")):
            if p.is_file() and p.suffix in (".json", ".md", ".py", ".log", ".txt"):
                files.append(p)
    files.extend(ROOT / n for n in sorted(p.name for p in ROOT.glob("*.py")))
    files.extend(ROOT / "paper_v2" / "scripts" / n
                 for n in sorted(p.name for p in (ROOT / "paper_v2" / "scripts").glob("*.py")))
    files.extend(ROOT / "paper_v2" / p for p in
                 ("recompute_stats.py", "paper/main.tex", "paper/main.pdf",
                  "paper/main.bbl", "paper/references.bib",
                  "paper/tables/tab_cells.tex", "paper/tables/tab_paired.tex",
                  "paper/tables/tab_writes.tex", "paper/tables/tab_v3.tex",
                  "paper/tables/tab_sa.tex"))
    files.extend(PROJECT / d for d in DOCS_PROJECT)
    files.extend(ROOT / d for d in DOCS_PILOT)
    files.extend(ROOT / e for e in PAPER_EVIDENCE)
    files.extend([OUT / "cover_letter.md", OUT / "REPRODUCIBILITY.md",
                  OUT / "l3-source.tar.gz"])
    return [f for f in files if f.exists()]


def citation() -> str:
    return """cff-version: 1.2.0
message: "If you use this evidence bundle, cite the paper it accompanies."
title: "What deleting an agent's memory actually removes: evidence from three preregistered iterations"
authors:
  - family-names: "Liu"
    given-names: "Zewen"
    orcid: "https://orcid.org/0009-0003-2981-9888"
version: "1.0.0"
date-released: "2026-11-21"
repository-code: "https://github.com/aidless"
abstract: "All per-episode judgements, traces, preregistrations, and deviation log for a three-iteration preregistered study of memory deletion in agents, plus a carrier-sensitivity replication."
"""


def build(batches: dict | None = None) -> pathlib.Path:
    spec = BATCHES if batches is None else batches
    rows = [check_batch(n, e) for n, e in spec.items()]
    files = collect()
    if not files:
        raise SystemExit("[release] nothing to pack")
    OUT.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d", time.gmtime())
    tar_path = OUT / f"l3-evidence-{stamp}.tar.gz"
    manifest = {"schema": "l3-evidence-bundle/v1",
                "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "batches": rows, "n_files": len(files), "files": {}}
    total = 0
    with tarfile.open(tar_path, "w:gz") as tf:
        for i, p in enumerate(sorted(files)):
            rel = p.relative_to(PROJECT) if p.is_relative_to(PROJECT) else p.relative_to(ROOT)
            arc = str(rel).replace("\\", "/")
            tf.add(p, arcname=arc)
            h = sha256_file(p)
            manifest["files"][arc] = {"sha256": h, "bytes": p.stat().st_size}
            total += p.stat().st_size
        cf = OUT / "CITATION.cff"
        cf.write_text(citation(), encoding="utf-8")
        tf.add(cf, arcname="CITATION.cff")
        manifest["files"]["CITATION.cff"] = {"sha256": sha256_file(cf),
                                             "bytes": cf.stat().st_size}
    # n_files 必须与 tarball members / SHA256SUMS 行数一致：CITATION.cff 是循环之后
    # 才补进 manifest 的，若沿用写循环前的 len(files)，README 会少报一个文件（实测
    # 3011 vs 3012），而校验者 sha256sum -c 会看到 3012 行 OK。
    manifest["n_files"] = len(manifest["files"])
    manifest["uncompressed_bytes"] = total
    manifest["tarball"] = {"path": tar_path.name, "sha256": sha256_file(tar_path),
                           "bytes": tar_path.stat().st_size}
    (OUT / "evidence_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    sums = "".join(f"{v['sha256']}  {k}\n" for k, v in sorted(manifest["files"].items()))
    assert len(sums.splitlines()) == manifest["n_files"], (
        f"SHA256SUMS 行数 {len(sums.splitlines())} != n_files {manifest['n_files']}")
    (OUT / "SHA256SUMS").write_text(sums, encoding="utf-8")
    _publish_commands(tar_path, manifest)
    return tar_path


def _publish_commands(tar_path: pathlib.Path, m: dict) -> None:
    tag = "l3-evidence-v1.0.0"
    text = f"""# Publishing commands (run manually; this script never uploads)

Bundle: `{tar_path.name}` ({m['tarball']['bytes']} B, {m['n_files']} files, sha256 `{m['tarball']['sha256']}`)

Verify integrity by extracting the archive first — the paths in `SHA256SUMS` are
relative to the archive root (the checksum file itself sits beside the archive,
not inside it):

```bash
mkdir -p /tmp/l3-evidence-verify && cd /tmp/l3-evidence-verify
tar xzf {OUT / tar_path.name}
sha256sum -c {OUT / "SHA256SUMS"}   # all OK
```

## Option A — GitHub Release (gh CLI is authenticated as `aidless`)

```bash
cd {OUT}
gh release create {tag} {tar_path.name} SHA256SUMS evidence_manifest.json \\
  --title "L3 evidence bundle v1.0.0" \\
  --notes "Per-episode judgements, traces, preregistrations and deviation log for the three-iteration memory-deletion study. Verify with: sha256sum -c SHA256SUMS"
```

## Option B — Zenodo (needs ZENODO_TOKEN with deposit:write; sandbox first)

```bash
ZENODO_SANDBOX=1 ZENODO_TOKEN=<token> python3 paper_v2/scripts/zenodo_deposit.py \\
  --files {tar_path.name} SHA256SUMS evidence_manifest.json
ZENODO_TOKEN=<token> python3 paper_v2/scripts/zenodo_deposit.py \\
  --files {tar_path.name} SHA256SUMS evidence_manifest.json --publish
```

Both paths are irreversible once published. Verify `sha256sum -c SHA256SUMS` on the
downloaded archive before trusting it.
"""
    (OUT / "README_RELEASE.md").write_text(text, encoding="utf-8")


def verify(archive: pathlib.Path) -> dict:
    """Re-open the bundle and check每 file against SHA256SUMS."""
    sums_path = archive.parent / "SHA256SUMS"
    if not sums_path.exists():
        raise SystemExit(f"[release] SHA256SUMS missing beside {archive}")
    want = {}
    for line in sums_path.read_text().splitlines():
        if not line.strip():
            continue
        h, name = line.split("  ", 1)
        want[name.strip()] = h
    got = {}
    with tarfile.open(archive, "r:gz") as tf:
        for info in tf.getmembers():
            if info.isfile():
                got[info.name] = hashlib.sha256(tf.extractfile(info).read()).hexdigest()
    missing = sorted(set(want) - set(got))
    extra = sorted(set(got) - set(want))
    bad = sorted(k for k in want if k in got and want[k] != got[k])
    if missing or extra or bad:
        raise SystemExit(f"[release] verification failed missing={missing[:3]} "
                         f"extra={extra[:3]} mismatch={bad[:3]}")
    return {"files": len(got), "ok": True}


def selftest() -> None:
    green = verify(build())
    assert green["ok"] and green["files"] >= 100, "GREEN: bundle must verify"

    # RED-1: corrupt one byte inside the archive -> verify must reject
    import tempfile, shutil
    with tempfile.TemporaryDirectory() as td:
        tdp = pathlib.Path(td)
        src = max((OUT).glob("l3-evidence-*.tar.gz"), key=lambda p: p.stat().st_mtime)
        shutil.copyfile(src, tdp / src.name)
        shutil.copyfile(OUT / "SHA256SUMS", tdp / "SHA256SUMS")
        bad = tdp / src.name
        with tarfile.open(src, "r:gz") as a, tarfile.open(bad, "w:gz") as b:
            for info in a.getmembers():
                data = a.extractfile(info).read() if info.isfile() else None
                if info.name.endswith("report.json") and data is not None:
                    data = data.replace(b'"n_records": 80', b'"n_records": 81', 1)
                    info.size = len(data)
                b.addfile(info, __import__("io").BytesIO(data) if data is not None else None)
        try:
            verify(bad)
        except SystemExit as e:
            assert "verification failed" in str(e), f"RED-1: unexpected: {e}"
        else:
            raise AssertionError("RED-1: corrupted bundle accepted")

    # RED-2: a cited batch that does not exist on disk -> build must refuse
    try:
        build({"l3-does-not-exist": 10})
    except SystemExit as e:
        assert "batch missing" in str(e), f"RED-2: unexpected: {e}"
    else:
        raise AssertionError("RED-2: build accepted a missing cited batch")

    print("SELFTEST PASS (green 1 / red 2): bundle verifies; corrupted and incomplete bundles rejected")


def main() -> int:
    args = sys.argv[1:]
    if "--selftest" in args:
        selftest()
        return 0
    if "--verify" in args:
        i = args.index("--verify")
        print(json.dumps(verify(pathlib.Path(args[i + 1])), indent=1))
        return 0
    p = build()
    print(f"[release] built {p} ({p.stat().st_size} B)")
    print(f"[release] published commands in {OUT/'README_RELEASE.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
