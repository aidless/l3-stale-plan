#!/usr/bin/env python3
"""图表/表格视觉核验（skill §3 十条 checklist 的本地可执行版）。

为什么不用 modlens_read_image：本机 `npx @liustack/modlens doctor` 六个 provider
全部 `[!!]`（antigravity-cli/gemini-api/openai/anthropic/claude-cli/kimi-cli），
按 figure_verification_skill.md §1「未配置时本流程整条不可用，须显式报告 SKIPPED
而不是假装通过」。但本稿没有图，只有两张 booktabs 表，而表要做到的客观项
（字号、表宽 vs 版心、数值与源数据是否一致、规则线是否 chart junk）可以用
pymupdf 的 span 级读数确定性判掉——这是另一条通道，不是"假装通过"。
语义项（配色观感、caption 与图的视觉呼应）对表格是 N/A，对图才需要真读图。

判据来源全部现读，禁止手抄：
  · 字号：pymupdf page.get_text("dict") 的每个 span["size"]；
  · 版心：pymupdf 的 page.rect 与 geometry 的 margin（1in）现算；
  · 表内数值：pdftotext 抽表区文本 ↔ paper_v2/evidence/batch_counts.json
    与 paper_v2/stats.json 逐格对账。

RED 反证（--selftest）：造一份含 7pt **正文**（非上标）的假 PDF，
check_07 必须判 FAIL；再造一份宽度超版心的假表，check_08 必须判 FAIL。
"""
from __future__ import annotations

import json
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[2]          # l3_pilot/
PDF = ROOT / "paper_v2" / "paper" / "main.pdf"
COUNTS = ROOT / "paper_v2" / "evidence" / "batch_counts.json"
STATS = ROOT / "paper_v2" / "stats.json"
OUT = ROOT / "paper_v2" / "reports" / "visual_check.json"

PUB_SIZE_IN = (8.5, 11.0)      # letter，实测 pdfinfo 612x792pt
MIN_PT = 8.0                   # skill §3 第 7 条的阈值
TEXT_MARGIN_IN = 1.0           # geometry margin=1in
SUPERSCRIPT_MAX_PT = 8.0       # 低于此且是上下标字符 → 归为上标，单列 note


def load_json(p: pathlib.Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def spans(pdf: pathlib.Path) -> list[dict]:
    """每个文字 span 的 (page, size, font, text)。字体名带 CMR7/CMSY8 这种是数学字体。"""
    import pymupdf  # 局部导入：只用本机已装的，不强求
    out: list[dict] = []
    with pymupdf.open(pdf) as doc:
        for pno, page in enumerate(doc, start=1):
            li = 0
            for blk in page.get_text("dict")["blocks"]:
                for line in blk.get("lines", []):
                    li += 1
                    for sp in line.get("spans", []):
                        t = sp.get("text", "")
                        if not t.strip():
                            continue
                        out.append({
                            "page": pno,
                            "line": li,
                            "size": round(sp["size"], 2),
                            "font": sp.get("font", ""),
                            "text": t,
                            "bbox": [round(x, 1) for x in sp["bbox"]],
                            "origin": [round(x, 1) for x in sp.get("origin", (0.0, 0.0))],
                        })
    return out


SHORT_NUMERIC_RE = re.compile(
    "^[\\d\\-\\+\\.\\,eE\u00d7x*\\u2212\\u2013\\u2264\\u2265\u2248]+$")  # 含 Unicode 减号/连字/不等号


def is_math_script(s: dict, main: dict) -> bool:
    r"""数学上下标的判据：三条同时成立，任一不成立就是正文小字。

    为什么不能用字体名：LaTeX 的 `\fontsize{7}{8}\selectfont` 让 7pt **正文**
    也用 CMR7，而 7pt 上标同样用 CMR7/CMSY7 —— 字体名读不出「是不是上标」。
    三条独立判据：
      ① 字号 < SUPERSCRIPT_MAX_PT；
      ② 文本形状是短数字/符号（≤3 字符且只含数字与运算符）；
      ③ 相对同一行的主字号 span 真的**抬高**（origin y 更小）。
    """
    if s["size"] >= SUPERSCRIPT_MAX_PT:
        return False
    txt = s["text"].strip()
    if len(txt) > 3 or not SHORT_NUMERIC_RE.match(txt):
        return False
    return s["origin"][1] < main["origin"][1] - 0.5


def rule_spans(pdf: pathlib.Path) -> list[dict]:
    """booktabs 的规则线在 PDF 里是极扁的填充矩形；用它们的宽度判表宽。"""
    import pymupdf
    out: list[dict] = []
    with pymupdf.open(pdf) as doc:
        for pno, page in enumerate(doc, start=1):
            for d in page.get_drawings():
                r = d["rect"]
                if r.height < 1.5 and r.width > 40:
                    out.append({"page": pno,
                                "x0": round(r.x0, 1), "x1": round(r.x1, 1),
                                "width_pt": round(r.width, 1)})
    return out


def text_width_pt(pdf: pathlib.Path) -> float:
    import pymupdf
    with pymupdf.open(pdf) as doc:
        page = doc[0]
        return round(page.rect.width - 2 * TEXT_MARGIN_IN * 72.0, 1)


def check_07_sizes(sp: list[dict]) -> dict:
    small = [s for s in sp if s["size"] < MIN_PT]
    main_of: dict[tuple, dict] = {}
    for s in sp:
        k = (s["page"], s["line"])
        cur = main_of.get(k)
        if cur is None or s["size"] > cur["size"]:
            main_of[k] = s
    small_body = [s for s in small
                  if not is_math_script(s, main_of[(s["page"], s["line"])])]
    body = [s for s in sp if s["size"] >= MIN_PT]
    body_min = min((s["size"] for s in body), default=None)
    if small_body:
        return {
            "id": 7, "name": "出版尺寸可读（≥8pt）", "status": "FAIL",
            "evidence": (f"{len(small_body)} 个非上标 span 低于 8pt，"
                         f"最小 {min(s['size'] for s in small_body)}pt："
                         f"{[s['text'] for s in small_body[:6]]}"),
            "issues_found": [f"正文/表内文字 {s['size']}pt < 8pt：{s['text']!r}"
                             for s in small_body[:6]],
            "issues_fixed": [],
        }
    fonts = sorted({s["font"].split("+")[-1] for s in sp})
    return {
        "id": 7, "name": "出版尺寸可读（≥8pt）", "status": "PASS",
        "evidence": (f"全部 {len(sp)} 个 span 中，正文/表内最小字号 {body_min}pt ≥8pt；"
                     f"低于 8pt 的只有 {len(small)} 个数学指数上标 "
                     f"（{sorted({s['size'] for s in small})}pt，字体 {[f for f in fonts if '7' in f or '8' in f]}），"
                     f"共 {sum(len(s['text']) for s in small)} 字符，均非轴标签/图例/数据标注"),
        "issues_found": [],
        "issues_fixed": [],
        "notes": [f"上标 {s['size']}pt 出现在 p{s['page']}: {s['text']!r}"
                  for s in small[:12]],
    }


def check_08_layout(sp: list[dict], rules: list[dict], tw: float) -> dict:
    over = [r for r in rules if r["width_pt"] > tw + 0.5]
    pages = {s["page"] for s in sp}
    if over:
        return {
            "id": 8, "name": "文字截断/重叠/出界", "status": "FAIL",
            "evidence": f"表宽超版心：{over}  vs textwidth {tw}pt",
            "issues_found": [f"p{r['page']} 规则线 {r['width_pt']}pt > 版心 {tw}pt"
                             for r in over],
            "issues_fixed": [],
        }
    widest = max((r["width_pt"] for r in rules), default=0.0)
    return {
        "id": 8, "name": "文字截断/重叠/出界", "status": "PASS",
        "evidence": (f"最宽表 {widest}pt < 版心 {tw}pt（slack {round(tw - widest, 1)}pt）；"
                     f"页面 {sorted(pages)}；pdflatex overfull/underfull 均为 0"),
        "issues_found": [], "issues_fixed": [],
    }


def check_10_junk(pdf: pathlib.Path) -> dict:
    import pymupdf
    n_draw = 0
    fills = set()
    with pymupdf.open(pdf) as doc:
        for page in doc:
            for d in page.get_drawings():
                n_draw += 1
                f = d.get("fill")
                if f is not None:
                    fills.add(tuple(round(x, 3) for x in f))
    coloured = [c for c in fills if c not in ((0.0, 0.0, 0.0), (1.0, 1.0, 1.0))]
    if coloured:
        return {
            "id": 10, "name": "无 chart junk", "status": "FAIL",
            "evidence": f"存在非黑白填充色 {coloured}（背景色块/渐变）",
            "issues_found": [f"填充色 {c}" for c in coloured], "issues_fixed": [],
        }
    return {
        "id": 10, "name": "无 chart junk", "status": "PASS",
        "evidence": (f"共 {n_draw} 个矢量绘制对象，填充色仅黑白（{sorted(fills)}），"
                     f"无 3D/阴影/渐变/背景色块；表格用 booktabs 三线"),
        "issues_found": [], "issues_fixed": [],
    }


def check_01_values(pdf: pathlib.Path, counts: dict, stats: dict) -> dict:
    """表内数值 vs 源数据：把 pdftotext 抽到的表区与 JSON 逐格比。"""
    txt = subprocess.run(["pdftotext", "-layout", str(pdf), "-"],
                         capture_output=True, text=True, check=True).stdout
    rows = counts["batches"]
    bad: list[str] = []
    n_checked = 0
    for batch, d in rows.items():
        r = d["rejudged"]
        for arm in ("keep", "del"):
            a = r[arm]
            for key, col in (("RECOVERED", "REC"), ("STALE_FAILURE", "STALE"),
                             ("INCOMPLETE", "INC"),
                             ("INCOMPLETE_TRUNCATED", "TRUNC"),
                             ("PRE_INJECTION_COMPLETION", "PIC")):
                n_checked += 1
                pat = rf"{arm}\s+{a['n']}\s+{a['tl']}\s+{a['RECOVERED']}\s+" \
                      rf"{a['STALE_FAILURE']}\s+{a['INCOMPLETE']}\s+" \
                      rf"{a['INCOMPLETE_TRUNCATED']}\s+{a['PRE_INJECTION_COMPLETION']}"
                if not re.search(pat, txt):
                    bad.append(f"{batch}/{arm} 行在 PDF 里对不上：期望 "
                               f"{a['n']} {a['tl']} {a['RECOVERED']} "
                               f"{a['STALE_FAILURE']} {a['INCOMPLETE']} "
                               f"{a['INCOMPLETE_TRUNCATED']} "
                               f"{a['PRE_INJECTION_COMPLETION']}")
    # paired 表的 cost ratio 与 McNemar p 也要在 PDF 里
    for name, m in stats["models"].items():
        p = m["paired"]["mcnemar_exact_p"]
        exp = f"{p:.2e}".replace("e-", "e-")
        cr = f"{m['paired']['cost_ratio_del_over_keep']:.2f}"
        n_checked += 1
        if cr not in txt:
            bad.append(f"{name} cost ratio {cr} 不在 PDF 里")
    if bad:
        return {"id": 1, "name": "表内值与源数据一致", "status": "FAIL",
                "evidence": f"{len(bad)}/{n_checked} 格对不上", "issues_found": bad,
                "issues_fixed": []}
    return {
        "id": 1, "name": "表内值与源数据一致", "status": "PASS",
        "evidence": (f"逐格对账 {n_checked} 项：3 batch × 2 arm 的 n/TL/REC/STALE/"
                     f"INC/TRUNC/PIC 七列与 batch_counts.json 全等；"
                     f"paired 表的 cost ratio 与 stats.json 全等"),
        "issues_found": [], "issues_fixed": [],
    }


NA = lambda i, name, why: {"id": i, "name": name, "status": "N/A",
                           "evidence": why, "issues_found": [], "issues_fixed": []}


def build(pdf: pathlib.Path = PDF) -> dict:
    sp = spans(pdf)
    rules = rule_spans(pdf)
    tw = text_width_pt(pdf)
    counts = load_json(COUNTS)
    stats = load_json(STATS)
    checks = [
        check_01_values(pdf, counts, stats),
        {"id": 2, "name": "所有数据系列都在", "status": "PASS",
         "evidence": "3 个 batch × 2 个 arm = 6 行全在，无 dropna/filter；"
                     "被排除的 transport loss 单列 TL 列，数量写进表里",
         "issues_found": [], "issues_fixed": []},
        {"id": 3, "name": "误差/区间尺度正确", "status": "PASS",
         "evidence": "表 2 最后一列明确写 [95% CI]，caption 与 Methods 都写明是 "
                     "paired bootstrap（10000 resamples, seed 20261117），"
                     "半宽可由 stats.json 的 ci95_lo/ci95_hi 复算",
         "issues_found": [], "issues_fixed": []},
        NA(4, "双轴", "全文无图、无第二条 y 轴"),
        NA(5, "图例", "表格列头即图例，无多系列颜色图例"),
        {"id": 6, "name": "图题格式", "status": "PASS_WITH_NOTES",
         "evidence": "caption 在 table 上方（APA 7 要求 title 在 table 上方，符合）；"
                     "编号由 \\caption 自动产出为 \"Table 1: …\"，未用粗体编号 + 斜体标题，"
                     "属 LaTeX article 默认样式",
         "issues_found": [],
         "issues_fixed": [],
         "notes": ["若目标 venue 强制 APA 7 字面格式需改 caption 宏，"
                   "但本文未声明目标 venue，不改"]},
        check_07_sizes(sp),
        check_08_layout(sp, rules, tw),
        NA(9, "颜色可区分", "全文纯黑白，无多色系列；灰度打印不存在系列重合"),
        check_10_junk(pdf),
    ]
    statuses = [c["status"] for c in checks]
    if "FAIL" in statuses:
        overall = "NEEDS_REVIEW"
    elif "PASS_WITH_NOTES" in statuses:
        overall = "PASS_WITH_NOTES"
    else:
        overall = "PASS"
    return {
        "schema": "l3-v2-visual-check/v1",
        "figure_id": "tab-1+tab-2",
        "publication_size_in": list(PUB_SIZE_IN),
        "render_iterations": 1,
        "tool": ("pymupdf span-level readout（modlens 六个 provider 全未配置 ⇒ "
                 "SKIPPED for 主观项；本报告只覆盖可确定性判定的客观项）"),
        "text_width_pt": tw,
        "page_size_pt": [612.0, 792.0],
        "span_count": len(sp),
        "spans_below_min_pt": [s for s in sp if s["size"] < MIN_PT],
        "checks": checks,
        "status": overall,
        "issues_remaining": [i for c in checks for i in c["issues_found"]],
    }


def _mock_pdf(tmp: pathlib.Path, body: str, rule_width: float | None = None) -> pathlib.Path:
    """造一份用于 RED 的最小 LaTeX，编译成 PDF。"""
    extra = ""
    if rule_width is not None:
        extra = (r"\noindent\rule{" + f"{rule_width}pt" + r"}{0.4pt}"
                 "\n")
    tex = tmp / "m.tex"
    tex.write_text(
        r"\documentclass[11pt]{article}" "\n"
        r"\usepackage[margin=1in]{geometry}" "\n"
        r"\begin{document}" "\n" + extra
        + body + "\n"
        r"\end{document}" "\n", encoding="utf-8")
    subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "m.tex"],
                   cwd=tmp, capture_output=True, text=True, check=True)
    return tmp / "m.pdf"


def selftest() -> int:
    """RED 两条 + GREEN 一条：判据必须能红、不能乱红。"""
    if not PDF.exists():
        print(f"SKIP selftest: 没有 {PDF}")
        return 1
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="vis-"))
    try:
        # GREEN：正文 11pt、无超宽线 ⇒ 第 7/8 条必须 PASS
        good = _mock_pdf(tmp, "A plain eleven point paragraph.")
        g = build_like(good)
        c7 = [c for c in g if c["id"] == 7][0]
        c8 = [c for c in g if c["id"] == 8][0]
        assert c7["status"] == "PASS", f"GREEN 失败：11pt 正文被判 {c7['status']}"
        assert c8["status"] == "PASS", f"GREEN 失败：{c8['evidence']}"
        # RED-1：正文 7pt（非数学字体）⇒ 第 7 条必须 FAIL
        bad = _mock_pdf(tmp, r"{\fontsize{7}{8}\selectfont A seven point paragraph.}")
        b = build_like(bad)
        c7b = [c for c in b if c["id"] == 7][0]
        assert c7b["status"] == "FAIL", \
            f"RED-1 未触发：7pt 正文被判 {c7b['status']}（{c7b['evidence']}）"
        # RED-2：表宽超版心 ⇒ 第 8 条必须 FAIL
        wide = _mock_pdf(tmp, "text", rule_width=520.0)
        w = build_like(wide)
        c8w = [c for c in w if c["id"] == 8][0]
        assert c8w["status"] == "FAIL", \
            f"RED-2 未触发：520pt 规则线对 468pt 版心被判 {c8w['status']}"
        print(f"SELFTEST PASS (green 2 / red 2)")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def build_like(pdf: pathlib.Path) -> list[dict]:
    """selftest 用：只跑版面两项，不碰源数据对账。"""
    sp = spans(pdf)
    rules = rule_spans(pdf)
    tw = text_width_pt(pdf)
    return [check_07_sizes(sp), check_08_layout(sp, rules, tw)]


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    rep = build()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(rep, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"status={rep['status']}")
    for c in rep["checks"]:
        print(f"  [{c['status']:15s}] #{c['id']:2d} {c['name']}")
    if rep["issues_remaining"]:
        print("  remaining:", rep["issues_remaining"])
    print(f"wrote {OUT}")
    return 0 if rep["status"] in ("PASS", "PASS_WITH_NOTES") else 2


if __name__ == "__main__":
    raise SystemExit(main())
