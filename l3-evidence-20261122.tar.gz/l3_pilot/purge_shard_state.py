#!/usr/bin/env python3
"""清掉分片 state 里被并发/限流烧掉的无信息记录（只清"0 步 + 预算耗尽"或 episode_exception）。

不清的：真实跑过步数但被判 INCOMPLETE 的（那是模型的真实失败，清了就是洗白）。
用法：python3 purge_shard_state.py runs/l3-fact-240x6x2-shard0 ...
"""
import json
import sys
from pathlib import Path


def is_burned(rec: dict) -> bool:
    errs = " ".join(str(x) for x in (rec.get("errors") or []))
    steps = rec.get("n_steps_taken")
    if steps is None:
        steps = len((rec.get("trace") or {}).get("steps", []))
    if "episode_exception" in errs:
        return True
    if steps == 0 and "budget exhausted" in errs:
        return True
    return False


def main(paths: list[str]) -> int:
    total_dropped = 0
    for p in paths:
        path = Path(p) / "factorial_state_v1.json"
        if not path.exists():
            print(f"skip {p}: no state")
            continue
        st = json.loads(path.read_text(encoding="utf-8"))
        before = len(st["records"])
        kept = [r for r in st["records"] if not is_burned(r)]
        dropped = before - len(kept)
        st["records"] = kept
        st["done"] = {r["slug"]: True for r in kept}
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)
        total_dropped += dropped
        print(f"{Path(p).name}: {before} -> {len(kept)} (dropped {dropped})")
    print(f"TOTAL DROPPED {total_dropped}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
