#!/usr/bin/env python3
"""从 runs/l3-v3-sc-200-minimax 的 judgements 现算 v3 主实验读数（铁律1：只认载体）。"""
import json, glob, math, collections, pathlib, sys

RUN = sys.argv[1] if len(sys.argv)>1 else "runs/l3-v3-sc-200-minimax"

def load():
    fs = sorted(glob.glob(f"{RUN}/judgements/*.json"))
    return [json.load(open(f)) for f in fs]

def exact_binom(b, c):
    n = b + c
    if n == 0: return 1.0
    k = min(b, c)
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k+1)) / 2**n)

def summarize():
    rows = load()
    eff = [r for r in rows if not r["transport_loss"]]
    by = collections.defaultdict(dict)
    for r in eff: by[r["card_id"]][r["arm"]] = r
    pairs = [v for v in by.values() if "keep" in v and "del" in v]
    valid = [v for v in pairs if all(v[a]["verdict"] in ("RECOVERED","STALE_FAILURE") for a in ("keep","del"))]
    def cnt(arm, v): return sum(1 for x in valid if x[arm]["verdict"] == v)
    imp = sum(1 for v in valid if v["keep"]["verdict"]=="STALE_FAILURE" and v["del"]["verdict"]=="RECOVERED")
    wor = sum(1 for v in valid if v["del"]["verdict"]=="STALE_FAILURE" and v["keep"]["verdict"]=="RECOVERED")
    tk = sum(v["keep"]["tokens"] for v in valid); td = sum(v["del"]["tokens"] for v in valid)
    ks = cnt("keep","STALE_FAILURE"); ds = cnt("del","STALE_FAILURE")
    out = {
        "schema":"l3-v3-main/v1","run_dir":RUN,
        "n_records":len(rows),"n_effective_records":len(eff),
        "transport_loss":sum(1 for r in rows if r["transport_loss"]),
        "cells":{},
        "paired":{"n_valid_pairs":len(pairs),"n_effective_pairs":len(valid),
            "keep_stale":ks,"del_stale":ds,
            "improved":imp,"worsened":wor,
            "diff_pp":round(100*(ds-ks)/len(valid),4) if valid else None,
            "direction":"deletion_harmful" if ds>ks else ("deletion_helpful" if ds<ks else "no_diff"),
            "mcnemar_exact_p":exact_binom(imp,wor),
            "cost_ratio_del_over_keep":round(td/tk,4) if tk else None,
            "cost_ok_le_1_10":(td/tk<=1.10) if tk else None},
        "prereg":{"required_effective_pairs":140,"achieved":len(valid),
            "power_ok":len(valid)>=140},
    }
    for arm in ("keep","del"):
        ar=[r for r in eff if r["arm"]==arm]
        c=collections.Counter(r["verdict"] for r in ar)
        out["cells"][arm]={"n":len(ar),"RECOVERED":c["RECOVERED"],"STALE_FAILURE":c["STALE_FAILURE"],
            "INCOMPLETE":c["INCOMPLETE"],"INCOMPLETE_TRUNCATED":c["INCOMPLETE_TRUNCATED"],
            "PRE_INJECTION_COMPLETION":c["PRE_INJECTION_COMPLETION"],
            "episodes_with_ok_write":sum(1 for r in ar if r.get("ok_writes",0)>0),
            "ok_writes_total":sum(r.get("ok_writes",0) for r in ar),
            "median_tokens":sorted(r["tokens"] for r in ar)[len(ar)//2] if ar else None}
    return out

if __name__=="__main__":
    o=summarize()
    pathlib.Path(f"{RUN}/main_summary.json" if len(sys.argv)<=1 else f"{RUN}/_check.json").write_text(json.dumps(o,ensure_ascii=False,indent=1),encoding="utf-8")
    print(json.dumps(o,ensure_ascii=False,indent=1))
