#!/usr/bin/env python3
"""S_a sensitivity arm: the plan carrier lives in a retrieval corpus.

Contrast with v3 (S_c), where the carrier lives in conversation history:
here the version mapping is exposed through a `retrieve` tool over a small
document corpus.  The deletion arm removes the version-mapping documents
from the corpus (not a memory row, not a history slice).  Resource names
stay visible in the constant system prompt (D16 de-confounding) and `stat`
does not leak the current version (D11.1).

The predicted effect (same as v3, different channel): the retention arm,
after the invalidation notice, retrieves the v2 row and switches basis
directly; the deletion arm cannot retrieve a version row, writes with the
stale basis once, is rejected, then discovers v2 by trial and error.  The
verdict therefore counts *stale write actions*, not task failure — both
arms deliver all 40 files (D20.1).

This file is orchestration-layer only: it imports the frozen/registered
modules and does not edit them.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import statistics
import sys
import threading
import time
import urllib.error
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import agent_arm  # noqa: E402
import v2_runner_sc as v2  # noqa: E402

DEFAULT_BASE = v2.DEFAULT_BASE
MAX_TOKENS = v2.MAX_TOKENS_V2
INJECT_TURN = v2.INJECT_TURN
MAX_TURNS = v2.MAX_TURNS
MAX_CALLS = v2.MAX_CALLS
CARRIER = "S_a:retriever/corpus"

# Two arms get byte-identical system prompts.  Resource names are constant
# (D16); the only difference is what `retrieve` returns (the corpus).
SYSTEM_PROMPT = (
    "You are an agent migrating files on a remote storage service.\n"
    "Goal: all files written to the current target path.\n"
    "There are {n_files} files: {first} .. {last}.\n"
    "Usable resources: {r0} and {r1}. Target paths: {t1} and {t2}.\n"
    "Rules:\n"
    "- The service may change at any time. `stat` does not publish the plan.\n"
    "- The current plan is in the knowledge corpus; use `retrieve` to read it.\n"
    "- `write` needs the plan_version your write is based on (an integer).\n"
    "  A write based on an outdated plan_version will be rejected.\n"
    "- A turn may contain at most 8 `write` calls.\n"
    "- When the service changes, re-check the corpus before your next write.\n"
    "- Use `verify` only for files you already wrote.\n"
    "Reply with tool calls only; no prose."
)

INJECT_NOTICE = (
    "Notice: the storage service reported a change. "
    "Re-check the knowledge corpus before your next write."
)

RETRIEVE_TOOL = {
    "type": "function",
    "function": {
        "name": "retrieve",
        "description": "Search the knowledge corpus and return matching documents.",
        "parameters": {
            "type": "object",
            "properties": {"query": {"type": "string", "description": "search query"}},
            "required": ["query"],
        },
    },
}
TOOLS_SA = list(v2.TOOLS) + [RETRIEVE_TOOL]


class ClientSA(v2.ClientV2):
    """ClientV2 but advertises the retrieve tool as well."""

    def complete(self, messages: list[dict]) -> dict:
        if self.calls >= self.max_calls:
            raise agent_arm.Budget(f"model call budget exhausted after {self.calls} calls")
        payload = {
            "model": self.model, "messages": messages, "tools": TOOLS_SA,
            "tool_choice": "auto", "max_tokens": MAX_TOKENS, "temperature": 0,
        }
        import urllib.request
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST",
        )
        self.calls += 1
        last = None
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    body = json.loads(resp.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as e:
                last = e
                if e.code in (429, 502, 503, 504) and attempt < 3:
                    time.sleep(5 * (attempt + 1))
                    continue
                raise
            except json.JSONDecodeError as e:
                last = e
                if attempt < 3:
                    time.sleep(2 * (attempt + 1))
                    continue
                raise
        else:  # pragma: no cover
            raise last
        usage = body.get("usage") or {}
        self.prompt_tokens += usage.get("prompt_tokens") or 0
        self.completion_tokens += usage.get("completion_tokens") or 0
        return body["choices"][0]


def make_client(base_url: str, model: str, max_calls: int = MAX_CALLS) -> ClientSA:
    return ClientSA(base_url, model, max_calls)


def make_corpus(card: dict, keep_carrier: bool, strip_versions: bool = False) -> list[dict]:
    """Retrieval corpus.  Deletion arm removes ONLY the version-mapping docs.

    `strip_versions` is the false-positive guard's lever: keep the arm label but
    remove the rows anyway, so a passing test cannot be explained by the label.
    """
    r0, r1 = card["resources"][0], card["resources"][1]
    t1, t2 = card["target_v1"], card["target_v2"]
    docs = [
        {"id": "doc-task", "text": "Migrate all files to the current target path."},
        {"id": "doc-plan-v1", "text": f"plan row v1: basis_version=1, resource={r0}, target={t1}"},
        {"id": "doc-plan-v2", "text": f"plan row v2: basis_version=2, resource={r1}, target={t2}"},
    ]
    if not keep_carrier or strip_versions:
        docs = [d for d in docs if d["id"] == "doc-task"]
    return docs


class EnvSA(v2.EnvSC):
    """继承 EnvSC 的状态机；额外持有检索语料。stat 仍不泄漏版本。"""

    def __init__(self, card: dict, keep_carrier: bool, strip_versions: bool = False):
        super().__init__(card)
        self.corpus = make_corpus(card, keep_carrier, strip_versions)


def dispatch_sa(call: dict, env: EnvSA, card: dict, written: dict) -> dict:
    fn = call.get("function") or {}
    if fn.get("name") == "retrieve":
        return {"ok": True, "result": {"documents": list(env.corpus)}}
    return v2.dispatch(call, env, card, written)


def make_card(n_files: int = 40, seed: int = 200000) -> dict:
    card = v2.make_card(n_files=n_files, seed=seed)
    card["schema"] = "l3-card-sa/v1"
    card["carrier"] = CARRIER
    card["injection"] = {
        "kind": "plan_invalidation",
        "effect": "plan_version 1->2, store-a unavailable, target v1->v2; "
                  "resource names remain in the prompt; version rows live in retrieval corpus",
    }
    return card


def run_episode(client, card: dict, keep_carrier: bool, max_turns: int = MAX_TURNS,
                strip_versions: bool = False) -> dict:
    env = EnvSA(card, keep_carrier, strip_versions)
    written: dict = {}
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT.format(
            n_files=card["n_steps"], first=card["files"][0], last=card["files"][-1],
            r0=card["resources"][0], r1=card["resources"][1],
            t1=card["target_v1"], t2=card["target_v2"])},
    ]
    # 两臂都被告知检索可用（工具可用性不是操纵变量）；差异只在语料内容。
    messages.append({"role": "user", "content":
                     "The knowledge corpus is available via retrieve."})
    trace = {"card_id": card["card_id"], "carrier": CARRIER,
             "keep_carrier": keep_carrier, "steps": [], "errors": [],
             "injection": None, "budget_exhausted": False}
    started = time.time()
    for turn in range(max_turns):
        if turn == INJECT_TURN and trace["injection"] is None:
            env.inject(card)
            trace["injection"] = {"step": turn, "kind": "plan_invalidation"}
            messages.append({"role": "user", "content": INJECT_NOTICE})
        try:
            choice = client.complete(messages)
        except agent_arm.Budget as e:
            trace["budget_exhausted"] = True
            trace["errors"].append(str(e))
            break
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError,
                json.JSONDecodeError) as e:
            trace["errors"].append(f"transport:{type(e).__name__}:{e}")
            break
        message = choice.get("message") or {}
        tool_calls = message.get("tool_calls") or []
        finish = choice.get("finish_reason")
        am = {"role": "assistant", "content": message.get("content") or ""}
        if tool_calls:
            am["tool_calls"] = tool_calls
        messages.append(am)
        if not tool_calls:
            trace["steps"].append({"step": turn, "plan_version": env.plan_version,
                                   "tool_calls": [], "text": (message.get("content") or "")[:300],
                                   "finish": finish})
            break
        step_calls = []
        for call in tool_calls:
            res = dispatch_sa(call, env, card, written)
            step_calls.append({"tool": call["function"]["name"],
                               "args": agent_arm._safe_args(call),
                               "ok": res.get("ok", False),
                               "result": res.get("result"),
                               "error": res.get("error")})
            messages.append({"role": "tool", "tool_call_id": call.get("id", ""),
                             "content": json.dumps(res, ensure_ascii=False)[:800]})
        trace["steps"].append({"step": turn, "plan_version": env.plan_version,
                               "tool_calls": step_calls, "finish": finish})
    last = trace["steps"][-1] if trace["steps"] else {}
    trace["final"] = {
        "verified_count": sum(written.values()),
        "n_files": card["n_steps"],
        "final_target": env.target,
        "tool_call_count": sum(len(s["tool_calls"]) for s in trace["steps"]),
        "trajectory_length": len(trace["steps"]),
        "empty_tail": (not last.get("tool_calls")),
        "last_finish": last.get("finish"),
        "token_proxy": client.prompt_tokens + client.completion_tokens,
        "wall_clock_s": round(time.time() - started, 2),
    }
    trace["usage"] = {"calls": client.calls, "prompt_tokens": client.prompt_tokens,
                      "completion_tokens": client.completion_tokens}
    trace["verdict"] = v2.verdict_of(trace)
    return trace


class ScriptedClientSA:
    """零 API：注入后若检索到 v2 行则直接切；否则先用 v1 被拒，再试错切 v2。"""

    def __init__(self, keep_carrier: bool, per_turn: int = 4, card: dict | None = None):
        self.keep_carrier = keep_carrier
        self.card = card or make_card()
        self.per_turn = per_turn
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.max_calls = MAX_CALLS
        self.model = "scripted-sa"

    def complete(self, messages):
        self.calls += 1
        tool_msgs = [m.get("content") or "" for m in messages if m.get("role") == "tool"]
        seen_change = any(m.get("role") == "user" and "reported a change" in (m.get("content") or "")
                          for m in messages)
        has_map = any("basis_version=2" in c for c in tool_msgs)
        got_stale = any("stale_basis" in c for c in tool_msgs)
        use_v2 = seen_change and (has_map or got_stale)
        n_done = sum(1 for c in tool_msgs if '"files"' in c)
        idx = n_done * self.per_turn
        card = self.card
        files = card["files"][idx:min(idx + self.per_turn, card["n_steps"])]
        target = card["target_v2"] if use_v2 else card["target_v1"]
        store = card["resources"][1] if use_v2 else card["resources"][0]
        basis = 2 if use_v2 else 1
        if seen_change and not use_v2:
            # 删臂注入后检索不到版本 → 先尝试旧 basis（制造 stale 写动作）
            basis = 1
        call = {"id": f"c{self.calls}", "type": "function",
                "function": {"name": "write", "arguments": json.dumps(
                    {"files": files, "resource": store, "basis_version": basis,
                     "target": target})}}
        return {"message": {"content": "", "tool_calls": [call]}, "finish_reason": "tool_calls"}


def count_ok_writes(trace: dict) -> int:
    return sum(1 for step in trace["steps"] for c in step["tool_calls"]
               if c["tool"] == "write" and c["ok"])


def selftest() -> None:
    ok = 0
    card = make_card()
    keep_sys = SYSTEM_PROMPT.format(
        n_files=40, first="f00", last="f39", r0="store-a", r1="store-b",
        t1="/dst/200000/v1", t2="/dst/200000/v2")
    # 两臂共用同一个 SYSTEM_PROMPT 常量：模板里不得出现任何臂标识，
    # 否则有人往提示里塞 arm 分支就能悄悄制造差异（恒真断言抓不到）。
    low = SYSTEM_PROMPT.lower()
    for token in ("keep_carrier", "keep_carrier=true", "deletion", "retention",
                  "arm=", "arm:", "keep arm", "del arm", "{keep"):
        assert token not in low, f"提示模板泄漏臂标识: {token}"
    assert "store-a" in keep_sys and "store-b" in keep_sys
    print("[PASS] 提示模板无臂标识（两臂逐字同）+ 资源名常驻（D16）"); ok += 1

    keep_corpus = make_corpus(card, True)
    del_corpus = make_corpus(card, False)
    keep_blob = " ".join(d["text"] for d in keep_corpus)
    del_blob = " ".join(d["text"] for d in del_corpus)
    assert "basis_version=1" in keep_blob and "basis_version=2" in keep_blob
    assert "basis_version" not in del_blob
    print("[PASS] 删臂检索语料移除版本映射，保留任务说明"); ok += 1

    envstat = EnvSA(card, True).stat(card)
    assert "store-a" not in json.dumps(envstat) and "plan_version" not in json.dumps(envstat)
    print("[PASS] stat 不泄漏版本（D11.1）"); ok += 1

    # ScriptedClient 需要先 retrieve 才能让 has_map 命中；注入前先取一次
    tr_k = run_episode(ScriptedClientSA(True), card, keep_carrier=True)
    assert tr_k["carrier"] == CARRIER
    print(f"[PASS] keep 载体字段 = {CARRIER}"); ok += 1

    # GREEN / RED：脚本客户端要在注入后从 tool 消息里读到 retrieve 结果，
    # 因此用带 retrieve 的包装客户端（见下）。
    tr_k = run_episode(ScriptedSAWithRetrieve(True), card, keep_carrier=True)
    assert tr_k["verdict"] == "RECOVERED", (tr_k["verdict"], tr_k["final"])
    print(f"[PASS] GREEN 检索到版本映射 → RECOVERED（{tr_k['final']['verified_count']}/40）"); ok += 1

    tr_d = run_episode(ScriptedSAWithRetrieve(False), card, keep_carrier=False)
    assert tr_d["verdict"] == "STALE_FAILURE", (tr_d["verdict"], tr_d["final"])
    inj = tr_d["injection"]["step"] if tr_d["injection"] else None
    ok_before = sum(1 for s in tr_d["steps"] if inj is not None and s["step"] < inj
                    for c in s["tool_calls"] if c["tool"] == "write" and c["ok"])
    assert ok_before > 0, ("删臂注入前必须能成功写（D16 去混杂）", ok_before)
    stale_after = sum(1 for s in tr_d["steps"] if inj is not None and s["step"] >= inj
                      for c in s["tool_calls"] if c["tool"] == "write" and c["error"] == "stale_basis")
    assert stale_after > 0, ("删臂注入后必须产生 stale 写动作", stale_after)
    print(f"[PASS] RED 检索不到版本 → STALE_FAILURE，注入前成功写 {ok_before} 次、注入后 stale {stale_after} 次"); ok += 1

    # 假阳守卫：keep 臂但语料里抹掉版本行 → 不得 RECOVERED
    # （必须改环境语料，不是只改脚本客户端自己发的 retrieve 结果）
    bad = ScriptedSAWithRetrieve(True, drop_versions=True)
    tr_bad = run_episode(bad, card, keep_carrier=True, strip_versions=True)
    assert tr_bad["verdict"] == "STALE_FAILURE", (tr_bad["verdict"], tr_bad["final"])
    print("[PASS] 假阳守卫：语料无版本映射即 STALE，不误判为恢复"); ok += 1

    import tempfile
    with tempfile.TemporaryDirectory() as td:
        rep = run_grid("http://127.0.0.1:1/v1", "scripted/model", 2, 2,
                       pathlib.Path(td), resume=False, scripted=True)
        assert rep["n_records"] == 4, rep["n_records"]
        assert rep["cells"]["del"]["STALE_FAILURE"] == 2, rep["cells"]["del"]
        assert rep["cells"]["keep"]["RECOVERED"] == 2, rep["cells"]["keep"]
        assert rep["writes"]["del"]["ok_before_injection_total"] > 0
        assert rep["schema"] == "l3-sa-report/v1"
        assert rep["carrier"] == CARRIER
        stage = pathlib.Path(td)
        assert len(list((stage / "judgements").glob("*.json"))) == 4
        assert len(list((stage / "traces").glob("*.json"))) == 4
        assert json.loads((stage / "state.json").read_text())["finished"] is True
    print("[PASS] 网格落盘：4 条 judgement/trace、del 2/2 STALE、state finished"); ok += 1

    print(f"SELFTEST PASS ({ok}/8)")


class ScriptedSAWithRetrieve(ScriptedClientSA):
    """脚本客户端：首轮发 retrieve，使 tool 消息携带语料；drop_versions 模拟假阳。"""

    def __init__(self, keep_carrier, per_turn=4, card=None, drop_versions=False):
        super().__init__(keep_carrier, per_turn, card)
        self.dropped = drop_versions
        self.did_retrieve = False

    def complete(self, messages):
        if not self.did_retrieve:
            self.did_retrieve = True
            self.calls += 1
            docs = make_corpus(self.card, self.keep_carrier)
            if self.dropped:
                docs = [d for d in docs if "basis_version" not in d["text"]]
            call = {"id": f"c{self.calls}", "type": "function",
                    "function": {"name": "retrieve", "arguments": json.dumps({"query": "plan"})}}
            return {"message": {"content": "", "tool_calls": [call]}, "finish_reason": "tool_calls"}
        return super().complete(messages)


def _records_from_judgements(out: pathlib.Path) -> list[dict]:
    recs = []
    for q in sorted((out / "judgements").glob("*.json")):
        j = json.loads(q.read_text(encoding="utf-8"))
        recs.append({k: j[k] for k in ("card_id", "arm", "verdict", "slug", "tokens",
                                       "verified", "steps", "errors", "transport_loss")})
    return recs


def writes_block(judgements: list[dict]) -> dict:
    out = {}
    for arm in ("keep", "del"):
        js = [j for j in judgements if j["arm"] == arm and not j["transport_loss"]]
        out[arm] = {
            "n": len(js),
            "episodes_with_ok_write": sum(1 for j in js if j.get("ok_writes", 0) > 0),
            "ok_before_injection_total": sum(j.get("ok_before_injection", 0) for j in js),
            "median_ok_writes": statistics.median([j.get("ok_writes", 0) for j in js]) if js else None,
        }
    return out


def run_grid(base_url: str, model: str, cards: int, workers: int, out: pathlib.Path,
             resume: bool, scripted: bool = False) -> dict:
    for sub in ("traces", "judgements"):
        (out / sub).mkdir(parents=True, exist_ok=True)
    card_list = [make_card(40, 200000 + i * 1000) for i in range(cards)]
    jobs = [(c, keep) for c in card_list for keep in (True, False)]
    slug_of = lambda c, k: (f"{model.replace('/', '_')}__{c['card_id']}__"
                            f"{'keep' if k else 'del'}__r0")
    done, recs = set(), []
    if resume:
        recs = _records_from_judgements(out)
        done = {r["slug"] for r in recs}
    lock = threading.Lock()
    t0 = time.time()
    state = {"finished": False, "planned": len(jobs), "done_slugs": sorted(done)}

    def write_state():
        tmp = out / "state.json.tmp"
        tmp.write_text(json.dumps(state, ensure_ascii=False, default=list), encoding="utf-8")
        tmp.replace(out / "state.json")

    write_state()

    def work(job):
        card, keep = job
        slug = slug_of(card, keep)
        if slug in done:
            return None
        client = (ScriptedSAWithRetrieve(keep, card=card) if scripted
                  else make_client(base_url, model))
        tr = run_episode(client, card, keep_carrier=keep)
        tr["slug"] = slug
        (out / "traces" / f"{slug}.json").write_text(
            json.dumps(tr, ensure_ascii=False, indent=1), encoding="utf-8")
        inj = tr["injection"]["step"] if tr["injection"] else None
        ok_w = count_ok_writes(tr)
        ok_b = sum(1 for s in tr["steps"] if inj is not None and s["step"] < inj
                   for c in s["tool_calls"] if c["tool"] == "write" and c["ok"])
        jm = {"schema": "l3-judgement-sa/v1", "slug": slug, "card_id": card["card_id"],
              "arm": "keep" if keep else "del", "carrier": CARRIER,
              "verdict": tr["verdict"], "metrics": tr["final"],
              "tokens": tr["usage"]["prompt_tokens"] + tr["usage"]["completion_tokens"],
              "verified": tr["final"]["verified_count"],
              "steps": tr["final"]["trajectory_length"], "errors": tr["errors"],
              "transport_loss": any("transport" in str(e) for e in tr["errors"]),
              "ok_writes": ok_w, "ok_before_injection": ok_b}
        (out / "judgements" / f"{slug}.json").write_text(
            json.dumps(jm, ensure_ascii=False, indent=1), encoding="utf-8")
        with lock:
            recs.append({k: jm[k] for k in ("card_id", "arm", "verdict", "slug", "tokens",
                                            "verified", "steps", "errors", "transport_loss")})
            state["done_slugs"].append(slug)
            write_state()
        return jm

    with ThreadPoolExecutor(max_workers=workers) as pool:
        list(pool.map(work, jobs))

    recs.sort(key=lambda r: (r["card_id"], r["arm"]))
    state["finished"] = True
    write_state()
    judgements = [json.loads(q.read_text(encoding="utf-8"))
                  for q in sorted((out / "judgements").glob("*.json"))]
    summary = v2.summarize(recs)
    report = {"schema": "l3-sa-report/v1", "model": model, "cards": cards,
              "arms": ["keep", "del"], "carrier": CARRIER,
              "retrieval_carrier": True, "resource_names_constant": True,
              "max_tokens": MAX_TOKENS, "inject_turn": INJECT_TURN,
              "wall_clock_s": round(time.time() - t0, 2),
              "writes": writes_block(judgements), **summary}
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1),
                                     encoding="utf-8")
    return report


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--base-url", default=DEFAULT_BASE)
    ap.add_argument("--model", default="openrouter/minimax/minimax-m3.1-flash")
    ap.add_argument("--cards", type=int, default=40)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--out", default="runs/l3-sa-sc")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--scripted", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        selftest()
        return 0
    from concurrent.futures import ThreadPoolExecutor  # noqa: F401  (used in run_grid)
    rep = run_grid(args.base_url, args.model, args.cards, args.workers,
                   pathlib.Path(args.out), args.resume, args.scripted)
    print(json.dumps({"cells": rep["cells"], "paired": rep["paired"],
                      "writes": rep["writes"]}, ensure_ascii=False, indent=1))
    print(f"records={rep['n_records']} wall={rep['wall_clock_s']}s out={args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
