#!/usr/bin/env python3
"""按 AGENTS.md §16 的 O_APPEND 纪律追加一段 DEVIATION。"""
import hashlib, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
TARGET = os.path.join(ROOT, "DEVIATION_L3.md")
BODY_PATH = os.path.join(os.path.dirname(__file__), "d10_body.md")

body = open(BODY_PATH, "rb").read()
before = open(TARGET, "rb").read()
prefix_hash = hashlib.sha256(before).hexdigest()
if body.strip() in before:
    print("ALREADY PRESENT, skip")
    sys.exit(0)
if not before.endswith(b"\n"):
    body = b"\n" + body
fd = os.open(TARGET, os.O_WRONLY | os.O_APPEND)
try:
    n = os.write(fd, body)
finally:
    os.close(fd)
after = open(TARGET, "rb").read()
assert after.startswith(before), "前缀被改动"
assert len(after) == len(before) + n, f"写入字节不符 {len(after)-len(before)} != {n}"
assert after.count(body.strip()) == 1, "正文哈希不唯一"
print(f"OK prefix_sha256={prefix_hash[:16]} appended={n} total={len(after)} "
      f"sha256={hashlib.sha256(after).hexdigest()[:16]}")
