# D10 复现：400-token 截断 → 空尾 → INCOMPLETE

## 跑什么

`python3 repro.py`（本机 Magpie 网关 `127.0.0.1:3425`，模型 `volcengine/glm-5.3-flash`）。
16 张注册卡 × 2 策略（`stale` = authority 提示 / `reactive` = recheck 提示）= 32 episode，8 并发，
墙钟约 90 秒（8 worker 并行；单 episode 中位 50.6s、最长 88.8s）。

上云通道在 2026-11-11 04:45 PST 实测 `Connection refused`（AMD 实例提前销毁），故按
`AGENTS.md` §17「确实无法上云时」的例外，做**亚分钟级诊断**，不挂后台、不跑长任务。

不改任何冻结文件：`CapClient` 继承 `agent_arm.Client`，只在 `complete()` 外层记录
`finish_reason` / `tool_calls` 数量；判 verdict 用冻结 `judge.judge()`。
`raw_turns.json` 里存了 `agent_arm.py` / `judge.py` / `engine.py` 的 sha256 前 16 位
（`6239b5d32d578122` / `0e09d9e1123236ad` / `46e99ba8dd9a6f82`），与 PREREG §1 一致。

## 关键机制（冻结层）

- `agent_arm.py:105`：`max_tokens: 400` 写死。
- `agent_arm.py:345-358`：一轮里 `tool_calls` 为空就 append 一条空 step 并 `break`。
- `judge.py:51-56`：`verified_count != n_files` 且无 stale → `INCOMPLETE("no stale writes but task not completed")`。
- GLM 是 reasoning 模型，响应把预算吃在 `reasoning_content` 上；`finish_reason=length` 时
  `tool_calls` 可能为 0 → 被当成「模型主动收工」。

## 实测结果（`summary.json` 可从 `raw_turns.json` 重算）

| 指标 | 全体 | stale(authority) | reactive(recheck) |
|---|---|---|---|
| episode | 32 | 16 | 16 |
| 总轮数 | 270 | 136 | 134 |
| `finish=length` 轮 | 48 (17.8%) | 23 (16.9%) | 25 (18.7%) |
| 截断且 0 tool_call 的轮 | 12 | 5 | 7 |
| 空尾 episode（最后一轮 0 tool_call 且 text 空） | 12 | 5 | 7 |
| 空尾最后一轮 `finish=length` | **12/12** | 5/5 | 7/7 |
| 空尾→判决 | — | 3 STALE + 2 INC | **7/7 INCOMPLETE** |
| 非空尾→判决 | — | 10 STALE + 1 INC | **9/9 RECOVERED** |
| 救援探针（同一 messages 换 `max_tokens=1600` 重发） | **12/12 拿到 tool_calls** | 5/5 | 7/7 |

救援探针只记录、不把结果交回 agent，所以冻结层行为未被改变。
12/12 成功说明空尾是**预算截断**，不是模型决定收工。

## 对 2880 因子跑的解释

- R_keep / R_del_plan / R_del_quota 三格 INC 117 / 81 / 33（48.8% / 33.8% / 13.8%），
  与空尾率 0.467 / 0.304 / 0.125 几乎一一对应。
- 因此**完成率维度的七组配对对照撤回**：它量到的是「提示/记忆让模型 reasoning 变长、
  更容易撞 400-token 上限」，不是任务能力差异。
- stale 维度不受空尾影响：authority 三格 210/218/226 STALE，recheck 三格 0 STALE；
  recheck 空尾的 episode 在截断前也没写过 stale basis（复现里 reactive 空尾 7/7 全 INC、
  0 STALE）。**「效应来自提示而非记忆移除」的方向不变**，但必须写成
  「在有效单元内」，且折损 19.7% 逼近 PREREG §56 的 20% 上限。

## 证据链状态

`runs/l3-fact-240x6x2-shard0..7/` 的 state / traces / judgements 随实例销毁丢失，
本地只剩聚合 `runs/l3-fact-240x6x2-analysis/factorial_2880.json`。
`python3 l3_pilot/verify_evidence_chain.py --aggregate <该文件> --shards-glob '...'` → **exit 2**。
闸门判定：2880 的逐格数字标 **VERIFY**，本报告只作为筛选性观察，不作确证性判定。

复核命令：

```bash
python3 l3_pilot/verify_evidence_chain.py --selftest
python3 l3_pilot/runs/l3-truncation-repro/repro.py
python3 l3_pilot/power_l3.py --check
```
