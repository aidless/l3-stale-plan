
## D10（2026-11-11）：INCOMPLETE 是量具截断，不是能力；且 2880 逐条载体已丢失

### D10.1 因果链（本机复现，可从落盘证据重算）

云实例 `36.150.116.206:33100` 于 2026-11-11 04:45 PST 实测 `Connection refused`
（比登记的 2026-11-12 06:29 PST 自动销毁早约 26h）。网关 `127.0.0.1:3425` 仍 200，
故按 `AGENTS.md` §17 的「无法上云」例外做亚分钟级诊断，不挂后台、不跑长任务。

复现：`l3_pilot/runs/l3-truncation-repro/repro.py`，16 卡 × 2 策略 = 32 episode，8 并发，
模型 `volcengine/glm-5.3-flash`。只继承 `agent_arm.Client` 记录原始响应，
**不改任何冻结文件**；`raw_turns.json` 存了 `agent_arm.py` `6239b5d32d578122` /
`judge.py` `0e09d9e1123236ad` / `engine.py` `46e99ba8dd9a6f82`（前 16 位，与 PREREG §1 一致）。

链条：

1. `agent_arm.py:105` 把 `max_tokens: 400` 写死；GLM 是 reasoning 模型，
   预算被 `reasoning_content` 吃掉，270 轮里 **48 轮 `finish_reason=length`（17.8%）**。
2. 其中 **12 轮 `tool_calls` 为 0**；`agent_arm.py:345-358` 见 `not tool_calls`
   就 append 一条空 step 并 `break`，把截断当成「模型主动收工」。
3. `judge.py:51-56` 见 `verified_count != n_files` 且无 stale →
   `INCOMPLETE("no stale writes but task not completed")`。

实测对应（`raw_turns.json` / `summary.json`）：

| 指标 | 全体 | stale(authority) | reactive(recheck) |
|---|---|---|---|
| episode / 总轮数 | 32 / 270 | 16 / 136 | 16 / 134 |
| `finish=length` 轮 | 48 | 23 | 25 |
| 截断且 0 tool_call | 12 | 5 | 7 |
| 空尾 episode | 12 | 5 | 7 |
| 空尾最后一轮 `finish=length` | **12/12** | 5/5 | 7/7 |
| 空尾→判决 | — | 3 STALE + 2 INC | **7/7 INCOMPLETE** |
| 非空尾→判决 | — | 10 STALE + 1 INC | **9/9 RECOVERED** |
| 救援探针（同 messages 换 `max_tokens=1600`） | **12/12 拿到 tool_calls** | 5/5 | 7/7 |

救援探针只记录、不把结果交回 agent，冻结层行为未变。12/12 成功 = 空尾是预算截断，
不是模型决定收工。这与 2880 跑里空尾率（A_keep 0.350 / A_del_plan 0.113 /
A_del_quota 0.071 / R_keep 0.467 / R_del_plan 0.304 / R_del_quota 0.125）
和 INC 率的一一对应吻合。

### D10.2 撤回与保留

- **撤回**：`L3_FACTORIAL_2880_REPORT.md` §三之后所有「完成率维度配对对照」
  （如 R_keep vs R_del_quota −35.0pp、A_keep vs R_keep +36.7pp）作为能力指标使用。
  它们量到的是「提示/记忆让 reasoning 变长 → 更容易撞 400 上限」，不是完成能力。
- **撤回**：§五「不排除时间漂移污染完成率」的猜测。GLM 1,440 条 judgement mtime 跨
  80.6 min，全局 10 段 INC 率 0.167–0.236 平走，六格在 shard 内平均位置均 1.50x → 已排除。
  **真因是截断**。
- **保留**：stale 维度方向。authority 三格 210/218/226 STALE，recheck 三格 0 STALE；
  复现里 reactive 空尾 7/7 全 INC、0 STALE（截断前也没写过 stale basis）。
  「效应来自提示、记忆移除惰性」在有效单元内成立，且必须限定「有效单元内」——
  GLM 折损 19.7% 已逼近 PREREG §56 的 20% 上限，deepseek 1,440 条里 1,374 条
  `transport:HTTPError:HTTP Error 429: Too Many Requests` 整块作废。
- **新口径**：以后报完成率必须先报 `finish_reason=length` 率与空尾率，
  并单独列「量具截断型 INCOMPLETE」，与「真实干不完」分开。冻结层不能改，
  就在编排层记录原始响应（v2 必须把 `max_tokens` 提到 ≥1600 或做截断续跑，
  并写进预注册修订）。

### D10.3 证据链缺口（本条最硬的教训）

`runs/l3-fact-240x6x2-shard0..7/` 的 state / traces / judgements 随实例销毁**全部丢失**，
本地只剩聚合 `runs/l3-fact-240x6x2-analysis/factorial_2880.json`（4,464 字节，只有 cells/contrasts）。
按铁律 1「数字可复算」，该聚合表里所有逐格数字标 **VERIFY**，只作筛选性观察。

新增闸门 `l3_pilot/verify_evidence_chain.py`：

```bash
python3 l3_pilot/verify_evidence_chain.py --selftest                 # RED+GREEN 4 条全 PASS
python3 l3_pilot/verify_evidence_chain.py --run-dir l3_pilot/runs/l3-runA-50x2x3   # exit 0
python3 l3_pilot/verify_evidence_chain.py \
  --aggregate l3_pilot/runs/l3-fact-240x6x2-analysis/factorial_2880.json \
  --shards-glob 'l3_pilot/runs/l3-fact-240x6x2-shard*/judgements/*.json'           # exit 2
```

闸门判据：完整 run 的 `report.n_records` / `report.records` / `judgements/` /
`traces/` / `formal_state_v2.json` 五处逐条对齐；聚合表若无 judgement 载体直接 exit 2。
`--selftest` 含 GREEN（完整 Run A 放行、最小载体放行）与 RED（篡改 `n_records` 阻断、
聚合表无载体阻断），均为真实注入、真实断言，不是装饰。

**纪律**：跑完立刻把载体拉回本地再出报告。上一轮「先出报告、实例还在、回头再拉」是错的——
实例提前销毁没有通知。吞吐不是健康证据，判决分布不是健康证据，**载体在磁盘上才是**。

### D10.4 与 D6/D8/D9 的关系

- D6 的结论（不投 2880 全量确认性跑、机制命名不成立）**不变**，D10 只是把
  「完成率」这一支证据削掉，主结论仍靠 stale 维度 + 提示/记忆因子分离。
- D8.4「任务本质是指令服从」**不变**，且被本节加强：`max_tokens` 一调，
  同一模型同一提示的完成率就变，说明测的是量具不是智能。
- D9 的 Client 复用 bug 与本节无关（那次是 0 步烧盘，这次是跑过若干轮后空尾）。
