#!/usr/bin/env python3
"""D10 复现：验证「max_tokens=400 截断 → 空 tool_calls → run_episode break → INCOMPLETE」因果链。

用量具（冻结层）原始行为，不修改任何冻结文件：
- 继承 agent_arm.Client，只在 complete() 外层记录 finish_reason / tool_calls 数量；
- 对 finish_reason=="length" 且 0 tool_calls 的那一轮，额外用 max_tokens=1600
  重发同一 messages 做「救援探针」（只记录，不把结果交回 agent），
  用来判断空尾到底是「模型主动收工」还是「预算截断」。
- 用冻结 judge.judge() 判 verdict。

输出：raw_turns.json（逐轮原始证据）、summary.json（可重算聚合）、README.md。
运行：python3 repro.py            （需本机 Magpie 网关 127.0.0.1:3425 可用）
"""
import collections
import concurrent.futures
import hashlib
import json
import os
import sys
import time
import urllib.request

ROOT = os.path.dirname(os.path.abspath(__file__))
PILOT = os.path.abspath(os.path.join(ROOT, "..", ".."))
sys.path.insert(0, PILOT)

import agent_arm  # noqa: E402
import formal_runner  # noqa: E402
from judge import judge  # noqa: E402

BASE = "http://127.0.0.1:3425/v1"
MODEL = "volcengine/glm-5.3-flash"
N_CARDS = 16
POLICIES = ("stale", "reactive")   # stale = authority 提示；reactive = recheck 提示
WORKERS = 8
MAX_TURNS = 20
MAX_CALLS = 40


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class CapClient(agent_arm.Client):
    """只观测，不改变冻结层行为。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.log = []

    def _rescue(self, messages):
        """同一 messages 换大预算重发一次，看 tool_calls 是否出现。"""
        payload = {
            "model": self.model,
            "messages": messages,
            "tools": agent_arm.TOOLS,
            "tool_choice": "auto",
            "max_tokens": 1600,
            "temperature": 0,
        }
        req = urllib.request.Request(
            self.base_url + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
        ch = body["choices"][0]
        msg = ch.get("message") or {}
        return {
            "finish": ch.get("finish_reason"),
            "ntc": len(msg.get("tool_calls") or []),
            "completion_tokens": (body.get("usage") or {}).get("completion_tokens"),
        }

    def complete(self, messages: list) -> dict:
        choice = super().complete(messages)          # 冻结层原行为
        msg = choice.get("message") or {}
        ntc = len(msg.get("tool_calls") or [])
        rec = {
            "turn": self.calls,
            "finish": choice.get("finish_reason"),
            "ntc": ntc,
            "content_chars": len(msg.get("content") or ""),
            "reasoning_chars": len(msg.get("reasoning_content") or ""),
        }
        if choice.get("finish_reason") == "length" and ntc == 0:
            try:
                rec["rescue"] = self._rescue(messages)
            except Exception as exc:                 # noqa: BLE001
                rec["rescue_error"] = f"{type(exc).__name__}: {exc}"
        self.log.append(rec)
        return choice                                # 交回的仍是原 choice


def load_cards(n):
    man = json.load(open(os.path.join(PILOT, "runs", "l3-registered-cards", "manifest.json"), encoding="utf-8"))
    out = []
    for entry in man["cards"][:n]:
        p = os.path.join(PILOT, "runs", "l3-registered-cards", entry["file"])
        card = json.load(open(p, encoding="utf-8"))
        if formal_runner.card_sha256(card) != entry["sha256"]:
            raise ValueError(f"card hash mismatch: {entry['file']}")
        out.append(card)
    return out


def work(job):
    card, policy = job
    t0 = time.time()
    client = CapClient(BASE, MODEL, MAX_CALLS, timeout=120.0)
    trace = agent_arm.run_episode(client, card, policy, 0, MAX_TURNS)
    res = judge(trace)
    steps = trace.get("steps") or []
    last_turn = client.log[-1] if client.log else {}
    return {
        "card_id": card["card_id"],
        "policy": policy,
        "verdict": res.get("verdict"),
        "note": res.get("note"),
        "n_turns": len(client.log),
        "n_steps": len(steps),
        "verified_count": (trace.get("final") or {}).get("verified_count"),
        "n_files": (trace.get("final") or {}).get("n_files"),
        "injection": trace.get("injection") is not None,
        "last_finish": last_turn.get("finish"),
        "last_ntc": last_turn.get("ntc"),
        "last_text": (steps[-1].get("text") if steps else None),
        "turns": client.log,
        "wall_s": round(time.time() - t0, 1),
    }


def summarize(records):
    out = {}
    for pol in POLICIES:
        seg = [r for r in records if r["policy"] == pol]
        n = len(seg)
        total_turns = sum(r["n_turns"] for r in seg)
        trunc = sum(1 for r in seg for t in r["turns"] if t["finish"] == "length")
        trunc_empty = [t for r in seg for t in r["turns"] if t["finish"] == "length" and t["ntc"] == 0]
        empty_tail = [r for r in seg if r["last_ntc"] == 0]
        rescued = [t for t in trunc_empty if "rescue" in t]
        out[pol] = {
            "n_episodes": n,
            "verdicts": dict(collections.Counter(r["verdict"] for r in seg)),
            "total_turns": total_turns,
            "turns_finish_length": trunc,
            "turns_finish_length_ratio": round(trunc / max(total_turns, 1), 4),
            "truncated_empty_tool_calls": len(trunc_empty),
            "empty_tail_episodes": len(empty_tail),
            "empty_tail_ratio": round(len(empty_tail) / max(n, 1), 4),
            "empty_tail_last_finish": dict(collections.Counter(r["last_finish"] for r in empty_tail)),
            "empty_tail_verdicts": dict(collections.Counter(r["verdict"] for r in empty_tail)),
            "nonempty_tail_verdicts": dict(collections.Counter(r["verdict"] for r in seg if r["last_ntc"] != 0)),
            "rescue_probes": len(rescued),
            "rescue_tool_calls_nonzero": sum(1 for t in rescued if (t["rescue"].get("ntc") or 0) > 0),
            "rescue_finish": dict(collections.Counter(t["rescue"].get("finish") for t in rescued)),
        }
    # 交叉表：空尾 × 判决
    cross = collections.Counter(
        (r["policy"], "empty_tail" if r["last_ntc"] == 0 else "nonempty_tail", r["verdict"])
        for r in records
    )
    out["crosstab"] = {f"{a}|{b}|{c}": v for (a, b, c), v in sorted(cross.items())}
    return out


def main():
    cards = load_cards(N_CARDS)
    jobs = [(c, p) for c in cards for p in POLICIES]
    print(f"[repro] {len(jobs)} episodes, model={MODEL}, workers={WORKERS}", flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as ex:
        records = list(ex.map(work, jobs))
    raw = {
        "schema": "l3-truncation-repro/v1",
        "base_url": BASE,
        "model": MODEL,
        "n_cards": N_CARDS,
        "policies": list(POLICIES),
        "max_turns": MAX_TURNS,
        "max_tokens_frozen": 400,
        "frozen_hashes": {f: sha256_file(os.path.join(PILOT, f))
                          for f in ("agent_arm.py", "judge.py", "engine.py")},
        "records": records,
    }
    with open(os.path.join(ROOT, "raw_turns.json"), "w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=False, indent=1)
    summary = summarize(records)
    with open(os.path.join(ROOT, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=1), flush=True)


if __name__ == "__main__":
    main()
