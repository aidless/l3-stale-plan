#!/usr/bin/env python3
"""只清 v2sc run 中 transport_loss=True 的记录（通道烧盘），让 --resume 能重试这些格子。

铁律：真实跑过且 transport_loss=False 的 INCOMPLETE/STALE/REC 一律保留；
      judgement/trace/state.done_slugs 三处一起清，不留孤儿。
"""
import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path


def purge(run_dir: Path, apply: bool) -> dict:
    jdir = run_dir / "judgements"
    tdir = run_dir / "traces"
    sp = run_dir / "state.json"
    if not sp.exists():
        return {"ok": False, "error": "state.json missing"}
    state = json.loads(sp.read_text(encoding="utf-8"))
    before = len(state["done_slugs"])
    bad, kept, missing = [], [], []
    for jf in sorted(jdir.glob("*.json")):
        rec = json.loads(jf.read_text(encoding="utf-8"))
        (bad if rec.get("transport_loss") else kept).append(jf)
    for slug in state["done_slugs"]:
        if not (jdir / f"{slug}.json").exists():
            missing.append(slug)
    removed = []
    if apply:
        for jf in bad:
            slug = jf.stem
            (tdir / f"{slug}.json").unlink(missing_ok=True)
            jf.unlink()
            removed.append(slug)
        state["done_slugs"] = [s for s in state["done_slugs"] if s not in removed]
        fd, tmp = tempfile.mkstemp(dir=str(run_dir), prefix=".state-", suffix=".json")
        with open(fd, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=1)
        Path(tmp).replace(sp)
    return {
        "ok": True, "applied": apply, "transport_loss_found": len(bad),
        "kept": len(kept), "removed": removed,
        "done_slugs_before": before,
        "done_slugs_after": before - len(removed) if apply else before,
        "orphan_done_slugs": missing,
    }


def selftest() -> int:
    with tempfile.TemporaryDirectory() as td:
        d = Path(td)
        (d / "judgements").mkdir(); (d / "traces").mkdir()
        def mk(slug, loss, verdict):
            (d / "judgements" / f"{slug}.json").write_text(
                json.dumps({"slug": slug, "transport_loss": loss, "verdict": verdict}))
            (d / "traces" / f"{slug}.json").write_text("{}")
        mk("bad", True, "INCOMPLETE")
        mk("good_inc", False, "INCOMPLETE")
        mk("good_stale", False, "STALE_FAILURE")
        (d / "state.json").write_text(json.dumps({
            "finished": False, "planned": 4,
            "done_slugs": ["bad", "good_inc", "good_stale", "orphan"]}))
        r = purge(d, apply=True)
        assert r["transport_loss_found"] == 1, r
        assert r["removed"] == ["bad"], r
        assert r["done_slugs_after"] == 3, r                 # bad + orphan 出列
        assert r["orphan_done_slugs"] == ["orphan"], r
        assert not (d / "judgements" / "bad.json").exists()
        assert not (d / "traces" / "bad.json").exists()
        assert (d / "judgements" / "good_inc.json").exists()  # 真 INC 必须留
        assert (d / "judgements" / "good_stale.json").exists()
        print("[PASS] GREEN 只清 transport_loss，真 INCOMPLETE/STALE 保留")
        # RED：把真 INC 改成 transport_loss 再跑，必须清掉（证明门不是按 verdict 清）
        jf = d / "judgements" / "good_inc.json"
        rec = json.loads(jf.read_text()); rec["transport_loss"] = True
        jf.write_text(json.dumps(rec))
        r2 = purge(d, apply=True)
        assert r2["removed"] == ["good_inc"], r2
        print("[PASS] RED 按 transport_loss 清（不按 verdict），门会红也会绿")
    print("SELFTEST PASS")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.run_dir:
        ap.error("--run-dir required")
    r = purge(Path(a.run_dir), a.apply)
    print(json.dumps(r, ensure_ascii=False, indent=1))
    return 0 if r["ok"] else 2


if __name__ == "__main__":
    sys.exit(main())
