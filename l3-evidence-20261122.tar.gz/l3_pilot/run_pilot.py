#!/usr/bin/env python3
"""Generate L3 pilot traces, judgements, and an aggregate report.

Usage: python3 run_pilot.py --out runs/l3-pilot-v1
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from cards import write_cards
from engine import POLICIES, load_card, run_card
from judge import VERDICT_STALE, judge

ROOT = Path(__file__).resolve().parent


def stable_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=ROOT / "runs" / "l3-pilot-v1")
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()

    out = args.out.resolve()
    cards_dir = out / "cards"
    traces_dir = out / "traces"
    judgements_dir = out / "judgements"
    traces_dir.mkdir(parents=True, exist_ok=True)
    judgements_dir.mkdir(parents=True, exist_ok=True)

    cards = write_cards(cards_dir)
    card_paths = {card["card_id"]: cards_dir / f"{card['card_id']}.json" for card in cards}
    records = []

    for card in cards:
        loaded = load_card(card_paths[card["card_id"]])
        for policy in POLICIES:
            for repeat in range(args.repeats):
                trace = run_card(loaded, policy, repeat)
                trace_path = traces_dir / f"{card['card_id']}-{policy}-r{repeat}.json"
                trace_path.write_text(json.dumps(trace, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

                judgement = judge(trace)
                judgement["trace_sha256"] = stable_hash(trace_path)
                judgement_path = judgements_dir / f"{card['card_id']}-{policy}-r{repeat}.json"
                judgement_path.write_text(
                    json.dumps(judgement, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
                )
                records.append(
                    {
                        "card_id": card["card_id"],
                        "policy": policy,
                        "repeat": repeat,
                        "verdict": judgement["verdict"],
                        "metrics": judgement["metrics"],
                        "trace": str(trace_path.relative_to(out)),
                        "judgement": str(judgement_path.relative_to(out)),
                        "trace_sha256": judgement["trace_sha256"],
                    }
                )

    summary = {}
    for policy in POLICIES:
        rows = [row for row in records if row["policy"] == policy]
        summary[policy] = {
            "n": len(rows),
            "stale_failure_count": sum(row["verdict"] == VERDICT_STALE for row in rows),
            "stale_failure_rate": sum(row["verdict"] == VERDICT_STALE for row in rows) / len(rows),
            "mean_tool_call_count": sum(row["metrics"]["tool_call_count"] for row in rows) / len(rows),
            "mean_token_proxy": sum(row["metrics"]["token_proxy"] for row in rows) / len(rows),
            "mean_repeat_action_count": sum(row["metrics"]["repeat_action_count"] for row in rows) / len(rows),
            "mean_verified_count": sum(row["metrics"]["verified_count"] for row in rows) / len(rows),
        }

    report = {
        "schema": "l3-pilot-report/v1",
        "run_id": out.name,
        "source": "simulated_no_llm",
        "no_llm_calls": True,
        "status": "INSTRUMENT_VALIDATION_ONLY",
        "what_this_proves": "the trace schema and deterministic judge are wired and mutable; no model behaviour is measured",
        "what_this_does_not_prove": "H3a/H3b/H3c are untouched; no claims about memory policies",
        "n_cards": len(cards),
        "n_policies": len(POLICIES),
        "n_repeats": args.repeats,
        "n_records": len(records),
        "cards_manifest_sha256": stable_hash(cards_dir / "manifest.json"),
        "ruler": "deterministic_state_machine_v1",
        "summary": summary,
        "records": records,
    }
    report_path = out / "report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {len(records)} records -> {report_path}")
    for policy, values in summary.items():
        print(
            f"  {policy:14s} stale={values['stale_failure_count']}/{values['n']}"
            f" tool_calls={values['mean_tool_call_count']:.1f}"
            f" token_proxy={values['mean_token_proxy']:.1f}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
