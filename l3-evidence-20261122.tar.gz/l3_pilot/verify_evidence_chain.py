#!/usr/bin/env python3
"""证据链闸门：聚合数字必须有对应逐条载体，且可从载体重算。

来源：2026-11-11 事故——2880 因子跑的 8 个分片目录随 AMD 实例销毁丢失，
本地只剩 `runs/l3-fact-240x6x2-analysis/factorial_2880.json` 聚合表。
铁律 1「数字可复算」要求：没有 judgement/trace 载体的聚合数字一律判 VERIFY，
不得写进结论。

用法：
  python3 verify_evidence_chain.py --run-dir runs/l3-runA-50x2x3
  python3 verify_evidence_chain.py --aggregate runs/l3-fact-240x6x2-analysis/factorial_2880.json \
      --shards-glob 'runs/l3-fact-240x6x2-shard*/judgements/*.json'
  python3 verify_evidence_chain.py --selftest      # RED + GREEN 两段
"""
import argparse
import collections
import glob
import json
import os
import sys
import tempfile
from pathlib import Path

PILOT = Path(__file__).resolve().parent


def _jload(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def verdict_of(obj):
    return obj.get("verdict")


def check_run_dir(run_dir: Path) -> dict:
    """完整 run：report.json 的 n_records / records 必须与三处载体逐条对齐。"""
    errors = []
    report_p = run_dir / "report.json"
    if not report_p.is_file():
        return {"ok": False, "errors": [f"MISSING report.json: {report_p}"]}
    report = _jload(report_p)
    n = report.get("n_records")
    records = report.get("records") or []
    if not isinstance(n, int):
        errors.append("report.json 缺整数 n_records")
    if records and len(records) != n:
        errors.append(f"report.records={len(records)} != n_records={n}")
    # 逐条载体
    for sub in ("judgements", "traces"):
        files = sorted((run_dir / sub).glob("*.json")) if (run_dir / sub).is_dir() else []
        if len(files) != n:
            errors.append(f"MISSING CARRIER: {sub}/ 有 {len(files)} 份，n_records={n}")
    # 载体状态文件：v1 formal_state_v2.json（含 records）；v2 runners 用 state.json（含 records）
    state_p = run_dir / "formal_state_v2.json"
    if not state_p.is_file():
        state_p = run_dir / "state.json"
    if not state_p.is_file():
        errors.append(f"MISSING CARRIER: {run_dir / 'formal_state_v2.json'} 或 state.json")
    else:
        state = _jload(state_p)
        sr = state.get("records") or []
        if len(sr) != n:
            # v2 runners: state 只存 done_slugs，records 落 judgements/（已在上面逐份对齐）
            slugs = state.get("done_slugs") or []
            if isinstance(slugs, list) and len(slugs) != n:
                errors.append(f"state(done_slugs)={len(slugs)} != n_records={n}")
            elif not isinstance(slugs, list):
                errors.append(f"state.records={len(sr)} != n_records={n}")
    # 判决分布可重算
    if records:
        dist = dict(collections.Counter(verdict_of(r) for r in records))
        inc = dist.get("INCOMPLETE", 0)
        if report.get("incomplete") != inc:
            errors.append(f"report.incomplete={report.get('incomplete')} != 重算 {inc}")
        loss = report.get("loss_rate")
        if isinstance(loss, (int, float)) and n and abs(loss - inc / n) > 1e-9:
            errors.append(f"loss_rate={loss} != 重算 {inc / n:.6f}")
    return {"ok": not errors, "n_records": n, "errors": errors,
            "verdict_dist": dict(collections.Counter(verdict_of(r) for r in records))}


def check_aggregate(aggregate: Path, shards_glob: str) -> dict:
    """聚合表：每个 cell 的 n / stale / recovered / incomplete 必须从 judgement 载体重算。"""
    errors = []
    agg = _jload(aggregate)
    files = sorted(glob.glob(shards_glob))
    if not files:
        return {"ok": False, "errors": [
            "MISSING CARRIER: 聚合表存在但没有任何逐条 judgement 载体；"
            f"pattern={shards_glob!r} → 所有数字标 VERIFY，不得写进结论"]}
    by_key = {}
    for p in files:
        r = _jload(p)
        by_key[(r.get("model"), r.get("cell"))] = by_key.get((r.get("model"), r.get("cell")), 0) + 1
    for model, block in agg.items():
        if not isinstance(block, dict) or "cells" not in block:
            errors.append(f"聚合表 {model} 缺 cells")
            continue
        for cell, claim in block["cells"].items():
            n = by_key.get((model, cell), 0)
            if n != claim.get("n"):
                errors.append(f"{model}/{cell}: 载体 {n} 份 != 声称 n={claim.get('n')}")
    return {"ok": not errors, "n_carrier_files": len(files), "errors": errors}


def selftest():
    results = []
    run_a = PILOT / "runs" / "l3-runA-50x2x3"
    # GREEN 1：完整 run 必须放行
    g1 = check_run_dir(run_a)
    results.append(("GREEN 完整 run 放行", g1["ok"], g1))
    # RED 1：篡改 n_records 必须阻断
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        (t / "judgements").mkdir(); (t / "traces").mkdir()
        rep = _jload(run_a / "report.json")
        rep["n_records"] = 999
        (t / "report.json").write_text(json.dumps(rep), encoding="utf-8")
        (t / "formal_state_v2.json").write_text(
            (run_a / "formal_state_v2.json").read_text(encoding="utf-8"), encoding="utf-8")
        r1 = check_run_dir(t)
        results.append(("RED 篡改 n_records 阻断", not r1["ok"], r1))
    # RED 2：只有聚合表、无逐条载体必须阻断（本次真实事故）
    agg = PILOT / "runs" / "l3-fact-240x6x2-analysis" / "factorial_2880.json"
    if agg.is_file():
        r2 = check_aggregate(agg, str(PILOT / "runs" / "l3-fact-240x6x2-shard*" / "judgements" / "*.json"))
        results.append(("RED 聚合表无载体阻断", not r2["ok"], r2))
    # GREEN 2：造一份只有 1 条载体的最小聚合表必须放行
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        (t / "judgements").mkdir()
        (t / "judgements" / "one.json").write_text(
            json.dumps({"model": "M", "cell": "C", "verdict": "RECOVERED"}), encoding="utf-8")
        (t / "agg.json").write_text(
            json.dumps({"M": {"cells": {"C": {"n": 1}}}}), encoding="utf-8")
        g2 = check_aggregate(t / "agg.json", str(t / "judgements" / "*.json"))
        results.append(("GREEN 最小载体放行", g2["ok"], g2))
    ok = True
    for name, passed, detail in results:
        print(("[PASS] " if passed else "[FAIL] ") + name)
        if not passed:
            print("       ", json.dumps(detail, ensure_ascii=False)[:400])
            ok = False
    print("SELFTEST", "PASS" if ok else "FAIL")
    return 0 if ok else 2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir")
    ap.add_argument("--aggregate")
    ap.add_argument("--shards-glob", default="")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if args.run_dir:
        res = check_run_dir(Path(args.run_dir))
    elif args.aggregate:
        res = check_aggregate(Path(args.aggregate), args.shards_glob)
    else:
        ap.print_help()
        return 2
    print(json.dumps(res, ensure_ascii=False, indent=1))
    return 0 if res["ok"] else 2


if __name__ == "__main__":
    sys.exit(main())
