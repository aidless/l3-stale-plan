#!/usr/bin/env python3
"""把 D6（3×2 因子解混杂）追加到 DEVIATION_L3.md —— 只追加，不改原文。

纪律（AGENTS.md 第 16 条精神）：不用 open(p,"w") 整份写回，
用 O_APPEND 单次写，写前写后断言前缀一致。
"""
import hashlib
import os
from pathlib import Path

DOC = Path(__file__).resolve().parent.parent / "DEVIATION_L3.md"

BLOCK = """
## D6（2026-11-10）：H3b 的 100pp 被提示混杂污染 —— 3×2 因子解混杂实验结果

### D6.1 为什么要做这个偏离

Karpathy 视角评审（`persona-board/reviews/andrej-karpathy.md`）指出 Run A 的
`diff_pp = 100.0` 不能归因于"删除归因条目 m-plan"。主会话读冻结代码复核，
确认 B 臂与 D 臂**一次差三件事**（不是猜的，行号可核）：

| 差异 | B（policy="stale"） | D（policy="memory_delete"） |
|---|---|---|
| memory 行 | 含 m-plan | 去掉 m-plan（`agent_arm.py:124-125`） |
| 规则行 | "You may use `stat`, but the stored plan is the default authority."（`agent_arm.py:130`，`stat_visible=False`） | "Environment changes can happen at any time; only `stat` tells you the truth."（`agent_arm.py:128`） |
| 注入后提示 | "The stored plan is still expected to be valid; re-check only if a write is rejected."（`agent_arm.py:313-322`） | "Re-check the environment with `stat` before your next write."（`agent_arm.py:323-332`） |

三处同时在动，所以 Run A 的 100pp 是**三因素打包效应**，PREREG §2 命名的机制
（"删除归因条目 m-plan"）从未被单独识别。这是判定口径的实质问题，必须先量清楚
再决定要不要投 2880 episode 的全量确认性跑。

### D6.2 实验设计（只动未冻结编排层）

新文件 `l3_pilot/factorial_3x2.py`（**未冻结**；不改 judge/engine/cards/cards_agent/
agent_arm/power_l3 一行，也不改 formal_runner.py / formal_runner_mt.py）。

两个因素正交：

- 因素 P（提示模式）：`authority` = `policy="stale"`；`recheck` = `policy="reactive"`
  —— policy 只控制**提示文本**，不再承担记忆移除职责。
- 因素 M（记忆移除）：在**卡片层**深拷贝后删 memory 行（`keep` / `del_plan`=m-plan /
  `del_quota`=m-quota）。这样两项因素真正正交，不像冻结版 `memory_delete` 那样
  把"删 m-plan"和"换提示"绑死。

6 格 = 2×3：`A_keep`（≡条件 B）/ `A_del_plan` / `A_del_quota` / `R_keep`（关键格）/
`R_del_plan`（≡条件 D）/ `R_del_quota`（≡条件 R）。

**关键格 `R_keep`**：recheck 提示 + 记忆完全不动。它此前从未被跑过
—— 条件 R 删的是 m-quota，条件 D 改的是 prompt+memory 两处。

### D6.3 结果（12 卡 × 6 格 × 1 repeat = 72 episode，模型 `opencode-go/deepseek-v4.1-flash`）

产物：`l3_pilot/runs/l3-factorial-3x2-smoke/report.json`（schema `l3-factorial-report/v1`），
traces 72 条 + judgements 72 条，墙钟 333.2s（6 worker）。

| 格 | 提示 | 记忆 | n | STALE | REC | INC | stale_rate | rec_rate |
|---|---|---|---|---|---|---|---|---|
| `A_keep` ≡B | authority | 不动 | 12 | 10 | 0 | 2 | **0.833** | 0.000 |
| `A_del_plan` | authority | 删 m-plan | 12 | 9 | 0 | 3 | 0.750 | 0.000 |
| `A_del_quota` | authority | 删 m-quota | 12 | 8 | 0 | 4 | 0.667 | 0.000 |
| **`R_keep`** | recheck | **不动** | 12 | **0** | 5 | 7 | **0.000** | 0.417 |
| `R_del_plan` ≡D | recheck | 删 m-plan | 12 | 0 | 5 | 7 | 0.000 | 0.417 |
| `R_del_quota` ≡R | recheck | 删 m-quota | 12 | 0 | 6 | 6 | 0.000 | 0.500 |

配对对照（同 model/card/replay、双方都 effective 才算一对）：

| 对照 | 有效对 | 方向 | diff_pp | McNemar 精确 p |
|---|---|---|---|---|
| 提示效应（记忆不动）：`A_keep` vs `R_keep` | 5 | 5→0 | **100.0** | 0.0625 |
| **记忆效应（提示固定 authority）：`A_keep` vs `A_del_plan`** | 9 | **0→0** | **0.0** | **1.0** |
| 随机对照（提示固定 authority）：`A_keep` vs `A_del_quota` | 8 | 0→0 | 0.0 | 1.0 |
| 复现 Run A 的 B/D：`A_keep` vs `R_del_plan` | 5 | 5→0 | 100.0 | 0.0625 |

### D6.4 结论（三句）

1. **记忆移除是惰性的**：提示固定为 authority 时，删 m-plan 与删 m-quota 的对拍
   方向都是 0→0、diff 0.0、p=1.0 —— 在 9 个有效配对里**一次 stale↔recovered 翻转都没有**。
   删"归因条目"与删"随机条目"逐格相同（0.750 vs 0.667 的差别全部来自 INCOMPLETE 位移，
   不是翻转）。
2. **效应全部来自提示**：recheck 提示下三格 stale_rate 一律 0.000，与记忆动不动无关；
   authority 提示下三格 stale_rate 0.667–0.833。`A_keep` vs `R_keep` 在记忆完全相同的情况下
   差 100pp（5→0）。
3. **因此 Run A 的 `diff_pp=100.0` 不能归因于"删除归因条目 m-plan"**。它是
   "把 stat 说成唯一真相 + 明确要求复核"这套提示的效应；记忆删除在这批数据里没有可测贡献。
   PREREG §2 命名的机制 **不成立**；打包处理（B vs D）的差异 **成立**。

### D6.5 对全量跑的影响（裁决）

**不投 2880 episode 的确认性全量跑。** 理由：在混杂未分离的设计上把样本从 40 加到 720，
只会把 MDE 从 6.6pp 压到 3pp，**偏倚一点不减**，得到的是一个归因错误的"确认性支持"。
这违反 AGENTS.md 铁律 1（数字可复算→此处是"归因可复算"）与 PREREG §2 的机制命名。

正确的下一步（需预注册修订，不在本偏离内擅自动手）：
- **设计 v2**：把提示冻成常量（两条件同一套提示），只操作记忆 → 直接测 PREREG 命名的机制。
- 若仍想保打包处理，则把 H3b 改写成"H3b′：recheck 提示打包的效应"，并**同时**登记
  记忆因素的零效应作为副结果。

### D6.6 局限（照实写）

- n=12/格、1 个模型、1 个 repeat；`R_keep` 格 7/12 INCOMPLETE（loss 0.4028），
  有效对只有 5–9 对，McNemar p=0.0625 与 1.0 都在小样本下。
- 但方向是**全同向**的：recheck 三格 0/36 次 STALE、authority 三格 27/36 次 STALE，
  加上记忆对照 0 翻转 —— 在这个样本上不存在"记忆有用"的证据。
- 判读按预注册纪律：**只作筛选性结论，不作确证性判定**（本表不进 H3b 判定）。

### D6.7 复现命令

```bash
cd l3_pilot
python3 factorial_3x2.py --selftest          # 16 条断言（含 2 条 RED）
python3 factorial_3x2.py \\
  --models opencode-go/deepseek-v4.1-flash \\
  --cards-manifest runs/l3-registered-cards/manifest.json \\
  --n-units 12 --repeats 1 --workers 6 \\
  --base-url http://127.0.0.1:13426/v1 \\
  --out runs/l3-factorial-3x2-smoke --resume
```
"""


def main() -> int:
    before = DOC.read_bytes()
    before_hash = hashlib.sha256(before).hexdigest()
    assert DOC.exists() and len(before) > 0, "DEVIATION_L3.md 不存在或为空"
    assert b"## D6" not in before, "D6 已存在，拒绝重复追加"

    payload = BLOCK.encode("utf-8")
    fd = os.open(DOC, os.O_WRONLY | os.O_APPEND)
    try:
        os.write(fd, payload)
    finally:
        os.close(fd)

    after = DOC.read_bytes()
    assert after.startswith(before), "追加后前缀不一致 —— 文件被改写，需人工核查"
    assert hashlib.sha256(after[: len(before)]).hexdigest() == before_hash, "前缀哈希不一致"
    assert b"## D6" in after, "追加未落盘"
    print(f"OK: D6 appended, {len(payload)} bytes; file {len(before)} -> {len(after)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
