#!/usr/bin/env python3
"""Generate the 240 registered L3 cards without touching frozen cards_agent.py."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import cards_agent

ROOT = Path(__file__).resolve().parent
PRIMARY = ("store-a", "bucket-x", "node-1", "cache-p", "vol-main")
ALT = ("store-b", "bucket-y", "node-2", "cache-q", "vol-backup")
INJECT_AFTER_FILES = (4, 8, 12, 16, 20)


def canonical(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def build_registered_card(index: int) -> dict:
    base = cards_agent.build_card(cards_agent.CARD_SPECS[0])
    seed = 100000 + index * 7919
    group = index % 5
    card = dict(base)
    card.update(
        {
            "card_id": f"L3-R{index:04d}",
            "seed": seed,
            "inject_after_files": INJECT_AFTER_FILES[index % len(INJECT_AFTER_FILES)],
            "resources": [PRIMARY[group], ALT[group]],
            "target_v1": f"/dst/{seed}/v1",
            "target_v2": f"/dst/{seed}/v2",
            "success_condition": "all files written to the current target path",
            "injection": {
                "kind": "plan_invalidation",
                "effect": (
                    f"{PRIMARY[group]} becomes unavailable, target becomes "
                    f"/dst/{seed}/v2, plan_version 1 -> 2"
                ),
            },
        }
    )
    card["memory"] = [
        {
            "id": "m-plan",
            "kind": "plan",
            "version": 1,
            "text": f"use {PRIMARY[group]} -> /dst/{seed}/v1",
            "culprit": True,
        },
        {"id": "m-quota", "kind": "fact", "version": 1, "text": "write quota is 40", "culprit": False},
        {"id": "m-format", "kind": "fact", "version": 1, "text": "payload format is jsonl", "culprit": False},
    ]
    card.pop("card_sha256", None)
    card["card_sha256"] = hashlib.sha256(canonical(card).encode("utf-8")).hexdigest()
    return card


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=240)
    parser.add_argument("--out", type=Path, default=ROOT / "runs" / "l3-registered-cards")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    cards = [build_registered_card(i) for i in range(args.n)]
    for card in cards:
        (out / f"{card['card_id']}.json").write_text(
            json.dumps(card, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    manifest = {
        "schema": "l3-registered-card-manifest/v1",
        "n_cards": len(cards),
        "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "cards": [
            {"card_id": card["card_id"], "file": f"{card['card_id']}.json", "sha256": card["card_sha256"]}
            for card in cards
        ],
    }
    (out / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"wrote {len(cards)} cards -> {out / 'manifest.json'}")
    print(f"manifest sha256 {hashlib.sha256((out / 'manifest.json').read_bytes()).hexdigest()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
