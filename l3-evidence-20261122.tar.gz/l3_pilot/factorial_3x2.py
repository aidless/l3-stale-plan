#!/usr/bin/env python3
"""L3 三因素解混杂实验（提示模式 × 记忆移除 的 3×2 因子网格）。

为什么存在
----------
Karpathy 视角评审（`persona-board/reviews/andrej-karpathy.md`）指出：Run A 的
`diff_pp = 100.0` 不能归因于"删除归因条目 m-plan"，因为 B 臂与 D 臂**一次差三件事**。
主会话读代码复核确认（不是猜的）：

| 差异 | B（policy="stale"） | D（policy="memory_delete"） |
|---|---|---|
| memory 行 | 含 m-plan | 去掉 m-plan（`agent_arm.py:124-125`） |
| 规则行 | "stored plan is the default authority"（`agent_arm.py:130`，stat_visible=False） | "only `stat` tells you the truth"（`agent_arm.py:128`） |
| 注入后提示 | "stored plan is still expected to be valid; re-check only if a write is rejected"（`agent_arm.py:313-322`） | "Re-check the environment with `stat` before your next write"（`agent_arm.py:323-332`） |

三处同时在动，所以 100pp 里哪一部分属于"删归因条目"是未分离的混杂。
本文件只动**未冻结的编排层**，把两个因素正交拆开：

  因素 P（提示模式）：authority = policy="stale"（stat 不是权威 + 注入后劝不要复核）
                      recheck   = policy="reactive"（stat 是唯一真相 + 注入后要求先复核）
  因素 M（记忆移除）：keep = 原卡 / del_plan = 移除 m-plan（归因条目）/ del_quota = 移除 m-quota（随机条目）

  6 格：A_keep / A_del_plan / A_del_quota / R_keep / R_del_plan / R_del_quota
  其中 A_keep ≡ 条件 B、R_del_plan ≡ 条件 D、R_del_quota ≡ 条件 R（复现校验用）。

关键格是 **R_keep（recheck 提示 + 记忆完全不动）**：
  - 若 R_keep 的 stale_rate 仍然很低（≤0.20），说明**提示独自就能消除失效率**，
    记忆删除不是必要成分 → H3b 的 100pp 被混杂污染，2880 episode 的全量跑本身不能归因。
  - 若 R_keep 的 stale_rate 仍高（≥0.80），说明提示不是主因，删记忆才是真效应 →
    H3b 的因果故事站得住，全量跑有意义。
  - 中间值 → 部分混杂，需要按效应量分摊。

纪律
----
1. 不改动任何冻结文件（judge.py / engine.py / cards.py / cards_agent.py /
   agent_arm.py / power_l3.py 一行不碰），也不改 formal_runner.py / formal_runner_mt.py。
2. 卡片逐张 sha256 校验（复用 `formal_runner.load_card`，篡改即抛错）。
3. 记忆移除在**卡片层**做（深拷贝），不借助 policy="memory_delete" 的隐式过滤 ——
   这样 P 与 M 才真正正交：policy 只控制提示文本，移除只控制 memory 行。
4. 本文件的产物**不进 PREREG 的确认性判定**，只用于偏离登记（DEVIATION_L3.md D6）
   与后续设计修正。

用法
----
  python3 factorial_3x2.py --selftest
  python3 factorial_3x2.py --models opencode-go/deepseek-v4.1-flash \
      --n-units 3 --repeats 1 --workers 6 --out runs/l3-factorial-3x2-smoke
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import agent_arm  # noqa: E402  冻结
from judge import judge  # noqa: E402  冻结
import formal_runner as fr  # noqa: E402  编排层复用

# ---------------------------------------------------------------------------
# 因子定义：6 格
# ---------------------------------------------------------------------------
POLICY_OF = {"authority": "stale", "recheck": "reactive"}
REMOVE_OF = {"keep": None, "del_plan": "m-plan", "del_quota": "m-quota"}

CELLS: list[tuple[str, str, str]] = [
    (f"{'A' if p == 'authority' else 'R'}_{m}", p, m)
    for p in ("authority", "recheck")
    for m in ("keep", "del_plan", "del_quota")
]


def build_card(card: dict, remove_id: str | None) -> dict:
    """深拷贝卡片并按 remove_id 去掉一条 memory；remove_id 不存在即抛错（RED 守卫）。"""
    edited = json.loads(json.dumps(card))
    if remove_id is None:
        return edited
    ids = [m["id"] for m in edited["memory"]]
    if remove_id not in ids:
        raise ValueError(f"remove_id {remove_id} 不在卡片 {card['card_id']} 中: {ids}")
    edited["memory"] = [m for m in edited["memory"] if m["id"] != remove_id]
    return edited


def make_client(base_url: str, model: str, max_calls: int):
    """每个 episode 一个全新 Client。

    agent_arm.Client 把 calls/prompt_tokens/completion_tokens 挂在实例上，没有 reset()；
    复用实例会让同一 worker 的第 2 个 episode 开口即 raise Budget，表现为 steps=0 的
    瞬时 INCOMPLETE（2026-11-11 实测烧掉 94.7%）。集中一处，selftest 有守卫。
    """
    return agent_arm.Client(base_url, model, max_calls)


def slug_for(model: str, card_id: str, cell: str, repeat: int) -> str:
    return f"{model.replace('/', '_')}__{card_id}__{cell}__r{repeat}"


def run_cell(client, card: dict, cell: str, prompt_mode: str, remove_mode: str,
             repeat: int, max_turns: int) -> dict:
    policy = POLICY_OF[prompt_mode]
    edited = build_card(card, REMOVE_OF[remove_mode])
    trace = agent_arm.run_episode(client, edited, policy, repeat, max_turns)
    verdict = judge(trace)
    return {
        "card_id": card["card_id"],
        "cell": cell,
        "prompt_mode": prompt_mode,
        "remove_mode": remove_mode,
        "policy": policy,
        "removed_memory_id": REMOVE_OF[remove_mode],
        "replay": repeat,
        "verdict": verdict["verdict"],
        "metrics": verdict["metrics"],
        "usage": trace["usage"],
        "budget_exhausted": trace["budget_exhausted"],
        "errors": trace["errors"],
        "injection": trace["injection"],
        "trace": trace,
    }


# ---------------------------------------------------------------------------
# 汇总
# ---------------------------------------------------------------------------
def summarize(records: list[dict]) -> dict:
    def block(rows: list[dict]) -> dict:
        n = len(rows)
        rec = sum(1 for r in rows if r["verdict"] == "RECOVERED")
        stale = sum(1 for r in rows if r["verdict"] == "STALE_FAILURE")
        inc = sum(1 for r in rows if r["verdict"] == "INCOMPLETE")
        toks = [r["usage"].get("prompt_tokens", 0) + r["usage"].get("completion_tokens", 0) for r in rows]
        steps = [r.get("n_steps_taken", len(r.get("trace", {}).get("steps", []))) for r in rows]
        return {
            "n": n,
            "recovered": rec,
            "stale_failure": stale,
            "incomplete": inc,
            "stale_rate": round(stale / n, 4) if n else None,
            "recovered_rate": round(rec / n, 4) if n else None,
            "mean_tokens": round(sum(toks) / n, 1) if n else None,
            "mean_steps": round(sum(steps) / n, 2) if n else None,
        }

    cells: dict[str, dict] = {}
    for cell, _p, _m in CELLS:
        cells[cell] = block([r for r in records if r["cell"] == cell])

    per_model: dict[str, dict] = {}
    for model in sorted({r.get("model") or "" for r in records}):
        rows = [r for r in records if (r.get("model") or "") == model]
        per_model[model] = {c: block([r for r in rows if r["cell"] == c]) for c in cells}

    # 三个解混杂对照（配对口径：同 (model, card_id, replay) 两格都 effective 才算一对）
    def paired(cell_x: str, cell_y: str) -> dict:
        key = lambda r: (r.get("model"), r["card_id"], r["replay"])  # noqa: E731
        xs = {key(r): r for r in records if r["cell"] == cell_x and fr.is_effective(r["verdict"])}
        ys = {key(r): r for r in records if r["cell"] == cell_y and fr.is_effective(r["verdict"])}
        common = sorted(set(xs) & set(ys))
        b = sum(1 for k in common if xs[k]["verdict"] == "STALE_FAILURE" and ys[k]["verdict"] == "RECOVERED")
        c = sum(1 for k in common if xs[k]["verdict"] == "RECOVERED" and ys[k]["verdict"] == "STALE_FAILURE")
        return {
            "cells": [cell_x, cell_y],
            "valid_pairs": len(common),
            "stale_only_in_" + cell_x: b,
            "stale_only_in_" + cell_y: c,
            "diff_pp": round(100.0 * (b - c) / len(common), 2) if common else None,
            "mcnemar_exact_p": fr.exact_binom_two_sided(b, c) if common else None,
        }

    contrasts = {
        "prompt_effect_memory_held（提示效应，记忆不动）": paired("A_keep", "R_keep"),
        "memory_effect_prompt_authority（删记忆效应，提示固定权威）": paired("A_keep", "A_del_plan"),
        "random_control_prompt_authority（删随机条目，提示固定权威）": paired("A_keep", "A_del_quota"),
        "reproduce_B_vs_D（复现 Run A 的 B/D 对照）": paired("A_keep", "R_del_plan"),
    }

    n_records = len(records)
    incomplete = sum(1 for r in records if r["verdict"] == "INCOMPLETE")
    return {
        "schema": "l3-factorial-report/v1",
        "cells": cells,
        "per_model": per_model,
        "contrasts": contrasts,
        "n_records": n_records,
        "incomplete": incomplete,
        "loss_rate": round(incomplete / n_records, 4) if n_records else None,
        "note": (
            "本报告只做因子解混杂，不参与 PREREG 确认性判定。"
            "关键判读格 = R_keep（recheck 提示 + 记忆不动）："
            "stale_rate ≤0.20 说明提示独自就消除失效率，H3b 归因不成立；"
            "≥0.80 说明提示不是主因，删记忆才是真效应。"
        ),
    }


# ---------------------------------------------------------------------------
# 自测（不联网，RED→GREEN）
# ---------------------------------------------------------------------------
def selftest() -> int:
    failures: list[str] = []

    def check(name: str, ok: bool, detail: str = "") -> None:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}{(' — ' + detail) if detail and not ok else ''}")
        if not ok:
            failures.append(name)

    # GREEN 1：6 格枚举与因子正交
    check("6 格枚举", len(CELLS) == 6, str(CELLS))
    check("格名", [c[0] for c in CELLS] ==
          ["A_keep", "A_del_plan", "A_del_quota", "R_keep", "R_del_plan", "R_del_quota"],
          str([c[0] for c in CELLS]))
    check("P×M 正交", len({(p, m) for _c, p, m in CELLS}) == 6)
    check("authority→stale", POLICY_OF["authority"] == "stale")
    check("recheck→reactive", POLICY_OF["recheck"] == "reactive")

    # GREEN 2：卡片编辑只动 memory，不动其它字段
    card = {
        "card_id": "T-1",
        "n_steps": 2,
        "files": ["a", "b"],
        "success_condition": "x",
        "memory": [
            {"id": "m-plan", "kind": "plan", "text": "old plan"},
            {"id": "m-quota", "kind": "quota", "text": "quota"},
        ],
    }
    keep = build_card(card, None)
    drop = build_card(card, "m-plan")
    check("keep 不改卡", keep == card)
    check("del_plan 只删一条", [m["id"] for m in drop["memory"]] == ["m-quota"])
    check("原卡未被污染", len(card["memory"]) == 2)
    check("其它字段不变", {k: v for k, v in drop.items() if k != "memory"} ==
          {k: v for k, v in card.items() if k != "memory"})

    # RED：移除不存在的 memory 必须抛错
    try:
        build_card(card, "m-nope")
        check("RED 移除不存在条目应抛错", False, "没有抛错")
    except ValueError:
        check("RED 移除不存在条目应抛错", True)

    # RED：未知 prompt_mode 必须键错
    try:
        POLICY_OF["bogus"]
        check("RED 未知 prompt_mode 应 KeyError", False, "没有抛错")
    except KeyError:
        check("RED 未知 prompt_mode 应 KeyError", True)

    # GREEN 3：slug 稳定且含格名
    s = slug_for("m/x", "L3-R0001", "R_keep", 1)
    check("slug 形状", s == "m_x__L3-R0001__R_keep__r1", s)

    # GREEN 4：summarize 在合成的 6 格数据上坐标对得上
    fake = []
    for cell, _p, _m in CELLS:
        for i in range(2):
            stale = cell.startswith("A")
            fake.append({
                "card_id": f"C{i}", "cell": cell, "model": "m",
                "replay": 0,
                "verdict": "STALE_FAILURE" if stale else "RECOVERED",
                "usage": {"prompt_tokens": 100, "completion_tokens": 20},
                "trace": {"steps": [{}, {}]},
            })
    rep = summarize(fake)
    check("n_records=12", rep["n_records"] == 12, str(rep["n_records"]))
    check("A_keep stale_rate=1.0", rep["cells"]["A_keep"]["stale_rate"] == 1.0)
    check("R_keep stale_rate=0.0", rep["cells"]["R_keep"]["stale_rate"] == 0.0)
    check("提示效应 diff_pp=100", rep["contrasts"]["prompt_effect_memory_held（提示效应，记忆不动）"]["diff_pp"] == 100.0)
    check("loss_rate=0", rep["loss_rate"] == 0.0)

    print()
    if failures:
        print(f"SELFTEST FAILED ({len(failures)}): {failures}")
        return 1
    c1 = make_client("http://127.0.0.1:1/v1", "m", 5)
    c2 = make_client("http://127.0.0.1:1/v1", "m", 5)
    assert c1 is not c2, "make_client 必须每次返回新实例"
    assert c1.calls == 0 and c2.calls == 0, "新 Client 计数必须为 0"
    c1.calls = 5
    assert c2.calls == 0, "两个 Client 的计数必须互相独立"
    print("OK: client 复用守卫")

    print("SELFTEST OK (all assertions passed)")
    return 0


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(description="L3 3×2 因子解混杂实验（提示模式 × 记忆移除）")
    ap.add_argument("--models", nargs="+", required=False, default=[])
    ap.add_argument("--cards-manifest", default="runs/l3-registered-cards/manifest.json")
    ap.add_argument("--n-units", type=int, default=3, help="用前 N 张卡")
    ap.add_argument("--repeats", type=int, default=1)
    ap.add_argument("--max-turns", type=int, default=20)
    ap.add_argument("--max-calls-per-episode", type=int, default=40)
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--out", default="runs/l3-factorial-3x2")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--shard", type=int, default=0, help="本分片编号（0..num-shards-1）")
    ap.add_argument("--num-shards", type=int, default=1, help="分片数；按 job 索引取模切分")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        return selftest()
    if not args.models:
        print("error: --models required (or use --selftest)", file=sys.stderr)
        return 2

    base_url = args.base_url or fr.DEFAULT_BASE_URL
    manifest_path = Path(args.cards_manifest)
    if not manifest_path.is_absolute():
        manifest_path = HERE / manifest_path
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    cards_dir = manifest_path.parent

    entries = manifest["cards"][: args.n_units]
    cards = [fr.load_card(cards_dir, e) for e in entries]  # 逐张 sha256 校验

    out_dir = Path(args.out)
    if not out_dir.is_absolute():
        out_dir = HERE / out_dir
    traces_dir = out_dir / "traces"
    judgements_dir = out_dir / "judgements"
    traces_dir.mkdir(parents=True, exist_ok=True)
    judgements_dir.mkdir(parents=True, exist_ok=True)
    state_path = out_dir / "factorial_state_v1.json"

    all_jobs = []
    for model in args.models:
        for card in cards:
            for cell, prompt_mode, remove_mode in CELLS:
                for repeat in range(args.repeats):
                    all_jobs.append((model, card, cell, prompt_mode, remove_mode, repeat))

    # 分片：按 job 全局索引取模。四个 --n-units 只能取前缀，撑不了"全 240 卡 × 6 格"的墙钟，
    # 所以用 --shard/--num-shards 起 N 个进程，各写各的 out 目录，最后人工合并 report。
    if args.num_shards < 1:
        ap.error("--num-shards 必须 >= 1")
    if not (0 <= args.shard < args.num_shards):
        ap.error(f"--shard 必须在 0..{args.num_shards - 1}")
    jobs = [j for i, j in enumerate(all_jobs) if i % args.num_shards == args.shard]
    if args.num_shards > 1:
        print(f"shard {args.shard}/{args.num_shards}: {len(jobs)}/{len(all_jobs)} jobs",
              file=sys.stderr)

    state = {"done": {}, "records": []}
    if args.resume and state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8"))
        print(f"resume: {len(state['done'])} done", file=sys.stderr)

    lock = threading.Lock()
    local = threading.local()

    def client_for(model: str):
        # 每个 episode 必须新建 Client：agent_arm.Client 的 calls/prompt_tokens 挂在实例上，
        # 复用实例会让第 2 个 episode 一开口就 raise Budget("budget exhausted")，
        # 表现为 steps=0 的瞬时 INCOMPLETE（2026-11-11 实测：8 分片 2880 条因此烧掉 94.7%）。
        # 顺序版 formal_runner.py 也是每 episode new 一个 Client，这里对齐。
        return make_client(base_url, model, args.max_calls_per_episode)

    def work(job) -> dict | None:
        model, card, cell, prompt_mode, remove_mode, repeat = job
        slug = slug_for(model, card["card_id"], cell, repeat)
        if slug in state["done"]:
            return None
        last_err = None
        for attempt in range(3):
            try:
                rec = run_cell(client_for(model), card, cell, prompt_mode, remove_mode,
                               repeat, args.max_turns)
                rec["model"] = model
                rec["slug"] = slug
                return rec
            except Exception as error:  # noqa: BLE001
                last_err = f"{type(error).__name__}: {error}"
                if attempt < 2:
                    time.sleep(30)
        return {
            "card_id": card["card_id"], "cell": cell, "model": model, "slug": slug,
            "prompt_mode": prompt_mode, "remove_mode": remove_mode,
            "policy": POLICY_OF[prompt_mode], "removed_memory_id": REMOVE_OF[remove_mode],
            "replay": repeat, "verdict": "INCOMPLETE",
            "metrics": {}, "usage": {}, "budget_exhausted": False,
            "errors": ["episode_exception:" + str(last_err)], "injection": None,
            "trace": {"schema": "l3-trace/v1", "card_id": card["card_id"],
                      "model": model, "steps": [], "errors": ["episode_exception:" + str(last_err)],
                      "injection": None, "usage": {}, "budget_exhausted": False,
                      "memory_ids": [], "no_llm_calls": False},
        }

    started = time.time()
    done_count = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for rec in pool.map(work, jobs):
            if rec is None:
                continue
            with lock:
                trace = rec.pop("trace", {})
                rec["n_steps_taken"] = len(trace.get("steps", []))
                (traces_dir / f"{rec['slug']}.json").write_text(
                    json.dumps(trace, ensure_ascii=False, indent=2), encoding="utf-8")
                (judgements_dir / f"{rec['slug']}.json").write_text(
                    json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
                state["records"].append(rec)
                state["done"][rec["slug"]] = True
                done_count += 1
                tmp = state_path.with_suffix(".tmp")
                tmp.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
                tmp.replace(state_path)
                if done_count % 6 == 0:
                    print(f"  {done_count}/{len(jobs)} {time.time()-started:.0f}s", file=sys.stderr)

    report = summarize(state["records"])
    report["models"] = args.models
    report["cards_manifest_sha256"] = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    report["n_units"] = len(cards)
    report["repeats"] = args.repeats
    report["workers"] = args.workers
    report["runner"] = "factorial_3x2.py"
    report["shard"] = args.shard
    report["num_shards"] = args.num_shards
    report["jobs_in_shard"] = len(jobs)
    report["jobs_total"] = len(all_jobs)
    report["wall_seconds"] = round(time.time() - started, 1)
    report["finished_at"] = datetime.now(timezone.utc).isoformat()
    (out_dir / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2),
                                         encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("n_records", "incomplete", "loss_rate", "wall_seconds")},
                     ensure_ascii=False))
    print(json.dumps(report["cells"], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
