# L3 v3 预注册（APPROVED / IN FORCE 2026-11-19）

状态：**APPROVED / IN FORCE（2026-11-19 PST，用户明确 GO「全做」）**。
本文件登记 v3 实验的条款；冻结层 6 文件与 v2 预注册均未改动。
条款冻结点：本节 + §3 判据 + §4 门；点火后任何改动须走 v3 修订登记（新增小节，不覆盖旧条款）。

日期：2026-11-19 PST。基线：v2 预注册（`L3_V2_PREREG_REVIEWABLE.md`，IN FORCE 2026-11-17），
DEVIATION D16（载体同时携带资源名），D17（report 载体对账）。

## 1. 为什么需要 v3（D16 的一句话）

v2 的 S_c 载体里同时写了两件事：计划行的版本（`basis_version=1/2`）**和**服务资源名
（`store-a`/`store-b`）。资源名在 system prompt 里一次也没出现。因此删除载体 = 同时删掉
版本信息和"如何寻址服务"的唯一词汇；三批 del 臂 `0/120` 次成功写、注入前 `0/562` 次成功写
（v2 主三批），统计标签 `STALE_FAILURE` 实际描述的是"一个字都写不出去"，不是"跟随过时计划"。
v2 的结论（删除有害、成本高）成立，但机制命名不成立。

## 2. 唯一操作化改动：把"词汇"和"版本"分开

| 通道 | v2（S_c） | v3（S_version，拟） |
|---|---|---|
| system prompt | 两臂同，但**不含**资源名/目标路径 | 两臂同，**常驻**资源名、两条目标路径、文件名、行数 |
| 历史载体 | 两行含 `resource=... target=... basis_version=...` | 两行**只含** `basis_version=1` / `basis_version=2` + "变更后取后一行" |
| `stat()` 返回 | note + files_seen（不泄漏） | 不变（仍不泄漏版本/目标） |
| reject 提示 | 不回授正确值 | 不变 |
| 注入通知 | 两臂逐字同 | 不变 |
| 注入触发 | 已写文件数 ≥4 或第 5 轮 | 不变 |
| 唯一差异 | 载体在/不在 | **版本映射**在/不在 |

删除臂在 v3 里仍然能写（资源名常驻），只是不知道变更发生后哪一行版本仍有效。
因此失败若出现，才可能是"版本跟随"而不是"无法寻址"。

## 3. 假设与判据（拟）

- H3v3（主，确认性）：在提示逐字相同、资源名常驻的条件下，删掉版本映射相对保留版本映射，
  把注入后 `STALE_FAILURE` 比例降低 ≥15pp；每个模型单独同向；双侧精确 McNemar α=0.05。
- 成本约束（方向不预设）：`cost_ratio = mean_tokens(del)/mean_tokens(keep)` 写在报告里，
  不预设 ≤1.10 或 ≥1；v1 删臂"失败得快"便宜、v2 删臂"失败得慢"贵 3.21–3.82×，
  v3 可能落在两者之间，结论须按方向分别陈述。
- 配对单元 = (model, card_id, repeat)；有效判定 = RECOVERED / STALE_FAILURE；
  PRE_INJECTION_COMPLETION 与 INCOMPLETE_TRUNCATED 单列、不进分母。
- 样本：注册 ≥140 有效配对；目标 420（按 `statistical-power` 重算后钉死，MDE 待定）。
  每模型 ≥1 批零传输损失；传输损失率 >20% 作废、>50% 降级。

## 4. 必须先过的门（未过不点主实验）

1. `v3_runner.py --selftest` 7/7（已过，2026-11-19：两臂提示逐字同、资源名常驻、
   载体只含版本、`stat` 不泄漏、GREEN 恢复、RED 删版本→STALE 且**注入前成功写 >0**、假阳守卫、零 API 网格落盘 4 条 judgement/trace + state finished）。
2. 真模 smoke（两轮累计 2+4 卡）：`runs/l3-v3-smoke4/`（minimax，4 卡 8 条，wall 91.88s）
   **TL=0**，配对 4 对 → keep stale 0.0 vs del stale 0.75、diff 75.0pp、McNemar p=0.25
   （n 太小不显著，方向对）。关键是 D16 判据已解除：del 臂 4/4 都有成功写、
   注入前累计 77 次（v2 删臂是 0/120），逐 trace 可见 step0–4 用 basis_version=1 成功写、
   注入后 step5 起用 v1 被拒再切 v2 → 这就是"版本跟随"而非"无法寻址"。
   仍须补 ≥1 个零折损模型 + ≥40 卡的阳性对照（keep REC ≥0.8、del 退化 ≥0.5pp）。
3. 新预注册经用户签署后生效；冻结层 6 文件哈希不变；v3 runner 以新哈希登记。

## 4b. 生效时刻的代码身份（冻结点）

| 文件 | 行数 | bytes | sha256 前 16 |
|---|---|---|---|
| `l3_pilot/v3_runner.py` | 407 | 19184 | `1d92fbcd6d1d3648` |
| `l3_pilot/v3_smoke.py` | 56 | — | 不改（smoke 专用） |

冻结层 6 文件哈希见 `L3_V2_PREREG_REVIEWABLE.md` §9，与 `PREREG_L3.md` §1 一致，v3 未动。
`formal_runner.py --verify-provenance` 必须仍 exit 0。

## 5. 明确不做

- 不改 v2 已登记 runner 的任何一行（跨批可比）。
- 不把 v3 smoke 的数字写进任何已交付稿件。
- 不在同一载体上同时改版本与词汇（那会重演 D16）。

## 6. 复现命令（待签署后启用）

```bash
cd l3_pilot
python3 v3_runner.py --selftest                              # 7/7
python3 v3_runner.py --scripted --cards 3 --out /tmp/v3grid     # 零 API 落盘路径
python3 v3_smoke.py --model <MODEL> --cards 4 --out runs/l3-v3-smoke4  # 真模 4 卡 smoke
# 主实验命令与参数在签署时按 §3 钉死
```
