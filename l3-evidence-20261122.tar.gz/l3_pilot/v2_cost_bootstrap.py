#!/usr/bin/env python3
"""v2 成本比的分层 bootstrap —— 只读落盘 judgements，产出可复算的比值 CI。

为什么需要：三批 report.json 只给点估计（3.2142 / 3.7622 / 3.6553），
预注册 §6 要求把成本区间收窄到不跨 1.10 才能把成本写成精估计。点估计无法判断
"3.2 是不是 1.1 的稳健翻倍"，必须给区间。

口径（逐条落进产物字段，不许事后改）：
  - 配对单元 = 同一 card_id 的 keep 与 del 都存在、两侧 transport_loss 均为 False、
    两侧 verdict 都在 (RECOVERED, STALE_FAILURE) 内（与 v2_runner_sc.summarize 的 eff 定义一致）
  - 每对取 tokens（该 episode 的 usage 总量）
  - 统计量 ratio = mean(del_tok) / mean(keep_tok)（与 report 的 cost_ratio 同口径，均值比，不是比值均值）
  - bootstrap：对配对单元有放回重采样 n_boot 次，percentile CI [2.5, 97.5]

用法：
  python3 v2_cost_bootstrap.py --selftest
  python3 v2_cost_bootstrap.py --runs l3-v2-sc-40-minimax l3-v2-sc-40-kimi-lowspeed l3-v2-sc-40-workbuddy2 --out ../runs/l3-v2-cost-bootstrap.json
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import pathlib
import random

EFFECTIVE = ("RECOVERED", "STALE_FAILURE")
N_BOOT = 10000
SEED = 20261117
COST_LIMIT = 1.10


def load_judgements(run_dir: str) -> list[dict]:
    out = []
    for p in sorted(glob.glob(os.path.join(run_dir, "judgements", "*.json"))):
        j = json.load(open(p, encoding="utf-8"))
        out.append(j)
    return out


def paired_tokens(records: list[dict]) -> list[tuple[float, float]]:
    by_card: dict[str, dict[str, dict]] = {}
    for r in records:
        if r.get("transport_loss"):
            continue
        if r.get("verdict") not in EFFECTIVE:
            continue
        by_card.setdefault(r["card_id"], {})[r["arm"]] = r
    pairs = []
    for cid, arms in sorted(by_card.items()):
        if "keep" in arms and "del" in arms:
            pairs.append((float(arms["keep"]["tokens"]), float(arms["del"]["tokens"])))
    return pairs


def ratio_of(pairs: list[tuple[float, float]]) -> float:
    tk = sum(p[0] for p in pairs)
    td = sum(p[1] for p in pairs)
    if not tk:
        raise ValueError("keep 总 token 为 0，比值无定义")
    return td / tk


def bootstrap(pairs, n_boot: int = N_BOOT, seed: int = SEED) -> dict:
    if not pairs:
        return {"n": 0, "point": None, "ci95": None, "p_le_limit": None}
    rng = random.Random(seed)
    point = ratio_of(pairs)
    n = len(pairs)
    vals = []
    for _ in range(n_boot):
        sample = [pairs[rng.randrange(n)] for _ in range(n)]
        tk = sum(p[0] for p in sample)
        if not tk:
            continue
        vals.append(sum(p[1] for p in sample) / tk)
    vals.sort()

    def pct(q):
        return vals[min(len(vals) - 1, int(q * len(vals)))]

    return {
        "n": n,
        "point": round(point, 4),
        "ci95": [round(pct(0.025), 4), round(pct(0.975), 4)],
        "p_le_limit": round(sum(1 for v in vals if v <= COST_LIMIT) / len(vals), 4),
        "n_boot": n_boot, "seed": seed, "raw": vals,
    }


def selftest() -> None:
    # ---- GREEN：构造已知比值 2.0 的 20 对，均值比必须精确 2.0
    g = [(100.0, 200.0)] * 20
    assert ratio_of(g) == 2.0, ratio_of(g)
    bg = bootstrap(g, n_boot=500, seed=1)
    assert bg["point"] == 2.0 and bg["ci95"] == [2.0, 2.0], bg
    assert bg["p_le_limit"] == 0.0, bg

    # ---- GREEN：不等权重的均值比（比值均值 ≠ 均值比，必须走均值比）
    g2 = [(10.0, 100.0), (90.0, 100.0)]
    assert abs(ratio_of(g2) - 2.0) < 1e-9, ratio_of(g2)          # 200/100
    assert abs((100 / 10 + 100 / 90) / 2 - 5.56) < 0.01           # 比值均值是 5.56，故意不同

    # ---- RED：transport_loss 的格子必须被逐出配对（否则一次 429 会污染成本比）
    recs = [
        {"card_id": "C1", "arm": "keep", "verdict": "RECOVERED", "tokens": 100, "transport_loss": False},
        {"card_id": "C1", "arm": "del", "verdict": "STALE_FAILURE", "tokens": 200, "transport_loss": False},
        {"card_id": "C2", "arm": "keep", "verdict": "RECOVERED", "tokens": 100, "transport_loss": False},
        {"card_id": "C2", "arm": "del", "verdict": "INCOMPLETE", "tokens": 0, "transport_loss": True},
    ]
    pr = paired_tokens(recs)
    assert pr == [(100.0, 200.0)], pr                              # C2 被逐出
    assert ratio_of(pr) == 2.0, ratio_of(pr)

    # ---- RED：非有效 verdict 的格子必须被逐出（INCOMPLETE 无成本可比）
    recs2 = recs[:2] + [
        {"card_id": "C3", "arm": "keep", "verdict": "INCOMPLETE", "tokens": 5, "transport_loss": False},
        {"card_id": "C3", "arm": "del", "verdict": "STALE_FAILURE", "tokens": 500, "transport_loss": False},
    ]
    assert paired_tokens(recs2) == [(100.0, 200.0)], paired_tokens(recs2)

    print("SELFTEST PASS (green 2 / red 2)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--runs", nargs="*", default=[])
    ap.add_argument("--out")
    args = ap.parse_args()
    if args.selftest:
        selftest()
        return 0

    per_run, all_pairs = {}, []
    for rd in args.runs:
        pairs = paired_tokens(load_judgements(rd))
        all_pairs.extend(pairs)
        b = bootstrap(pairs)
        b.pop("raw", None)
        per_run[os.path.basename(rd.rstrip("/"))] = b
    pooled = bootstrap(all_pairs)
    raw = pooled.pop("raw", [])
    res = {
        "schema": "l3-v2-cost-bootstrap/v1",
        "statistic": "ratio = mean(del_tokens)/mean(keep_tokens) over effective paired units",
        "cost_limit": COST_LIMIT,
        "n_boot": N_BOOT, "seed": SEED,
        "per_run": per_run,
        "pooled": pooled,
        "pooled_ci_excludes_limit": bool(pooled["ci95"] and pooled["ci95"][0] > COST_LIMIT),
        "runner": "v2_cost_bootstrap.py",
    }
    if raw:
        res["pooled_quantiles"] = {
            "p50": round(raw[len(raw) // 2], 4),
            "p5": round(raw[int(0.05 * len(raw))], 4),
            "p95": round(raw[int(0.95 * len(raw))], 4),
        }
    txt = json.dumps(res, ensure_ascii=False, indent=1, sort_keys=True)
    if args.out:
        pathlib.Path(args.out).write_text(txt + "\n", encoding="utf-8")
    print(txt)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
