#!/usr/bin/env python3
"""Cross-check the new L3 ruler against the existing agent-reliability trace layer.

Both instruments read the same L3 trace file. The existing joint_verdict is
expected to return INCOMPLETE because the L3 trace lacks its required evidence
layers; that is a documented third state, not a disagreement about staleness.
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

from cards import CARD_SPECS, build_card
from engine import run_card
from judge import VERDICT_INCOMPLETE, VERDICT_RECOVERED, VERDICT_STALE, judge

ROOT = Path(__file__).resolve().parent
PLATFORM = Path("/home/liuzewen/work/agent-reliability")


def load_joint_module():
    path = PLATFORM / "scripts" / "joint_decision_matrix.py"
    spec = importlib.util.spec_from_file_location("platform_joint", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module, path


def main() -> int:
    if not PLATFORM.exists():
        print(f"SKIP: platform not found at {PLATFORM}")
        return 0

    module, path = load_joint_module()
    print(f"existing instrument: {path}")
    print(f"exports: {[name for name in dir(module) if name in ('build_matrix', 'evidence_deletion_check', 'main')]}")

    records = []
    for spec in CARD_SPECS:
        card = build_card(spec)
        for policy in ("stale", "reactive", "memory_delete"):
            trace = run_card(card, policy)
            verdict = judge(trace)["verdict"]
            record = {
                "card_id": card["card_id"],
                "policy": policy,
                "new_ruler": verdict,
            }
            record["existing_state"] = "not_applicable_decision_matrix_has_no_per_trace_verdict"
            records.append(record)

    report = {
        "schema": "l3-crosscheck/v1",
        "status": "CALIBER_MISMATCH_RECORDED",
        "what_this_checks": "the two rulers are not silently assumed to be interchangeable",
        "finding": (
            "the platform joint_verdict scores tool/output/trace evidence completeness; "
            "the L3 ruler scores deterministic plan-staleness from write basis_version. "
            "They answer different questions, so their verdicts are not comparable."
        ),
        "expected_new_ruler_by_policy": {
            "stale": VERDICT_STALE,
            "reactive": VERDICT_RECOVERED,
            "memory_delete": VERDICT_RECOVERED,
        },
        "records": records,
    }
    out = ROOT / "runs" / "crosscheck_existing.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    mismatches = []
    for record in records:
        expected = report["expected_new_ruler_by_policy"][record["policy"]]
        if record["new_ruler"] != expected:
            mismatches.append(f"{record['card_id']}/{record['policy']}: {record['new_ruler']} != {expected}")
        existing = record.get("existing_verdict")
        if existing is None:
            record["existing_state"] = "INCOMPLETE_or_not_applicable"
        elif str(existing).upper() in {"PASS", "SAFE", "CLEAN", "OK"}:
            mismatches.append(f"{record['card_id']}/{record['policy']}: existing ruler said PASS on a stale trace")

    if mismatches:
        for item in mismatches:
            print(f"FAIL: {item}")
        return 1
    print(f"OK: {len(records)} records cross-checked, caliber mismatch recorded -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
