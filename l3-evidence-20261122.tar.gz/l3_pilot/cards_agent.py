"""12-file cards for the real-model arm.

Kept separate from cards.py so the fixture pilot stays byte-identical.
"""
from __future__ import annotations

from cards import canonical, sha256_text

SCHEMA = "l3-task-card/v1"
N_STEPS = 40

CARD_SPECS = [
    {"card_id": "L3-A01", "seed": 1101, "inject_after_files": 8, "primary": "store-a", "alt": "store-b"},
    {"card_id": "L3-A02", "seed": 1202, "inject_after_files": 12, "primary": "bucket-x", "alt": "bucket-y"},
    {"card_id": "L3-A03", "seed": 1303, "inject_after_files": 4, "primary": "node-1", "alt": "node-2"},
    {"card_id": "L3-A04", "seed": 1404, "inject_after_files": 16, "primary": "cache-p", "alt": "cache-q"},
    {"card_id": "L3-A05", "seed": 1505, "inject_after_files": 8, "primary": "vol-main", "alt": "vol-backup"},
]


def build_card(spec: dict) -> dict:
    card = {
        "schema": SCHEMA,
        "card_id": spec["card_id"],
        "seed": spec["seed"],
        "n_steps": N_STEPS,
        "inject_after_files": spec["inject_after_files"],
        "files": [f"f{index:02d}" for index in range(N_STEPS)],
        "resources": [spec["primary"], spec["alt"]],
        "target_v1": f"/dst/{spec['seed']}/v1",
        "target_v2": f"/dst/{spec['seed']}/v2",
        "memory": [
            {
                "id": "m-plan",
                "kind": "plan",
                "version": 1,
                "text": f"use {spec['primary']} -> /dst/{spec['seed']}/v1",
                "culprit": True,
            },
            {"id": "m-quota", "kind": "fact", "version": 1, "text": "write quota is 40", "culprit": False},
            {"id": "m-format", "kind": "fact", "version": 1, "text": "payload format is jsonl", "culprit": False},
        ],
        "success_condition": "all files written to the current target path",
        "injection": {
            "kind": "plan_invalidation",
            "effect": (
                f"{spec['primary']} becomes unavailable, target becomes /dst/{spec['seed']}/v2, "
                "plan_version 1 -> 2"
            ),
        },
    }
    card["card_sha256"] = sha256_text(canonical(card))
    return card


def spec_by_id() -> dict:
    return {spec["card_id"]: spec for spec in CARD_SPECS}
