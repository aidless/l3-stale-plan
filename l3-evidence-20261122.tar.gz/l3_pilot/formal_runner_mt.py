#!/usr/bin/env python3
"""L3 并发正式运行器（**编排层，未冻结**）。

为什么存在
----------
`formal_runner.py` 的主循环是纯顺序的（`formal_runner.py:469-472`：
`for model → for card → for condition → for repeat`），每个 episode 独占一个进程。
实测速度（Run A judgement 文件 mtime 实测）：deepseek-v4.1-flash ≈ 29s/episode，
glm-5.3-flash ≈ 60s/episode。PREREG_L3.md §3 注册规模为 240 卡 × 3 seed = 720 配对单元，
§4 要求 ≥ 2 个模型 —— 即 240 × 3 seed × {B,D} × 2 模型 = 2880 episode，
顺序执行约需 36h，超过云端实例寿命（2026-11-12 06:29 PST 自动销毁）。
本文件把 episode 级并行化，用同一批 episode 压进实例窗口。

纪律
----
1. **不改动任何冻结文件**：`judge.py` / `engine.py` / `cards.py` /
   `cards_agent.py` / `agent_arm.py` / `power_l3.py` 一行不碰（PREREG §1 哈希）。
2. **不改动 `formal_runner.py` 一行**：卡片哈希校验、条件路由
   （`CONDITION_POLICY`）、harness 选择、判定口径、统计口径全部
   `import formal_runner as fr` 直接复用，不复制粘贴改写，避免两处漂移。
3. **同一 slug 集合**：并发版与顺序版跑的是同一批 (model, card, condition, repeat)
   组合，slug 完全一致，因此顺序版产出的 `formal_state_v2.json` 可以直接被
   本文件 `--resume` 接管，反之亦然。
4. **统计口径不变**：最终 report 仍是 `l3-formal-report/v2`，由 `fr.summarize()`
   生成，与顺序版逐字段可比。

并发安全依据（读代码核过，不是猜的）
------------------------------------
* `agent_arm.run_episode()` 每次调用新建 `Env`（`engine.py:14`），
  `written` / `messages` 均为局部变量 → episode 之间无共享可变状态。
* `agent_arm.Client` 的 `calls` / `prompt_tokens` / `completion_tokens`
  计数器挂在实例上（`agent_arm.py:86-119`）→ **每个 worker 必须持有独立 Client
  实例**；本文件用 `threading.local()` 分配，绝不共享（共享会让预算计数串台）。
* `fr.run_one` / `fr.summarize` / `fr.slug_for` / `fr.build_condition_card`
  都是纯函数，可并发调用。

用法
----
  # 自测（不联网，RED→GREEN）
  python3 formal_runner_mt.py --selftest

  # 真实 smoke（2 卡 × B/D × 1 模型 × 4 worker）
  python3 formal_runner_mt.py --models opencode-go/deepseek-v4.1-flash \
      --n-units 2 --repeats 1 --conditions B D --workers 4 \
      --out runs/l3-mt-smoke

  # 正式（240 卡 × 3 seed × B/D × 2 模型）
  python3 formal_runner_mt.py --models M1 M2 --n-units 240 --repeats 3 \
      --conditions B D --workers 6 --out runs/l3-formal-full --resume
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

import agent_arm
import formal_runner as fr

ROOT = Path(__file__).resolve().parent
DEFAULT_MANIFEST = fr.DEFAULT_MANIFEST
DEFAULT_BASE_URL = fr.DEFAULT_BASE_URL
PERSISTENCE_FILE = fr.PERSISTENCE_FILE


# ---------------------------------------------------------------------------
# 每线程独立的 Client（共享会让 calls / token 计数串台）
# ---------------------------------------------------------------------------
class ClientPool:
    """按线程分配 agent_arm.Client。

    为什么必须 per-thread：agent_arm.Client 把 calls / prompt_tokens /
    completion_tokens 挂在实例上（agent_arm.py:86-119），共享实例会让多个
    episode 的调用预算与 token 统计互相污染 —— 那会直接毁掉 H3b 的成本约束
    （PREREG §2 成本条款）。
    """

    def __init__(self, base_url: str, model: str, max_calls: int):
        self.base_url = base_url
        self.model = model
        self.max_calls = max_calls
        self._local = threading.local()
        self._all: list[agent_arm.Client] = []
        self._lock = threading.Lock()

    def get(self) -> agent_arm.Client:
        client = getattr(self._local, "client", None)
        if client is None:
            client = agent_arm.Client(self.base_url, self.model, self.max_calls)
            self._local.client = client
            with self._lock:
                self._all.append(client)
        return client

    @property
    def clients(self) -> list[agent_arm.Client]:
        with self._lock:
            return list(self._all)


# ---------------------------------------------------------------------------
# 任务网格（与顺序版完全同序，便于对照）
# ---------------------------------------------------------------------------
def build_jobs(models: list[str], cards: list[dict], conditions: list[str], repeats: int) -> list[dict]:
    jobs = []
    for model in models:
        for card in cards:
            for condition in conditions:
                for repeat in range(repeats):
                    _, removed_id = fr.build_condition_card(card, condition)
                    jobs.append(
                        {
                            "model": model,
                            "card": card,
                            "card_id": card["card_id"],
                            "condition": condition,
                            "repeat": repeat,
                            "removed_id": removed_id,
                            "slug": fr.slug_for(model, card["card_id"], condition, removed_id, repeat),
                        }
                    )
    return jobs


def record_sort_key(record: dict) -> tuple:
    return (
        record["model"],
        record["card_id"],
        record["condition"],
        record["repeat"],
    )


# ---------------------------------------------------------------------------
# 单 episode 执行（重试语义与顺序版一致：3 次，间隔 30s）
# ---------------------------------------------------------------------------
def run_job(job: dict, pools: dict[str, ClientPool], args, traces_dir: Path,
            judgements_dir: Path) -> dict:
    model = job["model"]
    condition = job["condition"]
    card = job["card"]
    slug = job["slug"]
    client = pools[model].get()

    result = None
    last_exc = None
    for attempt in range(3):
        try:
            result = fr.run_one(client, card, condition, job["repeat"], args.max_turns, args.random_harness)
            break
        except Exception as e:  # noqa: BLE001 — 单条崩不整批
            last_exc = e
            print(f"  [retry {attempt + 1}/3] {slug}: {type(e).__name__}: {str(e)[:80]}", flush=True)
            time.sleep(30)
    if result is None:
        e = last_exc
        result = {
            "card_id": card["card_id"], "condition": condition,
            "removed_memory_id": job["removed_id"], "replay": job["repeat"],
            "verdict": "INCOMPLETE", "metrics": {},
            "usage": {"calls": getattr(client, "calls", 0),
                      "prompt_tokens": getattr(client, "prompt_tokens", 0),
                      "completion_tokens": getattr(client, "completion_tokens", 0)},
            "budget_exhausted": False,
            "errors": [f"episode_exception:{type(e).__name__}:{e}"],
            "injection": None,
            "trace": {"schema": "l3-trace/v1", "card_id": card["card_id"],
                      "condition": condition, "steps": [], "errors": [str(e)]},
        }

    trace_path = traces_dir / f"{slug}.json"
    trace_path.write_text(json.dumps(result["trace"], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    judgement = {k: v for k, v in result.items() if k != "trace"}
    judgement["model"] = model
    judgement_path = judgements_dir / f"{slug}.json"
    judgement_path.write_text(json.dumps(judgement, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    import hashlib

    return {
        "model": model,
        "card_id": card["card_id"],
        "condition": condition,
        "removed_memory_id": job["removed_id"],
        "repeat": job["repeat"],
        "verdict": result["verdict"],
        "metrics": result.get("metrics", {}),
        "usage": result["usage"],
        "budget_exhausted": result.get("budget_exhausted", False),
        "errors": result.get("errors", []),
        "slug": slug,
        "trace": str(trace_path.relative_to(traces_dir.parent)),
        "judgement": str(judgement_path.relative_to(judgements_dir.parent)),
        "trace_sha256": hashlib.sha256(trace_path.read_bytes()).hexdigest(),
    }


# ---------------------------------------------------------------------------
# 自测：RED（共享 client 会串台 / 漏跑）→ GREEN（per-thread client + 全量落盘）
# ---------------------------------------------------------------------------
def selftest() -> int:
    print("=== SELFTEST(MT) START ===")
    ok = True

    # GREEN-1: ClientPool 每线程分配独立实例
    pool = ClientPool("http://127.0.0.1:1/v1", "fake-model", 40)
    seen: list[int] = []
    lock = threading.Lock()

    def grab():
        c = pool.get()
        with lock:
            seen.append(id(c))

    threads = [threading.Thread(target=grab) for _ in range(6)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    if len(set(seen)) != len(seen):
        print(f"[RED-FAIL] 6 个线程拿到 {len(set(seen))} 个 Client 实例 —— 共享会串台！")
        ok = False
    else:
        print(f"[GREEN] 6 线程 → {len(set(seen))} 个独立 Client 实例（预算/计数不串台）")

    # RED-1: 共享 client 的计数器串台（证明上一条不是装饰）
    shared = agent_arm.Client("http://127.0.0.1:1/v1", "fake-model", 40)
    shared.calls = 7
    pool2 = ClientPool("http://127.0.0.1:1/v1", "fake-model", 40)
    fresh = pool2.get()
    if fresh.calls == 7:
        print("[RED-FAIL] 新 Client 继承了别人的 calls 计数")
        ok = False
    else:
        print(f"[GREEN] 新 Client 计数干净（calls={fresh.calls}，共享那个是 {shared.calls}）")

    # GREEN-2: build_jobs 与顺序版同序同集
    manifest = fr.load_manifest(DEFAULT_MANIFEST)
    cards_dir = DEFAULT_MANIFEST.resolve().parent
    cards = [fr.load_card(cards_dir, manifest["cards"][i]) for i in range(3)]
    jobs = build_jobs(["m1", "m2"], cards, ["B", "D", "R"], 2)
    expected = len(["m1", "m2"]) * 3 * 3 * 2
    if len(jobs) != expected:
        print(f"[RED-FAIL] 任务数 {len(jobs)} != 期望 {expected}")
        ok = False
    else:
        print(f"[GREEN] 任务网格 {len(jobs)} 条（{len(jobs)}/{expected}）")
    seq_slugs = [fr.slug_for(m, c["card_id"], cond, fr.build_condition_card(c, cond)[1], rep)
                 for m in ["m1", "m2"] for c in cards for cond in ["B", "D", "R"] for rep in range(2)]
    if seq_slugs != [j["slug"] for j in jobs]:
        print("[RED-FAIL] 并发版 slug 集合/顺序与顺序版不一致")
        ok = False
    else:
        print("[GREEN] slug 集合与顺序同顺序版逐条一致（可直接互相 resume）")

    # GREEN-3: 并发跑一组 stub episode → 全部落盘、无重复、无丢失
    stub_records: list[dict] = []
    stub_lock = threading.Lock()

    def fake_run_one(client, card, condition, repeat, max_turns, harness):
        return {
            "card_id": card["card_id"], "condition": condition, "policy": "stub",
            "removed_memory_id": None, "replay": repeat, "verdict": "RECOVERED",
            "metrics": {}, "usage": {"calls": 1, "prompt_tokens": 10, "completion_tokens": 5},
            "budget_exhausted": False, "errors": [], "injection": {"step": 1},
            "trace": {"schema": "l3-trace/v1", "card_id": card["card_id"], "steps": []},
        }

    orig_run_one = fr.run_one
    fr.run_one = fake_run_one
    try:
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            (out / "traces").mkdir()
            (out / "judgements").mkdir()
            args = argparse.Namespace(max_turns=16, random_harness="agent_arm")
            pools = {m: ClientPool("http://x/v1", m, 40) for m in ["m1", "m2"]}
            jobs_small = build_jobs(["m1", "m2"], cards, ["B", "D"], 2)
            with ThreadPoolExecutor(max_workers=6) as ex:
                futures = [ex.submit(run_job, j, pools, args, out / "traces", out / "judgements")
                           for j in jobs_small]
                for f in futures:
                    rec = f.result()
                    with stub_lock:
                        stub_records.append(rec)
            n_expect = len(jobs_small)
            if len(stub_records) != n_expect:
                print(f"[RED-FAIL] 并发结果 {len(stub_records)} 条 != 期望 {n_expect}")
                ok = False
            else:
                print(f"[GREEN] 并发跑完 {len(stub_records)}/{n_expect} 条，无丢失")
            slugs = [r["slug"] for r in stub_records]
            if len(set(slugs)) != len(slugs):
                print("[RED-FAIL] slug 重复")
                ok = False
            else:
                print("[GREEN] slug 无重复")
            for sub in ("traces", "judgements"):
                n_files = len(list((out / sub).glob("*.json")))
                if n_files != n_expect:
                    print(f"[RED-FAIL] {sub} 落盘 {n_files} 个 != {n_expect}")
                    ok = False
                else:
                    print(f"[GREEN] {sub} 落盘 {n_files} 个文件")
            summary = fr.summarize(stub_records)
            if summary["n_records"] != n_expect:
                print("[RED-FAIL] summarize 记录数不对")
                ok = False
            else:
                print(f"[GREEN] summarize 复用顺序版口径：n_records={summary['n_records']}")
    finally:
        fr.run_one = orig_run_one

    print("=== SELFTEST(MT)", "PASS" if ok else "FAIL", "===")
    return 0 if ok else 1


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="+")
    parser.add_argument("--cards-manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--n-units", type=int, default=None, help="用前 N 张卡（默认全部）")
    parser.add_argument("--conditions", nargs="+", default=["B", "D"], help="B/D/R/R2 组合")
    parser.add_argument("--repeats", type=int, default=1, help="每个单元的 seed 重复次数（0,1,2...）")
    parser.add_argument("--out", type=Path, default=ROOT / "runs" / "l3-formal-mt")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument("--max-calls-per-episode", type=int, default=40)
    parser.add_argument("--max-turns", type=int, default=20)
    parser.add_argument("--workers", type=int, default=4, help="并发 episode 数")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--random-harness", choices=["agent_arm", "cf_episode"], default="agent_arm")
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()

    if args.selftest:
        return selftest()
    if not args.models:
        parser.error("--models 必填（--selftest 除外）")
    if args.workers < 1:
        parser.error("--workers 必须 ≥ 1")

    manifest = fr.load_manifest(args.cards_manifest)
    cards_dir = args.cards_manifest.resolve().parent
    n_total = min(args.n_units or manifest["n_cards"], manifest["n_cards"])
    cards = [fr.load_card(cards_dir, manifest["cards"][i]) for i in range(n_total)]
    print(f"loaded {len(cards)} cards (hash-verified) from {args.cards_manifest}")

    out = args.out.resolve()
    traces_dir = out / "traces"
    judgements_dir = out / "judgements"
    traces_dir.mkdir(parents=True, exist_ok=True)
    judgements_dir.mkdir(parents=True, exist_ok=True)

    state = {
        "started_at": datetime.now().isoformat(),
        "finished": False,
        "planned": args.repeats * len(cards) * len(args.conditions) * len(args.models),
        "done_slugs": [],
        "records": [],
    }
    if args.resume:
        loaded = fr.load_state(out)
        if loaded:
            state.update(loaded)
            n_purged = fr.purge_burned_incomplete(state)
            if n_purged:
                fr.save_state(out, state)
                print(f"resume-purge: 清除 {n_purged} 条传输层烧掉的 INCOMPLETE，将重跑")
            print(f"resumed: {len(state['done_slugs'])} already done / {state['planned']} planned")
    done = set(state["done_slugs"])

    jobs = [j for j in build_jobs(args.models, cards, args.conditions, args.repeats) if j["slug"] not in done]
    print(f"todo {len(jobs)} episodes / workers={args.workers} / base={args.base_url}")

    pools = {m: ClientPool(args.base_url, m, args.max_calls_per_episode) for m in args.models}
    state_lock = threading.Lock()
    t0 = time.time()

    def worker(job):
        rec = run_job(job, pools, args, traces_dir, judgements_dir)
        with state_lock:
            state["records"].append(rec)
            state["done_slugs"].append(rec["slug"])
            fr.save_state(out, state)
            n = len(state["done_slugs"])
            print(f"[{n}/{state['planned']}] {rec['slug']}: {rec['verdict']} "
                  f"calls={rec['usage'].get('calls')} elapsed={time.time() - t0:.0f}s", flush=True)
        return rec

    if jobs:
        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            list(ex.map(worker, jobs))

    state["finished"] = True
    state["finished_at"] = datetime.now().isoformat()
    fr.save_state(out, state)

    records = sorted(state["records"], key=record_sort_key)
    summary = fr.summarize(records)
    report = {
        "schema": "l3-formal-report/v2",
        "run_id": out.name,
        "base_url": args.base_url,
        "models": args.models,
        "conditions": args.conditions,
        "random_harness": args.random_harness,
        "n_cards": len(cards),
        "repeats": args.repeats,
        "workers": args.workers,
        "runner": "formal_runner_mt.py",
        # 与顺序版共用同一个函数，绝不各写一份（否则围栏会出现两个实现，漂移无人发现）
        "provenance": fr.provenance_block(),
        **summary,
        "records": records,
    }
    report_path = out / "report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\nwrote {len(records)} records -> {report_path}")
    print(json.dumps({k: v for k, v in report.items() if k != "records"}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
