"""Deterministic task-card generator for the L3 staleness pilot.

Cards are fixtures for instrument validation, not experimental evidence.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

SCHEMA = "l3-task-card/v1"
N_STEPS = 50

CARD_SPECS = [
    {"card_id": "L3-P01", "seed": 101, "inject_step": 23, "primary": "store-a", "alt": "store-b"},
    {"card_id": "L3-P02", "seed": 202, "inject_step": 17, "primary": "bucket-x", "alt": "bucket-y"},
    {"card_id": "L3-P03", "seed": 303, "inject_step": 31, "primary": "node-1", "alt": "node-2"},
    {"card_id": "L3-P04", "seed": 404, "inject_step": 9, "primary": "cache-p", "alt": "cache-q"},
    {"card_id": "L3-P05", "seed": 505, "inject_step": 41, "primary": "vol-main", "alt": "vol-backup"},
]


def canonical(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def build_card(spec: dict) -> dict:
    card = {
        "schema": SCHEMA,
        "card_id": spec["card_id"],
        "seed": spec["seed"],
        "n_steps": N_STEPS,
        "inject_step": spec["inject_step"],
        "files": [f"f{index:02d}" for index in range(N_STEPS)],
        "resources": [spec["primary"], spec["alt"]],
        "target_v1": f"/dst/{spec['seed']}/v1",
        "target_v2": f"/dst/{spec['seed']}/v2",
        "memory": [
            {
                "id": "m-plan",
                "kind": "plan",
                "version": 1,
                "text": f"use {spec['primary']} -> /dst/{spec['seed']}/v1",
                "culprit": True,
            },
            {"id": "m-quota", "kind": "fact", "version": 1, "text": "write quota is 50", "culprit": False},
            {"id": "m-format", "kind": "fact", "version": 1, "text": "payload format is jsonl", "culprit": False},
        ],
        "success_condition": "all files written to the current target path with verify=true",
        "injection": {
            "kind": "plan_invalidation",
            "effect": f"{spec['primary']} becomes unavailable, target becomes /dst/{spec['seed']}/v2, plan_version 1 -> 2",
        },
    }
    card["card_sha256"] = sha256_text(canonical(card))
    return card


def write_cards(out_dir: Path) -> list[dict]:
    out_dir.mkdir(parents=True, exist_ok=True)
    cards = [build_card(spec) for spec in CARD_SPECS]
    manifest = {
        "schema": "l3-card-manifest/v1",
        "n_cards": len(cards),
        "cards": [
            {"card_id": card["card_id"], "file": f"{card['card_id']}.json", "sha256": card["card_sha256"]}
            for card in cards
        ],
    }
    for card in cards:
        (out_dir / f"{card['card_id']}.json").write_text(
            json.dumps(card, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    (out_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return cards
