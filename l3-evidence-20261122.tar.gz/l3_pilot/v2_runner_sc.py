#!/usr/bin/env python3
"""L3 v2 主实验 runner —— 载体 S_c（KV 可见历史），编排层新文件，冻结层 6 文件不动。

设计依据（全部已落盘）：
  D6  提示混杂：v1 的 B/D 一次差三处提示 → v2 全臂 system+注入提示逐字同一
  D10 max_tokens=400 截断 reasoning → 空 tool_calls → 假 INCOMPLETE → v2 提到 1600 并单列截断型
  D11.4 硬判据：载体被删后无法通过任何工具调用（含错误响应）重建
         → stat() 不泄漏 plan/target/resource；stale_basis/wrong_target 不回授正确值
  D11.5 阳性对照：workbuddy 13/13 REC vs del 9/10 STALE；minimax 17/20 REC vs 20/20 STALE

S_c 载体形态：计划以「上一轮会话留下的迁移备忘」两行映射写进**对话历史**
（user 一条 + assistant 一条 acknowledgement）。
  keep 臂：这两条历史全程保留 → 注入后模型可切到 v2 行
  del  臂：这两条历史被裁掉（等于历史裁剪） → 注入后无从得知 v2 行
两臂差异**只有**这两条历史消息，其余 messages 由同一模板生成（D6）。

用法：
  python3 v2_runner_sc.py --selftest
  python3 v2_runner_sc.py --model workbuddy/deepseek-v4.1-flash --cards 40 --workers 3 \
      --out runs/l3-v2-sc-40x2
"""
from __future__ import annotations

import argparse
import collections
import json
import pathlib
import statistics
import sys
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import agent_arm  # noqa: E402  只借 Client/Budget/TOOLS/工具函数，不用 run_episode

DEFAULT_BASE = "http://127.0.0.1:3425/v1"
MAX_TOKENS_V2 = 1600
MAX_WRITES_PER_TURN = 8
INJECT_TURN = 5
MAX_TURNS = 20
MAX_CALLS = 40

# 两臂逐字相同的提示（D6）。载体不在提示里 —— 载体在历史里。
SYSTEM_PROMPT = (
    "You are an agent migrating files on a remote storage service.\n"
    "Goal: all files written to the current target path.\n"
    "There are {n_files} files: {first} .. {last}.\n"
    "Rules:\n"
    "- The service may change at any time. `stat` alone will NOT tell you the plan.\n"
    "- `write` needs the plan_version your write is based on (an integer).\n"
    "  A write based on an outdated plan_version will be rejected.\n"
    "- A turn may contain at most 8 `write` calls; you cannot finish everything in one turn.\n"
    "- When the service changes, which plan row still holds? Check what you have on record.\n"
    "- Use `verify` only for files you already wrote.\n"
    "Reply with tool calls only; no prose."
)

INJECT_NOTICE = (
    "Notice: the storage service reported a change. "
    "Re-check which plan row is current before your next write."
)

TOOLS = agent_arm.TOOLS


def carrier_messages(card: dict) -> list[dict]:
    """S_c 载体：上一轮会话留下的迁移备忘（历史里的两条消息）。"""
    plan = (
        "Migration note from the previous session — the service publishes two plan rows; "
        "exactly one is current and the service will not tell you which:\n"
        f"  plan v1: resource={card['resources'][0]} target={card['target_v1']} basis_version=1\n"
        f"  plan v2: resource={card['resources'][1]} target={card['target_v2']} basis_version=2\n"
        "After the service reports a change, the later row is the one that holds."
    )
    return [
        {"role": "user", "content": plan},
        {"role": "assistant", "content": "Noted — I will use the row that is current."},
    ]


class EnvSC:
    """记忆/历史是唯一计划来源；`stat()` 故意什么都不泄漏（D11.1 修法）。"""

    def __init__(self, card: dict):
        self.plan_version = 1
        self.target = card["target_v1"]
        self.available = {card["resources"][0]: True, card["resources"][1]: True}
        self.injected = False

    def inject(self, card: dict) -> None:
        self.plan_version = 2
        self.target = card["target_v2"]
        self.available[card["resources"][0]] = False
        self.injected = True

    def stat(self, card: dict) -> dict:
        return {
            "note": "the service does not publish a plan; consult what you have on record",
            "files_seen": 0,
        }


def dispatch(call: dict, env: EnvSC, card: dict, written: dict) -> dict:
    function = call.get("function") or {}
    name = function.get("name")
    raw = function.get("arguments") or "{}"
    try:
        args = json.loads(raw) if isinstance(raw, str) else dict(raw)
    except json.JSONDecodeError:
        return {"ok": False, "error": "arguments_not_json"}

    if name == "stat":
        return {"ok": True, "result": env.stat(card)}

    if name == "write":
        files = args.get("files")
        if files is None and args.get("file") is not None:
            files = [args.get("file")]
        if not isinstance(files, list) or not files:
            files = [args.get("file")]
        names = [agent_arm.normalize_file(x, card) for x in files]
        if any(n is None for n in names):
            return {"ok": False, "error": "unknown_file",
                    "hint": f"use one of: {', '.join(card['files'][:5])} ... {card['files'][-1]}"}
        resource = str(args.get("resource", ""))
        target = str(args.get("target", ""))
        basis = agent_arm.coerce_version(args.get("basis_version"))
        if basis is None:
            return {"ok": False, "error": "basis_version_missing"}
        if basis < env.plan_version:
            # 不回授 current_plan_version（D11.2）
            return {"ok": False, "error": "stale_basis",
                    "hint": "this basis came from an outdated plan row"}
        if basis > env.plan_version:
            return {"ok": False, "error": "future_basis"}
        if resource not in env.available or not env.available[resource]:
            return {"ok": False, "error": "resource_unavailable"}
        if target != env.target:
            # 不回授 current_target（D11.2）
            return {"ok": False, "error": "wrong_target",
                    "hint": "this target is not the current one"}
        accepted, dup = [], []
        for n in names:
            if written.get(n):
                dup.append(n)
            elif len(accepted) >= MAX_WRITES_PER_TURN:
                return {"ok": False, "error": "too_many_writes_in_one_turn",
                        "accepted_before_refusal": accepted}
            else:
                written[n] = True
                accepted.append(n)
        if not accepted:
            return {"ok": False, "error": "already_written", "files": dup}
        return {"ok": True, "result": {"files": accepted, "target": target}}

    if name == "verify":
        f = str(args.get("file", ""))
        if written.get(f):
            return {"ok": True, "result": {"file": f, "verified": True}}
        return {"ok": False, "error": "not_written"}
    return {"ok": False, "error": "unknown_tool"}


class ClientV2(agent_arm.Client):
    """只改 max_tokens（D10）+ 429/坏 JSON 重试；其余与冻结层同构。"""

    def complete(self, messages: list[dict]) -> dict:
        if self.calls >= self.max_calls:
            raise agent_arm.Budget(f"model call budget exhausted after {self.calls} calls")
        payload = {
            "model": self.model, "messages": messages, "tools": TOOLS,
            "tool_choice": "auto", "max_tokens": MAX_TOKENS_V2, "temperature": 0,
        }
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST",
        )
        self.calls += 1
        last = None
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    raw = resp.read().decode("utf-8")
                body = json.loads(raw)
                break
            except urllib.error.HTTPError as e:
                last = e
                if e.code in (429, 502, 503, 504) and attempt < 3:
                    time.sleep(5 * (attempt + 1))
                    continue
                raise
            except json.JSONDecodeError as e:
                last = e
                if attempt < 3:
                    time.sleep(2 * (attempt + 1))
                    continue
                raise
        else:  # pragma: no cover
            raise last
        usage = body.get("usage") or {}
        self.prompt_tokens += usage.get("prompt_tokens") or 0
        self.completion_tokens += usage.get("completion_tokens") or 0
        return body["choices"][0]


def make_client(base_url: str, model: str, max_calls: int = MAX_CALLS) -> ClientV2:
    """D9：Client 计数挂实例、无 reset → 每 episode 必须新实例。"""
    return ClientV2(base_url, model, max_calls)


def make_card(n_files: int = 40, seed: int = 200000) -> dict:
    return {
        "schema": "l3-card-v2sc/v1",
        "card_id": f"L3V2SC-{seed}",
        "seed": seed,
        "n_steps": n_files,
        "inject_after_files": 4,
        "inject_after_turn": INJECT_TURN,
        "files": [f"f{i:02d}" for i in range(n_files)],
        "resources": ["store-a", "store-b"],
        "target_v1": f"/dst/{seed}/v1",
        "target_v2": f"/dst/{seed}/v2",
        "carrier": "S_c:history",
        "injection": {"kind": "plan_invalidation",
                      "effect": "plan_version 1->2, store-a unavailable, target v1->v2"},
    }


def run_episode(client, card: dict, keep_carrier: bool, max_turns: int = MAX_TURNS) -> dict:
    env = EnvSC(card)
    written: dict[str, bool] = {}
    system = SYSTEM_PROMPT.format(n_files=card["n_steps"],
                                 first=card["files"][0], last=card["files"][-1])
    messages = [{"role": "system", "content": system}]
    if keep_carrier:
        messages.extend(carrier_messages(card))   # 唯一差异：历史里的载体在不在
    trace = {
        "schema": "l3-trace-v2sc/v1",
        "card_id": card["card_id"], "model": getattr(client, "model", "?"),
        "arm": "keep" if keep_carrier else "del",
        "carrier": "S_c:history",
        "carrier_present": keep_carrier,
        "injection": None, "steps": [], "errors": [], "budget_exhausted": False,
    }
    started = time.time()

    for turn in range(max_turns):
        if sum(written.values()) >= card["n_steps"]:
            break
        if turn >= card["inject_after_turn"] and not env.injected:
            env.inject(card)
            trace["injection"] = {"step": turn, "from_version": 1, "to_version": 2,
                                  "kind": card["injection"]["kind"]}
            messages.append({"role": "user", "content": INJECT_NOTICE})  # 两臂逐字相同
        try:
            choice = client.complete(messages)
        except agent_arm.Budget as e:
            trace["budget_exhausted"] = True
            trace["errors"].append(str(e))
            break
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError,
                json.JSONDecodeError) as e:
            trace["errors"].append(f"transport:{type(e).__name__}:{e}")
            break

        message = choice.get("message") or {}
        tool_calls = message.get("tool_calls") or []
        finish = choice.get("finish_reason")
        am = {"role": "assistant", "content": message.get("content") or ""}
        if tool_calls:
            am["tool_calls"] = tool_calls
        messages.append(am)
        if not tool_calls:
            trace["steps"].append({"step": turn, "plan_version": env.plan_version,
                                   "tool_calls": [], "text": (message.get("content") or "")[:300],
                                   "finish": finish})
            break
        step_calls = []
        for call in tool_calls:
            res = dispatch(call, env, card, written)
            step_calls.append({"tool": call["function"]["name"],
                               "args": agent_arm._safe_args(call),
                               "ok": res.get("ok", False),
                               "result": res.get("result"),
                               "error": res.get("error")})
            messages.append({"role": "tool", "tool_call_id": call.get("id", ""),
                             "content": json.dumps(res, ensure_ascii=False)[:800]})
        trace["steps"].append({"step": turn, "plan_version": env.plan_version,
                               "tool_calls": step_calls, "finish": finish})

    last = trace["steps"][-1] if trace["steps"] else {}
    trace["final"] = {
        "verified_count": sum(written.values()),
        "n_files": card["n_steps"],
        "final_target": env.target,
        "tool_call_count": sum(len(s["tool_calls"]) for s in trace["steps"]),
        "trajectory_length": len(trace["steps"]),
        "empty_tail": (not last.get("tool_calls")),
        "last_finish": last.get("finish"),
        "token_proxy": client.prompt_tokens + client.completion_tokens,
        "wall_clock_s": round(time.time() - started, 2),
    }
    trace["usage"] = {"calls": client.calls, "prompt_tokens": client.prompt_tokens,
                      "completion_tokens": client.completion_tokens}
    trace["verdict"] = verdict_of(trace)
    return trace


def verdict_of(trace: dict) -> str:
    """五分判定：量具截断、注入前写满分别从能力型 INCOMPLETE 里单列（D10.2 / D12.5）。"""
    writes = [(s["step"], c) for s in trace["steps"] for c in s["tool_calls"]
              if c["tool"] == "write"]
    pv = {s["step"]: s["plan_version"] for s in trace["steps"]}
    stale = 0
    for step, call in writes:
        basis = (call.get("args") or {}).get("basis_version")
        if not isinstance(basis, int) or isinstance(basis, bool):
            continue
        if basis < pv.get(step, 0):
            stale += 1
    final = trace["final"]
    truncated = (final["empty_tail"] and final["last_finish"] == "length")
    if truncated:
        return "INCOMPLETE_TRUNCATED"  # 量具截断优先于一切（D12.5 实测）
    if trace["injection"] is None:
        # 注入未触发且任务已写完 = 注入前写满（PIC），第五类（D12.5 §4.2 不对称性）
        if final["verified_count"] == final["n_files"]:
            return "PRE_INJECTION_COMPLETION"
        return "INCOMPLETE"
    if stale:
        return "STALE_FAILURE"
    if final["verified_count"] == final["n_files"]:
        return "RECOVERED"
    return "STALE_FAILURE" if final["verified_count"] == 0 else "INCOMPLETE"


class ScriptedClient:
    """零 API 的脚本客户端：证明「载体在/不在历史」能改变行为（RED/GREEN 用）。"""

    def __init__(self, keep_carrier: bool, per_turn: int = 4):
        self.keep_carrier = keep_carrier
        self.per_turn = per_turn
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.max_calls = MAX_CALLS
        self.model = "scripted"

    def complete(self, messages):
        self.calls += 1
        seen_change = any(m.get("role") == "user" and "reported a change" in (m.get("content") or "")
                          for m in messages)
        # 只有载体在历史里、且看到了变更通知，才知道 v2 行
        use_v2 = seen_change and self.keep_carrier and any(
            "plan v2" in (m.get("content") or "") for m in messages if m.get("role") == "user")
        n_done = sum(1 for m in messages if m.get("role") == "tool"
                     and '"files"' in (m.get("content") or ""))
        idx = n_done * self.per_turn
        seed = 200000
        for m in messages:
            c = m.get("content") or ""
            if "/dst/" in c:
                try:
                    seed = int(c.split("/dst/")[1].split("/")[0])
                except Exception:
                    pass
                break
        files = [f"f{i:02d}" for i in range(idx, min(idx + self.per_turn, 40))]
        target = f"/dst/{seed}/v2" if use_v2 else f"/dst/{seed}/v1"
        store = "store-b" if use_v2 else "store-a"
        basis = 2 if use_v2 else 1
        call = {"id": f"c{self.calls}", "type": "function",
                "function": {"name": "write", "arguments": json.dumps(
                    {"files": files, "resource": store, "basis_version": basis,
                     "target": target})}}
        return {"message": {"content": "", "tool_calls": [call]}, "finish_reason": "tool_calls"}


def summarize(records: list[dict]) -> dict:
    cells, pairs = {}, {}
    for arm in ("keep", "del"):
        rs = [r for r in records if r["arm"] == arm and not r["transport_loss"]]
        n = len(rs)
        cnt = collections.Counter(r["verdict"] for r in rs)
        tok = sorted(r["tokens"] for r in rs)
        cells[arm] = {
            "n": n,
            "n_transport_loss": sum(1 for r in records if r["arm"] == arm and r["transport_loss"]),
            **{k: cnt.get(k, 0) for k in
               ("RECOVERED", "STALE_FAILURE", "INCOMPLETE", "INCOMPLETE_TRUNCATED",
                "PRE_INJECTION_COMPLETION")},
            "stale_rate_all": round(cnt.get("STALE_FAILURE", 0) / n, 4) if n else None,
            "n_effective": cnt.get("RECOVERED", 0) + cnt.get("STALE_FAILURE", 0),
            "stale_rate_effective": (
                round(cnt.get("STALE_FAILURE", 0) / (cnt.get("RECOVERED", 0) + cnt.get("STALE_FAILURE", 0)), 4)
                if (cnt.get("RECOVERED", 0) + cnt.get("STALE_FAILURE", 0)) else None),
            "truncated_rate": round(cnt.get("INCOMPLETE_TRUNCATED", 0) / n, 4) if n else None,
            # 第五类 PIC：注入前写满，不进有效分母（D12.5 §4.2）
            "pre_injection_completion": cnt.get("PRE_INJECTION_COMPLETION", 0),
            "pic_rate": round(cnt.get("PRE_INJECTION_COMPLETION", 0) / n, 4) if n else None,
            "median_tokens": tok[len(tok) // 2] if tok else None,
            "median_verified": statistics.median(r["verified"] for r in rs) if rs else None,
        }
    by_card = collections.defaultdict(dict)
    for r in records:
        if r["transport_loss"]:
            continue
        by_card[r["card_id"]][r["arm"]] = r
    valid = {c: v for c, v in by_card.items() if "keep" in v and "del" in v}
    eff = {c: v for c, v in valid.items()
           if v["keep"]["verdict"] in ("RECOVERED", "STALE_FAILURE")
           and v["del"]["verdict"] in ("RECOVERED", "STALE_FAILURE")}
    improved = worsened = 0
    for v in eff.values():
        k = v["keep"]["verdict"] == "STALE_FAILURE"
        d = v["del"]["verdict"] == "STALE_FAILURE"
        if k and not d:
            improved += 1
        elif d and not k:
            worsened += 1
    tk = sum(v["keep"]["tokens"] for v in eff.values())
    td = sum(v["del"]["tokens"] for v in eff.values())
    pairs = {
        "n_valid": len(valid), "n_effective": len(eff),
        "keep_stale_rate": (round(sum(1 for v in eff.values() if v["keep"]["verdict"] == "STALE_FAILURE") / len(eff), 4) if eff else None),
        "del_stale_rate": (round(sum(1 for v in eff.values() if v["del"]["verdict"] == "STALE_FAILURE") / len(eff), 4) if eff else None),
        "diff_pp": (round(100 * (sum(1 for v in eff.values() if v["del"]["verdict"] == "STALE_FAILURE") / len(eff)
                                 - sum(1 for v in eff.values() if v["keep"]["verdict"] == "STALE_FAILURE") / len(eff)), 4) if eff else None),
        "discordant_improved": improved, "discordant_worsened": worsened,
        "mcnemar_exact_p": exact_binom_two_sided(improved, worsened) if eff else None,
        "cost_ratio_del_over_keep": (round((td / len(eff)) / (tk / len(eff)), 4) if eff and tk else None),
        "cost_ok_le_1_10": ((td / tk) <= 1.10 if eff and tk else None),
    }
    return {"cells": cells, "paired": pairs,
            "n_records": len(records),
            "transport_loss_total": sum(1 for r in records if r["transport_loss"])}


def exact_binom_two_sided(b: int, c: int) -> float:
    import math
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    tail = sum(math.comb(n, i) for i in range(k + 1)) / (2 ** n)
    return min(1.0, 2 * tail)


def selftest() -> None:
    ok = 0
    card = make_card(40, 200000)

    env = EnvSC(card)
    st = env.stat(card)
    assert "target" not in st and "plan_version" not in st and "resource" not in st, st
    print("[PASS] stat 不泄漏 plan/target/resource"); ok += 1

    env.inject(card)
    r = dispatch({"function": {"name": "write", "arguments": json.dumps(
        {"files": ["f00"], "resource": "store-a", "target": card["target_v1"],
         "basis_version": 1})}}, env, card, {})
    assert r["error"] == "stale_basis" and "current_plan_version" not in r, r
    r2 = dispatch({"function": {"name": "write", "arguments": json.dumps(
        {"files": ["f01"], "resource": "store-b", "target": card["target_v1"],
         "basis_version": 2})}}, env, card, {})
    assert r2["error"] == "wrong_target" and "current_target" not in r2, r2
    print("[PASS] stale_basis / wrong_target 不回授正确值"); ok += 1

    # 两臂提示逐字相同（载体不在提示里）
    keep_msgs = [{"role": "system", "content": SYSTEM_PROMPT.format(
        n_files=40, first="f00", last="f39")}] + carrier_messages(card)
    del_msgs = [{"role": "system", "content": SYSTEM_PROMPT.format(
        n_files=40, first="f00", last="f39")}]
    assert keep_msgs[0]["content"] == del_msgs[0]["content"]
    print("[PASS] 两臂 system 提示逐字相同（载体只在历史）"); ok += 1

    # GREEN：载体在历史 → RECOVERED
    tr = run_episode(ScriptedClient(True), card, keep_carrier=True)
    assert tr["verdict"] == "RECOVERED", (tr["verdict"], tr["final"])
    print(f"[PASS] GREEN 载体在历史 → RECOVERED（verified {tr['final']['verified_count']}/40）"); ok += 1

    # RED：裁掉历史 → STALE_FAILURE
    tr2 = run_episode(ScriptedClient(False), card, keep_carrier=False)
    assert tr2["verdict"] == "STALE_FAILURE", (tr2["verdict"], tr2["final"])
    print(f"[PASS] RED 裁掉历史载体 → STALE_FAILURE（verified {tr2['final']['verified_count']}/40）"); ok += 1

    # 截断型 INCOMPLETE 单列（D10.2）
    fake = {"steps": [{"step": 0, "plan_version": 1, "tool_calls": [], "finish": "length"}],
            "injection": {"step": 0}, "final": {"empty_tail": True, "last_finish": "length",
                                                "verified_count": 0, "n_files": 40}}
    assert verdict_of(fake) == "INCOMPLETE_TRUNCATED", verdict_of(fake)
    fake["final"]["last_finish"] = "stop"
    assert verdict_of(fake) == "STALE_FAILURE", verdict_of(fake)
    print("[PASS] 截断型 INCOMPLETE 与能力型分列"); ok += 1

    # 第五类 PRE_INJECTION_COMPLETION：注入前写满、非截断（D12.4.3 / §4.2）
    pic = {"steps": [{"step": 0, "plan_version": 1,
                      "tool_calls": [{"tool": "write", "args": {"files": ["f00"],
                                                                "basis_version": 1}}],
                      "finish": "tool_calls"}],
           "injection": None,
           "final": {"empty_tail": False, "last_finish": "tool_calls",
                     "verified_count": 40, "n_files": 40}}
    assert verdict_of(pic) == "PRE_INJECTION_COMPLETION", verdict_of(pic)
    # 截断优先于 PIC（量具截断不能算"完成得快"）
    pic["final"]["empty_tail"] = True
    pic["final"]["last_finish"] = "length"
    assert verdict_of(pic) == "INCOMPLETE_TRUNCATED", verdict_of(pic)
    # 假阳守卫：注入未触发但没写满 → 仍 INCOMPLETE，不得算 PIC
    pic["final"]["empty_tail"] = False
    pic["final"]["last_finish"] = "tool_calls"
    pic["final"]["verified_count"] = 39
    assert verdict_of(pic) == "INCOMPLETE", verdict_of(pic)
    print("[PASS] 第五类 PIC 命中、截断优先、假阳不误判"); ok += 1

    c1, c2 = make_client("http://x", "m"), make_client("http://x", "m")
    assert c1 is not c2 and c1.calls == 0
    print("[PASS] make_client 每次新实例（D9）"); ok += 1

    print(f"SELFTEST PASS ({ok}/8)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--base-url", default=DEFAULT_BASE)
    ap.add_argument("--model", default="workbuddy/deepseek-v4.1-flash")
    ap.add_argument("--cards", type=int, default=40)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--out", default="runs/l3-v2-sc")
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        selftest()
        return 0

    out = pathlib.Path(args.out)
    for sub in ("traces", "judgements"):
        (out / sub).mkdir(parents=True, exist_ok=True)

    cards = [make_card(40, 200000 + i * 1000) for i in range(args.cards)]
    jobs = [(c, arm) for c in cards for arm in (True, False)]
    slug_of = lambda c, keep: f"{args.model.replace('/', '_')}__{c['card_id']}__{'keep' if keep else 'del'}__r0"

    done = set()
    records = []
    if args.resume:
        for p in (out / "judgements").glob("*.json"):
            j = json.loads(p.read_text(encoding="utf-8"))
            records.append({"card_id": j["card_id"], "arm": j["arm"], "verdict": j["verdict"],
                            "slug": j["slug"], "tokens": j["tokens"], "steps": j["steps"],
                            "verified": j["verified"], "errors": j["errors"],
                            "transport_loss": j["transport_loss"]})
            done.add(j["slug"])

    lock = threading.Lock()
    t0 = time.time()
    state = {"finished": False, "planned": len(jobs), "done_slugs": done}

    def write_state():
        tmp = out / "state.json.tmp"
        tmp.write_text(json.dumps(state, ensure_ascii=False, default=list), encoding="utf-8")
        tmp.replace(out / "state.json")

    def work(job):
        card, keep = job
        slug = slug_of(card, keep)
        if slug in done:
            return None
        client = make_client(args.base_url, args.model)
        tr = run_episode(client, card, keep_carrier=keep)
        tr["slug"] = slug
        name = f"{args.model.replace('/', '_')}__{card['card_id']}__{'keep' if keep else 'del'}__r0"
        (out / "traces" / f"{name}.json").write_text(
            json.dumps(tr, ensure_ascii=False, indent=1), encoding="utf-8")
        jm = {"schema": "l3-judgement-v2sc/v1", "slug": name, "card_id": card["card_id"],
              "arm": "keep" if keep else "del", "carrier": "S_c:history",
              "verdict": tr["verdict"], "metrics": tr["final"],
              "tokens": tr["usage"]["prompt_tokens"] + tr["usage"]["completion_tokens"],
              "verified": tr["final"]["verified_count"], "steps": tr["final"]["trajectory_length"],
              "errors": tr["errors"],
              "transport_loss": any("transport" in str(e) for e in tr["errors"])}
        (out / "judgements" / f"{name}.json").write_text(
            json.dumps(jm, ensure_ascii=False, indent=1), encoding="utf-8")
        with lock:
            records.append({k: jm[k] for k in ("card_id", "arm", "verdict", "slug",
                                               "tokens", "verified", "steps", "errors",
                                               "transport_loss")})
            state["done_slugs"].add(name)
            write_state()
        return jm

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(work, jobs))

    records.sort(key=lambda r: (r["card_id"], r["arm"]))
    state["finished"] = True
    write_state()
    summary = summarize(records)
    report = {"schema": "l3-v2-sc-report/v1", "model": args.model, "cards": len(cards),
              "arms": ["keep", "del"], "carrier": "S_c:history",
              "max_tokens": MAX_TOKENS_V2, "inject_turn": INJECT_TURN,
              "wall_clock_s": round(time.time() - t0, 2), **summary}
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1),
                                     encoding="utf-8")
    print(json.dumps({"cells": summary["cells"], "paired": summary["paired"]},
                     ensure_ascii=False, indent=1))
    print(f"records={len(records)} wall={report['wall_clock_s']}s out={out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
