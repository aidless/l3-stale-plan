#!/usr/bin/env python3
"""从载体（judgements/*.json）重生成 v2 批次的 report.json。

为什么需要它（两个已发生的实证）：
  1. `runs/l3-v2-sc-40-kimi-lowspeed/report.json` 记 cost_ratio 3.7622，从 80 份 judgement 重算得 3.8151
     （相对偏差 1.4%）——runner 的 `records` 只含**当轮** work() 返回项，`--resume` 时旧 judgement 不入账，
     跨多轮监督器 + purge 的批次，report 是某一轮内存 records 的快照，与盘上载体脱钩。
  2. `runs/l3-v2-sc-40-hy4free2/` 因 runner 被 timeout 杀死，根本没写 report.json，只有 29 份 judgement。

本脚本只做一件事：summary 一律由载体现算，不读旧 report 的任何统计字段。
旧 report 若存在，先备份成 report.json.bak-<UTC> 再覆盖。

用法：
  python3 resummarize_v2.py --run-dir runs/l3-v2-sc-40-hy4free2 --apply
  python3 resummarize_v2.py --selftest
"""
import argparse
import json
import pathlib
import shutil
import sys
import tempfile
import time

import v2_runner_sc as v2

REQUIRED = ("arm", "card_id", "verdict", "tokens", "verified", "transport_loss", "slug")


def load_records(run_dir: pathlib.Path) -> list[dict]:
    """读 judgements/ 下全部载体，缺字段即抛。"""
    files = sorted((run_dir / "judgements").glob("*.json"))
    if not files:
        raise SystemExit(f"{run_dir}: judgements/ 为空，无载体可复算")
    out = []
    for f in files:
        j = json.loads(f.read_text(encoding="utf-8"))
        missing = [k for k in REQUIRED if k not in j]
        if missing:
            raise SystemExit(f"{f.name}: 缺字段 {missing}")
        if j["slug"] != f.stem:
            raise SystemExit(f"{f.name}: slug={j['slug']} 与文件名不符")
        out.append(j)
    out.sort(key=lambda r: (r["card_id"], r["arm"]))
    return out


def infer_model(run_dir: pathlib.Path, records: list[dict]) -> str:
    rp = run_dir / "report.json"
    if rp.exists():
        try:
            m = json.loads(rp.read_text(encoding="utf-8")).get("model")
            if m:
                return m
        except json.JSONDecodeError:
            pass
    sp = run_dir / "state.json"
    if sp.exists():
        try:
            m = json.loads(sp.read_text(encoding="utf-8")).get("model")
            if m:
                return m
        except json.JSONDecodeError:
            pass
    # slug 形如 <model with / -> _>__<card>__<arm>__r0
    return records[0]["slug"].split("__")[0].replace("_", "/", 1)


def rebuild(run_dir: pathlib.Path, apply: bool = False) -> dict:
    records = load_records(run_dir)
    summary = v2.summarize(records)
    model = infer_model(run_dir, records)
    rp = run_dir / "report.json"
    old = None
    if rp.exists():
        old = json.loads(rp.read_text(encoding="utf-8"))
    n_cards = len({r["card_id"] for r in records})
    report = {
        "schema": "l3-v2-sc-report/v1",
        "model": model,
        "cards": n_cards,
        "arms": ["keep", "del"],
        "carrier": "S_c:history",
        "max_tokens": v2.MAX_TOKENS_V2,
        "inject_turn": v2.INJECT_TURN,
        "wall_clock_s": (old or {}).get("wall_clock_s"),
        "resummarized_from_carriers": True,
        "carrier_judgements": len(records),
        **summary,
    }
    drift = {}
    if old:
        for key in ("n_records", "transport_loss_total"):
            if old.get(key) != report.get(key):
                drift[key] = {"old": old.get(key), "new": report.get(key)}
        for arm in ("keep", "del"):
            o, n = (old.get("cells") or {}).get(arm) or {}, summary["cells"][arm]
            for k in n:
                if k in o and o[k] != n[k]:
                    drift[f"cells.{arm}.{k}"] = {"old": o[k], "new": n[k]}
        for k, val in summary["paired"].items():
            o = (old.get("paired") or {}).get(k)
            if o != val:
                drift[f"paired.{k}"] = {"old": o, "new": val}
    if apply:
        if rp.exists():
            bak = rp.with_suffix(f".json.bak-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}")
            shutil.copy2(rp, bak)
        rp.write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"run_dir": str(run_dir), "model": model, "carrier_judgements": len(records),
            "cells": summary["cells"], "paired": summary["paired"], "drift_vs_old_report": drift,
            "applied": apply, "report_exists": rp.exists()}


def selftest() -> int:
    results = []
    # GREEN：三批已知批次，重算必须与已登记 report 逐字段相等（kimi 的 cost_ratio 是已记录的偏差，单列）
    for batch, exact in (("l3-v2-sc-40-minimax", True),
                         ("l3-v2-sc-40-workbuddy2", True),
                         ("l3-v2-sc-40-kimi-lowspeed", False)):
        d = pathlib.Path("runs") / batch
        out = rebuild(d, apply=False)
        if exact:
            ok = not out["drift_vs_old_report"]
            results.append((f"GREEN {batch} 重算与登记 report 逐字段相等", ok,
                            "" if ok else json.dumps(out["drift_vs_old_report"], ensure_ascii=False)))
        else:
            drift = out["drift_vs_old_report"]
            keys = set(drift)
            # kimi 批因 --resume 漏账，登记 report 与载体有两处已知偏差（均在 DEVIATION D13 记录）：
            #   del median_tokens 35960 → 36859；cost_ratio 3.7622 → 3.8151
            ok = keys == {"paired.cost_ratio_del_over_keep", "cells.del.median_tokens"}
            results.append((f"GREEN {batch} 偏差必须恰好是已登记的两项（3.7622→3.8151、35960→36859）",
                            ok, json.dumps(sorted(keys))))
    # RED：删掉一份 judgement，n_records 必须与旧 report 不符
    src = pathlib.Path("runs/l3-v2-sc-40-minimax")
    with tempfile.TemporaryDirectory() as td:
        dst = pathlib.Path(td) / "cut"
        shutil.copytree(src, dst)
        victim = sorted((dst / "judgements").glob("*.json"))[0]
        victim.unlink()
        out = rebuild(dst, apply=False)
        ok = out["drift_vs_old_report"].get("n_records") is not None
        results.append(("RED 删一份载体后 n_records 必须与旧 report 不符", ok,
                        json.dumps(out["drift_vs_old_report"].get("n_records"))))
    # RED-2：无载体必须拒绝
    with tempfile.TemporaryDirectory() as td:
        empty = pathlib.Path(td) / "empty"
        (empty / "judgements").mkdir(parents=True)
        try:
            load_records(empty)
            results.append(("RED-2 空 judgements 必须拒绝", False, "未抛 SystemExit"))
        except SystemExit as e:
            results.append(("RED-2 空 judgements 必须拒绝", True, str(e)))
    bad = [r for r in results if not r[1]]
    for name, ok, detail in results:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
    print(f"SELFTEST {'PASS' if not bad else 'FAIL'} ({len(results) - len(bad)}/{len(results)})")
    return 0 if not bad else 1


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.run_dir:
        print("需要 --run-dir 或 --selftest", file=sys.stderr)
        return 2
    out = rebuild(pathlib.Path(a.run_dir), apply=a.apply)
    print(json.dumps(out, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
