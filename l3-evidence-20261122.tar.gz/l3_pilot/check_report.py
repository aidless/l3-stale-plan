#!/usr/bin/env python3
"""Recompute every report number from raw traces + judgements. Exit 1 on mismatch."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from judge import VERDICT_STALE, judge


def stable_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(run_dir: Path) -> list[str]:
    errors: list[str] = []
    report_path = run_dir / "report.json"
    if not report_path.exists():
        return ["missing report.json"]
    report = json.loads(report_path.read_text(encoding="utf-8"))

    if stable_hash(run_dir / "cards" / "manifest.json") != report["cards_manifest_sha256"]:
        errors.append("cards manifest sha256 mismatch")

    recomputed = []
    for index, row in enumerate(report["records"]):
        trace_path = run_dir / row["trace"]
        judgement_path = run_dir / row["judgement"]
        if not trace_path.exists() or not judgement_path.exists():
            errors.append(f"record {index}: missing raw artifact")
            continue
        if stable_hash(trace_path) != row["trace_sha256"] or stable_hash(trace_path) != stable_hash(trace_path):
            errors.append(f"record {index}: trace hash mismatch")
        trace = json.loads(trace_path.read_text(encoding="utf-8"))
        judgement = json.loads(judgement_path.read_text(encoding="utf-8"))
        fresh = judge(trace)
        if fresh["verdict"] != judgement["verdict"] or fresh["metrics"] != judgement["metrics"]:
            errors.append(f"record {index}: judgement does not recompute from trace")
        if judgement["verdict"] != row["verdict"] or judgement["metrics"] != row["metrics"]:
            errors.append(f"record {index}: report row disagrees with judgement")
        recomputed.append(row)

    for policy, values in report["summary"].items():
        rows = [row for row in recomputed if row["policy"] == policy]
        expected = {
            "n": len(rows),
            "stale_failure_count": sum(row["verdict"] == VERDICT_STALE for row in rows),
            "stale_failure_rate": sum(row["verdict"] == VERDICT_STALE for row in rows) / len(rows),
            "mean_tool_call_count": sum(row["metrics"]["tool_call_count"] for row in rows) / len(rows),
            "mean_token_proxy": sum(row["metrics"]["token_proxy"] for row in rows) / len(rows),
            "mean_repeat_action_count": sum(row["metrics"]["repeat_action_count"] for row in rows) / len(rows),
            "mean_verified_count": sum(row["metrics"]["verified_count"] for row in rows) / len(rows),
        }
        for key, value in expected.items():
            if values.get(key) != value:
                errors.append(f"summary {policy}.{key}: {values.get(key)!r} != recomputed {value!r}")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    errors = check(args.run_dir.resolve())
    if errors:
        for error in errors:
            print(f"FAIL: {error}")
        return 1
    print(f"OK: {args.run_dir} recomputes from raw artifacts")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
