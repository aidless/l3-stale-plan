"""Deterministic state machine and scripted policies.

No model calls, no API keys. This engine only produces traces; verdicts are
computed separately by judge.py so the ruler cannot answer for itself.
"""
from __future__ import annotations

import json
from pathlib import Path

POLICIES = ("stale", "reactive", "memory_delete")


class Env:
    def __init__(self, card: dict):
        self.plan_version = 1
        self.target = card["target_v1"]
        self.available = {card["resources"][0]: True, card["resources"][1]: True}
        self.migrated: list[str] = []
        self.verified: list[str] = []
        self.injected = False

    def inject(self, card: dict) -> None:
        self.plan_version = 2
        self.target = card["target_v2"]
        self.available[card["resources"][0]] = False
        self.injected = True

    def stat(self, card: dict) -> dict:
        resource = card["resources"][0] if self.available[card["resources"][0]] else card["resources"][1]
        return {"plan_version": self.plan_version, "target": self.target, "resource": resource}


def token_proxy(tool_calls: list[dict]) -> int:
    return sum(len(json.dumps(call, ensure_ascii=False, sort_keys=True)) // 4 for call in tool_calls)


def run_card(card: dict, policy: str, repeat: int = 0) -> dict:
    if policy not in POLICIES:
        raise ValueError(f"unknown policy: {policy}")

    env = Env(card)
    memory = [dict(entry) for entry in card["memory"]]
    if policy == "memory_delete":
        memory = [entry for entry in memory if entry["id"] != "m-plan"]

    plan_present = any(entry["id"] == "m-plan" for entry in memory)
    basis_version = 1
    resource = card["resources"][0]
    target = card["target_v1"]
    file_index = 0
    total_tool_calls = 0
    trace = {
        "schema": "l3-trace/v1",
        "card_id": card["card_id"],
        "card_sha256": card["card_sha256"],
        "policy": policy,
        "repeat": repeat,
        "source": "simulated_no_llm",
        "no_llm_calls": True,
        "memory_ids": [entry["id"] for entry in memory],
        "injection": None,
        "steps": [],
    }

    for step in range(card["n_steps"]):
        if step == card["inject_step"]:
            env.inject(card)
            trace["injection"] = {
                "step": step,
                "from_version": 1,
                "to_version": 2,
                "kind": card["injection"]["kind"],
            }

        should_stat = policy == "reactive" or (policy == "memory_delete" and not plan_present) or step == 0
        calls: list[dict] = []

        if should_stat:
            observed = env.stat(card)
            calls.append({"tool": "stat", "args": {}, "result": dict(observed)})
            basis_version = observed["plan_version"]
            resource = observed["resource"]
            target = observed["target"]

        file_name = card["files"][file_index]
        write_ok = (
            basis_version == env.plan_version
            and resource in env.available
            and env.available[resource]
            and target == env.target
        )
        reason = None
        if not write_ok:
            reason = "stale_basis" if basis_version < env.plan_version else "resource_or_target_mismatch"
        calls.append(
            {
                "tool": "write",
                "args": {"file": file_name, "resource": resource, "target": target, "basis_version": basis_version},
                "ok": write_ok,
                "reason": reason,
            }
        )
        if write_ok:
            env.migrated.append(file_name)
            env.verified.append(file_name)
            calls.append({"tool": "verify", "args": {"file": file_name}, "ok": True})
            file_index = min(file_index + 1, card["n_steps"] - 1)

        total_tool_calls += len(calls)
        trace["steps"].append(
            {"step": step, "plan_version": env.plan_version, "tool_calls": calls}
        )

    trace["final"] = {
        "migrated_count": len(env.migrated),
        "verified_count": len(env.verified),
        "n_files": card["n_steps"],
        "final_target": env.target,
        "tool_call_count": total_tool_calls,
        "trajectory_length": len(trace["steps"]),
        "token_proxy": token_proxy(
            [call for step in trace["steps"] for call in step["tool_calls"]]
        ),
    }
    return trace


def load_card(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))
