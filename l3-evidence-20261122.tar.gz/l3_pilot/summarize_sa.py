#!/usr/bin/env python3
"""从 S_a judgements+traces 现算汇总（新尺先验底物纪律）。

用法：
  python3 summarize_sa.py --run-dir runs/l3-sa-smoke2 --expect smoke   # 对表 2 卡 smoke
  python3 summarize_sa.py --run-dir runs/l3-sa-sc-40 --out runs/l3-sa-sc-40-sa.json
"""
from __future__ import annotations

import argparse
import json
import pathlib
import statistics
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import v2_runner_sc as v2  # noqa: E402

SCHEMA = "l3-sa-summary/v1"
VERDICTS = ("RECOVERED", "STALE_FAILURE", "INCOMPLETE",
            "INCOMPLETE_TRUNCATED", "PRE_INJECTION_COMPLETION")

# 2 卡 smoke 的实测金标（来自 sa_runner.py 落盘的 report + judgements 现算）
SMOKE_EXPECT = {
    "n_records": 4,
    "cells.keep.RECOVERED": 2,
    "cells.del.STALE_FAILURE": 2,
    "paired.diff_pp": 100.0,
    "paired.mcnemar_exact_p": 0.5,
    "paired.cost_ratio_del_over_keep": 1.8942,
    "writes.keep.ok_before_injection_total": 3,
    "writes.del.ok_before_injection_total": 2,
}

# 40 卡分层金标（stratum = del 臂注入前成功写 > 0），从载体现算后钉死。
# 注意方向口径与 v2.summarize 一致：
#   improved  = keep STALE 且 del 非 STALE（删臂"救回"）
#   worsened  = del STALE 且 keep 非 STALE（删臂"搞坏"）
# 旧的一次性内联脚本 l3-sa-sc-40-stratified.json 把这两个标签写反了
# （improved=10/worsened=3）；McNemar 双侧 p 对称所以数值没暴露，此处纠正。
STRATUM = "del_pre_ok_gt_0"
STRAT_EXPECT = {
    "stratum": STRATUM,
    "n_pairs": 25,
    "keep_stale": 3,
    "del_stale": 10,
    "keep_stale_rate": 0.12,
    "del_stale_rate": 0.4,
    "diff_pp": 28.0,
    "improved": 3,
    "worsened": 10,
    "mcnemar_exact_p": 0.09228515625,
    "cost_ratio": 1.256,
}


def compute(run_dir: pathlib.Path) -> dict:
    jdir = run_dir / "judgements"
    js = [json.loads(p.read_text(encoding="utf-8"))
          for p in sorted(jdir.glob("*.json"))]
    recs = [{k: j[k] for k in ("card_id", "arm", "verdict", "slug", "tokens",
                               "verified", "steps", "errors", "transport_loss")}
            for j in js]
    summary = v2.summarize(recs)
    cells = summary["cells"]
    paired = summary["paired"]
    writes = {}
    for arm in ("keep", "del"):
        subset = [j for j in js if j["arm"] == arm and not j["transport_loss"]]
        writes[arm] = {
            "n": len(subset),
            "episodes_with_ok_write": sum(1 for j in subset if j.get("ok_writes", 0) > 0),
            "ok_before_injection_total": sum(j.get("ok_before_injection", 0) for j in subset),
            "delivered_all_files": sum(1 for j in subset if j["verified"] == j["metrics"]["n_files"]),
            "median_tokens": statistics.median([j["tokens"] for j in subset]) if subset else None,
        }
    return {
        "schema": SCHEMA, "run_dir": str(run_dir),
        "n_records": len(js),
        "transport_loss_total": sum(1 for j in js if j.get("transport_loss")),
        "cells": cells, "paired": paired, "writes": writes,
    }


def stratified(run_dir: pathlib.Path) -> dict:
    """分层：只取 del 臂注入前确实成功写过的卡对，去掉「只检索不写」行为差异。

    方向口径严格对齐 v2.summarize：improved = keep stale & del 非 stale；
    worsened = del stale & keep 非 stale。 McNemar 双侧对称，但方向标签不可反。
    """
    jdir = run_dir / "judgements"
    js = [json.loads(p.read_text(encoding="utf-8"))
          for p in sorted(jdir.glob("*.json"))]
    by: dict[str, dict] = {}
    for j in js:
        if j.get("transport_loss"):
            continue
        by.setdefault(j["card_id"], {})[j["arm"]] = j
    pairs = {c: a for c, a in by.items()
             if "keep" in a and "del" in a
             and a["del"].get("ok_before_injection", 0) > 0}
    n = len(pairs)
    if not n:
        return {"stratum": STRATUM, "n_pairs": 0,
                "note": "no paired card with del ok_before_injection > 0"}
    ks = sum(1 for a in pairs.values() if a["keep"]["verdict"] == "STALE_FAILURE")
    ds = sum(1 for a in pairs.values() if a["del"]["verdict"] == "STALE_FAILURE")
    improved = worsened = 0
    for a in pairs.values():
        k = a["keep"]["verdict"] == "STALE_FAILURE"
        d = a["del"]["verdict"] == "STALE_FAILURE"
        if k and not d:
            improved += 1
        elif d and not k:
            worsened += 1
    tk = sum(a["keep"]["tokens"] for a in pairs.values())
    td = sum(a["del"]["tokens"] for a in pairs.values())
    p = v2.exact_binom_two_sided(improved, worsened)
    assert 0.0 <= p <= 1.0, ("p_out_of_range", STRATUM, p)
    return {
        "stratum": STRATUM, "n_pairs": n,
        "keep_stale": ks, "del_stale": ds,
        "keep_stale_rate": round(ks / n, 4), "del_stale_rate": round(ds / n, 4),
        "diff_pp": round(100 * (ds - ks) / n, 4),
        "improved": improved, "worsened": worsened,
        "mcnemar_exact_p": p,
        "cost_ratio": round(td / tk, 4) if tk else None,
    }


def flat(d: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in d.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            out.update(flat(v, key))
        else:
            out[key] = v
    return out


def check_against(d: dict, expect: dict) -> list[str]:
    flat_d = flat(d)
    bad = []
    for k, v in expect.items():
        got = flat_d.get(k)
        if isinstance(v, float):
            ok = got is not None and abs(float(got) - v) < 1e-6
        else:
            ok = got == v
        if not ok:
            bad.append(f"{k}: expect={v} got={got}")
    return bad


def selftest() -> None:
    root = pathlib.Path(__file__).resolve().parent
    smoke = root / "runs" / "l3-sa-smoke2"
    assert smoke.exists(), f"smoke run missing: {smoke}"
    d = compute(smoke)
    bad = check_against(d, SMOKE_EXPECT)
    assert not bad, ("对表失败（新尺读错底物）", bad)
    print(f"[PASS] GREEN 对表 2 卡 smoke 全部 {len(SMOKE_EXPECT)} 项一致")
    # RED：改一个金标必须被抓出来
    wrong = dict(SMOKE_EXPECT, **{"paired.diff_pp": 99.0})
    assert check_against(d, wrong), "RED 未触发：篡改金标未被抓出"
    print("[PASS] RED 篡改金标必被抓出（尺子会红）")
    # 分层金标对表：新写的 stratified() 必须先读对 40 卡已知分层
    run40 = root / "runs" / "l3-sa-sc-40"
    assert run40.exists(), f"40 card run missing: {run40}"
    st = stratified(run40)
    bad2 = check_against(st, STRAT_EXPECT)
    assert not bad2, ("分层对表失败（新尺读错底物）", bad2)
    print(f"[PASS] GREEN 分层对表 40 卡全部 {len(STRAT_EXPECT)} 项一致")
    # RED-分层：方向标签写反必须被抓出（旧内联脚本的真实缺陷）
    wrong2 = dict(STRAT_EXPECT, **{"improved": 10, "worsened": 3})
    assert check_against(st, wrong2), "RED-分层 未触发：方向标签写反未被抓出"
    print("[PASS] RED-分层 方向标签写反必被抓出（improved/worsened 不可反）")
    print("SELFTEST PASS (4/4)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--run-dir", default="runs/l3-sa-sc-40")
    ap.add_argument("--expect", choices=["smoke"], default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    if args.selftest:
        selftest()
        return 0
    rd = pathlib.Path(args.run_dir)
    d = compute(rd)
    if args.expect == "smoke":
        bad = check_against(d, SMOKE_EXPECT)
        assert not bad, ("对表失败", bad)
        print("[PASS] 对表 smoke 一致")
    st = stratified(rd)
    d["stratified"] = st
    if args.out:
        pathlib.Path(args.out).write_text(json.dumps(d, ensure_ascii=False, indent=1),
                                          encoding="utf-8")
        print(f"wrote {args.out}")
    print(json.dumps({"n_records": d["n_records"],
                      "transport_loss_total": d["transport_loss_total"],
                      "cells": {k: {kk: v[kk] for kk in ("RECOVERED", "STALE_FAILURE", "n") if kk in v}
                                for k, v in d["cells"].items()},
                      "paired": d["paired"], "writes": d["writes"],
                      "stratified": st},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
