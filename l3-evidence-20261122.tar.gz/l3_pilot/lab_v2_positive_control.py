"""L3 v2 阳性对照环境（D11.5）。

目的：给 D11.4 的载体判据做一次「能失败」的检验 —— 造一个**记忆是唯一信息源**的
环境，验证「删条目 → stale 率显著上升」确实可测。

与 v1 的差别（全部在编排层新文件里，冻结层 6 文件一字未动）：
  1. `stat()` 不返回 target / resource / plan_version，只回一句「没有计划信息，查你的记忆」。
  2. `write` 的错误响应**不回授正确值**（v1 的 stale_basis 带 current_plan_version、
     wrong_target 带 current_target，是免费纠错 —— 见 D11.2）。
  3. 计划以**映射表**形态写进 memory，同时含 v1 行与 v2 行；注入后必须改用 v2 行。
  4. `max_tokens` 提到 1600（D10 的截断修法）。
  5. 提示对两条臂**逐字相同**（D6/D11 的混杂教训）。

判据：
  - GREEN：memory 完整 → 模型能读到 v2 行 → 写对 → RECOVERED
  - RED：删 m-plan → 无从得知 v2 → 必用 v1 → STALE_FAILURE
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import agent_arm  # noqa: E402  只用它的 Client / Budget / TOOLS，不用 run_episode
import judge as judge_mod  # noqa: E402

DEFAULT_BASE = "http://127.0.0.1:3425/v1"
MAX_TOKENS_V2 = 1600          # D10：v1 的 400 撞 reasoning 模型必然截断
MAX_WRITES_PER_TURN = 8
SOFT_INJECT_AFTER = 2

# 两条臂用**同一个**提示，唯一的差别是记忆里有没有 m-plan（D11.4 判据）
SYSTEM_PROMPT_V2 = (
    "You are an agent migrating files on a remote storage service.\n"
    "Goal: all files written to the current target path.\n"
    "There are {n_files} files: {first} .. {last}.\n"
    "Known memory:\n"
    "{memory_lines}\n"
    "Rules:\n"
    "- The service may change at any time. `stat` alone will NOT tell you the plan.\n"
    "- `write` needs the plan_version your write is based on (an integer).\n"
    "  A write based on an outdated plan_version will be rejected.\n"
    "- A turn may contain at most 8 `write` calls; you cannot finish everything in one turn.\n"
    "- When the service changes, which plan row still holds? Only your memory says.\n"
    "- Use `verify` only for files you already wrote.\n"
    "Reply with tool calls only; no prose."
)

TOOLS_V2 = agent_arm.TOOLS  # 工具签名不变；变的是服务端行为


class EnvV2:
    """记忆是唯一计划来源的环境。`stat()` 故意什么都不泄漏。"""

    def __init__(self, card: dict):
        self.plan_version = 1
        self.target = card["target_v1"]
        self.available = {card["resources"][0]: True, card["resources"][1]: True}
        self.injected = False

    def inject(self, card: dict) -> None:
        self.plan_version = 2
        self.target = card["target_v2"]
        self.available[card["resources"][0]] = False
        self.injected = True

    def stat(self, card: dict) -> dict:
        # 关键：v1 这里回 {plan_version, target, resource}，与 m-plan 逐字段冗余（D11.1）。
        # v2 什么都不回 —— 计划只能来自 memory。
        return {
            "note": "the service does not publish a plan; consult your memory for "
                    "the resource, target path and plan_version",
            "files_seen": 0,
        }


def system_prompt_v2(card: dict, memory: list[dict]) -> str:
    lines = "\n".join(f"- [{e['kind']}] {e['text']}" for e in memory) or "- (no stored plan)"
    return SYSTEM_PROMPT_V2.format(
        n_files=card["n_steps"],
        first=card["files"][0],
        last=card["files"][-1],
        memory_lines=lines,
    )


def dispatch_v2(call: dict, env: EnvV2, card: dict, written: dict) -> dict:
    function = call.get("function") or {}
    name = function.get("name")
    raw = function.get("arguments") or "{}"
    try:
        args = json.loads(raw) if isinstance(raw, str) else dict(raw)
    except json.JSONDecodeError:
        return {"ok": False, "error": "arguments_not_json"}

    if name == "stat":
        return {"ok": True, "result": env.stat(card)}

    if name == "write":
        files = args.get("files")
        if files is None and args.get("file") is not None:
            files = [args.get("file")]
        if not isinstance(files, list) or not files:
            files = [args.get("file")]
        names = [agent_arm.normalize_file(x, card) for x in files]
        if any(n is None for n in names):
            return {"ok": False, "error": "unknown_file",
                    "hint": f"use one of: {', '.join(card['files'][:5])} ... {card['files'][-1]}"}
        resource = str(args.get("resource", ""))
        target = str(args.get("target", ""))
        basis = agent_arm.coerce_version(args.get("basis_version"))
        if basis is None:
            return {"ok": False, "error": "basis_version_missing"}
        if basis < env.plan_version:
            # v1 回 {"current_plan_version": 2}；v2 不回 —— 不免费纠错（D11.2 的修法）
            return {"ok": False, "error": "stale_basis",
                    "hint": "this basis is from an outdated plan; find the current row"}
        if basis > env.plan_version:
            return {"ok": False, "error": "future_basis"}
        if resource not in env.available or not env.available[resource]:
            return {"ok": False, "error": "resource_unavailable"}
        if target != env.target:
            # v1 回 {"current_target": ...}；v2 不回
            return {"ok": False, "error": "wrong_target",
                    "hint": "this target is not the current one; find the current row"}
        accepted, dup = [], []
        for n in names:
            if written.get(n):
                dup.append(n)
            elif len(accepted) >= MAX_WRITES_PER_TURN:
                return {"ok": False, "error": "too_many_writes_in_one_turn",
                        "accepted_before_refusal": accepted}
            else:
                written[n] = True
                accepted.append(n)
        if not accepted:
            return {"ok": False, "error": "already_written", "files": dup}
        return {"ok": True, "result": {"files": accepted, "target": target}}

    if name == "verify":
        f = str(args.get("file", ""))
        if written.get(f):
            return {"ok": True, "result": {"file": f, "verified": True}}
        return {"ok": False, "error": "not_written"}
    return {"ok": False, "error": "unknown_tool"}


def make_client(base_url: str, model: str, max_calls: int) -> "ClientV2":
    """每 episode 必须新实例（D9：calls 挂实例、无 reset）。"""
    return ClientV2(base_url, model, max_calls)


class ClientV2(agent_arm.Client):
    """只改 max_tokens（D10）；其余与冻结层同构。"""

    def complete(self, messages: list[dict]) -> dict:
        if self.calls >= self.max_calls:
            raise agent_arm.Budget(f"model call budget exhausted after {self.calls} calls")
        payload = {
            "model": self.model,
            "messages": messages,
            "tools": TOOLS_V2,
            "tool_choice": "auto",
            "max_tokens": MAX_TOKENS_V2,   # v1: 400
            "temperature": 0,
        }
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        self.calls += 1
        body = None
        for attempt in range(3):          # 网关偶发非 JSON/空体：重试至 3 次
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    raw = resp.read().decode("utf-8")
                body = json.loads(raw)
                break
            except json.JSONDecodeError:
                if attempt == 2:
                    raise
                time.sleep(2 * (attempt + 1))
        usage = body.get("usage") or {}
        self.prompt_tokens += usage.get("prompt_tokens") or 0
        self.completion_tokens += usage.get("completion_tokens") or 0
        return body["choices"][0]


def run_episode_v2(client, card: dict, keep_plan: bool, max_turns: int = 20) -> dict:
    env = EnvV2(card)
    memory = [dict(e) for e in card["memory"]]
    if not keep_plan:
        memory = [e for e in memory if e["id"] != "m-plan"]
    written: dict[str, bool] = {}
    messages = [{"role": "system", "content": system_prompt_v2(card, memory)}]
    trace = {
        "schema": "l3-trace-v2/v1",
        "card_id": card["card_id"],
        "card_sha256": card.get("card_sha256"),
        "arm": "keep_plan" if keep_plan else "del_plan",
        "model": getattr(client, "model", "?"),
        "memory_ids": [e["id"] for e in memory],
        "injection": None,
        "steps": [],
        "errors": [],
        "budget_exhausted": False,
    }
    started = time.time()

    for turn in range(max_turns):
        if sum(written.values()) >= card["n_steps"]:
            break
        # 注入按固定 turn 触发（两臂同点），不依赖已写文件数 —— 否则 del 臂
        # 写不到 4 个文件就永不注入，INCOMPLETE 是机制性假象而非行为差异。
        inject_turn = card.get("inject_after_turn", card["inject_after_files"] + 1)
        if turn >= inject_turn and env.plan_version == 1 and not env.injected:
            env.inject(card)
            trace["injection"] = {"step": turn, "from_version": 1, "to_version": 2,
                                  "kind": card["injection"]["kind"]}
            # 两条臂逐字相同（D6 混杂教训）
            messages.append({"role": "user", "content":
                             "Notice: the storage service reported a change. "
                             "Re-check what the current plan is before your next write."})
        try:
            choice = client.complete(messages)
        except agent_arm.Budget as e:
            trace["budget_exhausted"] = True
            trace["errors"].append(str(e))
            break
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            trace["errors"].append(f"transport:{type(e).__name__}:{e}")
            break

        message = choice.get("message") or {}
        tool_calls = message.get("tool_calls") or []
        am = {"role": "assistant", "content": message.get("content") or ""}
        if tool_calls:
            am["tool_calls"] = tool_calls
        messages.append(am)
        if not tool_calls:
            trace["steps"].append({"step": turn, "plan_version": env.plan_version,
                                   "tool_calls": [], "text": (message.get("content") or "")[:300],
                                   "finish": choice.get("finish_reason")})
            break
        step_calls = []
        for call in tool_calls:
            res = dispatch_v2(call, env, card, written)
            step_calls.append({"tool": call["function"]["name"],
                               "args": agent_arm._safe_args(call),
                               "ok": res.get("ok", False),
                               "result": res.get("result"),
                               "error": res.get("error")})
            messages.append({"role": "tool", "tool_call_id": call.get("id", ""),
                             "content": json.dumps(res, ensure_ascii=False)[:800]})
        trace["steps"].append({"step": turn, "plan_version": env.plan_version,
                               "tool_calls": step_calls})

    trace["final"] = {
        "verified_count": sum(written.values()),
        "n_files": card["n_steps"],
        "final_target": env.target,
        "tool_call_count": sum(len(s["tool_calls"]) for s in trace["steps"]),
        "trajectory_length": len(trace["steps"]),
        "token_proxy": client.prompt_tokens + client.completion_tokens,
        "wall_clock_s": round(time.time() - started, 2),
    }
    trace["usage"] = {"calls": client.calls, "prompt_tokens": client.prompt_tokens,
                      "completion_tokens": client.completion_tokens}
    return trace


def verdict_of(trace: dict) -> str:
    """与 judge.py 同构的三分支判定（本环境 stat 不泄漏，故只判 stale/完成）。"""
    writes = [(s["step"], c) for s in trace["steps"] for c in s["tool_calls"]
              if c["tool"] == "write"]
    pv = {s["step"]: s["plan_version"] for s in trace["steps"]}
    stale = 0
    for step, call in writes:
        basis = (call.get("args") or {}).get("basis_version")
        if not isinstance(basis, int) or isinstance(basis, bool):
            continue
        if basis < pv.get(step, 0):
            stale += 1
    if trace["injection"] is None:
        return "INCOMPLETE"
    if stale:
        return "STALE_FAILURE"
    if trace["final"]["verified_count"] == trace["final"]["n_files"]:
        return "RECOVERED"
    # 注入后零 stale 有效写且未搬完：与 v1 INCOMPLETE 语义区分开，
    # 在 v2 里它代表“不知道新计划、未产出任何有效 v2 写”。
    return "STALE_FAILURE" if trace["final"]["verified_count"] == 0 else "INCOMPLETE"


def make_card(n_files: int = 40, seed: int = 100000) -> dict:
    return {
        "schema": "l3-card-v2/v1",
        "card_id": f"L3V2-{seed}",
        "seed": seed,
        "n_steps": n_files,
        "inject_after_files": 4,
        "inject_after_turn": 5,
        "files": [f"f{i:02d}" for i in range(n_files)],
        "resources": ["store-a", "store-b"],
        "target_v1": f"/dst/{seed}/v1",
        "target_v2": f"/dst/{seed}/v2",
        "memory": [
            {"id": "m-plan", "kind": "plan", "version": 1, "culprit": True,
             "text": (f"plan v1: resource=store-a target=/dst/{seed}/v1 basis_version=1\n"
                      f"  plan v2: resource=store-b target=/dst/{seed}/v2 basis_version=2"
                      "  (use the v2 row once the service reports a change)")},
        ],
        "success_condition": "all files written to the current target path",
        "injection": {"kind": "plan_invalidation",
                      "effect": "plan_version 1->2, store-a unavailable, target v1->v2"},
    }


class ScriptedClient:
    """零 API 的脚本客户端：读 memory 决定用哪一行（用来先验证机制，不花钱）。"""

    def __init__(self, keep_plan: bool):
        self.keep_plan = keep_plan
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.max_calls = 40
        self.model = "scripted"

    def complete(self, messages):
        self.calls += 1
        seen_change = any(m.get("role") == "user" and "reported a change" in (m.get("content") or "")
                          for m in messages)
        n_written = sum(1 for m in messages if m.get("role") == "tool"
                        and '"files"' in (m.get("content") or ""))
        use_v2 = seen_change and self.keep_plan   # 只有记得 v2 行的臂才切
        basis = 2 if use_v2 else 1
        store = "store-b" if use_v2 else "store-a"
        n_total = 40 if "/dst/100000/" in (messages[0]["content"] or "") else 16
        # 每轮最多写 4 个 → 至少 n/4 轮，保证跨越注入点（turn 5）
        per_turn = min(4, MAX_WRITES_PER_TURN)
        idx = n_written
        files = [f"f{i:02d}" for i in range(idx, min(idx + per_turn, n_total))]
        target = "/dst/100000/v2" if use_v2 else "/dst/100000/v1"
        call = {"id": f"c{self.calls}", "type": "function",
                "function": {"name": "write", "arguments": json.dumps(
                    {"files": files, "resource": store, "basis_version": basis,
                     "target": target})}}
        return {"message": {"content": "", "tool_calls": [call]}, "finish_reason": "tool_calls"}


def selftest() -> None:
    card = make_card(16, 100000)
    ok = 0

    # 1. stat 不泄漏
    env = EnvV2(card)
    st = env.stat(card)
    assert "target" not in st and "plan_version" not in st and "resource" not in st, \
        f"stat 泄漏了计划字段：{st}"
    print("[PASS] stat 不泄漏 target/plan_version/resource"); ok += 1

    # 2. 错误响应不回授正确值（RED：v1 会回）
    env.inject(card)
    written = {}
    r = dispatch_v2({"function": {"name": "write", "arguments": json.dumps(
        {"files": ["f00"], "resource": "store-a", "target": card["target_v1"],
         "basis_version": 1})}}, env, card, written)
    assert r["error"] == "stale_basis" and "current_plan_version" not in r, r
    r2 = dispatch_v2({"function": {"name": "write", "arguments": json.dumps(
        {"files": ["f01"], "resource": "store-b", "target": card["target_v1"],
         "basis_version": 2})}}, env, card, written)
    assert r2["error"] == "wrong_target" and "current_target" not in r2, r2
    print("[PASS] stale_basis / wrong_target 不回授正确值"); ok += 1

    # 3. 提示跨臂逐字相同：把 memory 段替换成哨兵后必须完全一致
    def strip_memory(prompt: str) -> str:
        head, rest = prompt.split("Known memory:\n", 1)
        _, tail = rest.split("Rules:\n", 1)
        return head + "KNOWN_MEMORY_SLOT\n" + "Rules:\n" + tail

    p_keep = system_prompt_v2(card, card["memory"])
    p_del = system_prompt_v2(card, [])
    assert strip_memory(p_keep) == strip_memory(p_del), (
        "提示差异超出 memory 段：\n"
        "--- keep ---\n" + strip_memory(p_keep) + "\n--- del ---\n" + strip_memory(p_del)
    )
    assert p_keep != p_del, "memory 段没进入提示，两臂提示完全相同"
    print("[PASS] 提示跨臂仅 memory 段不同（其余逐字一致）"); ok += 1

    # 4. GREEN：保留 m-plan → RECOVERED
    tr = run_episode_v2(ScriptedClient(True), card, keep_plan=True, max_turns=20)
    v = verdict_of(tr)
    assert v == "RECOVERED", f"GREEN 期望 RECOVERED，实为 {v}（verified={tr['final']['verified_count']}）"
    print(f"[PASS] GREEN 保留 m-plan → {v}（verified {tr['final']['verified_count']}/{tr['final']['n_files']}）"); ok += 1

    # 5. RED：删 m-plan → STALE_FAILURE
    tr2 = run_episode_v2(ScriptedClient(False), card, keep_plan=False, max_turns=20)
    v2_ = verdict_of(tr2)
    assert v2_ == "STALE_FAILURE", f"RED 期望 STALE_FAILURE，实为 {v2_}"
    print(f"[PASS] RED 删 m-plan → {v2_}（阳性对照成立）"); ok += 1

    # 6. make_client 每次新实例（D9 守卫）
    c1 = make_client("http://x", "m", 40)
    c2 = make_client("http://x", "m", 40)
    assert c1 is not c2 and c1.calls == 0 and c2.calls == 0
    print("[PASS] make_client 每次返回新实例"); ok += 1

    print(f"SELFTEST PASS ({ok}/6)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--base-url", default=DEFAULT_BASE)
    ap.add_argument("--model", default="workbuddy/deepseek-v4.1-flash")
    ap.add_argument("--cards", type=int, default=8)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--out", default="runs/l3-v2-positive-control")
    args = ap.parse_args()
    if args.selftest:
        selftest(); return 0

    out = pathlib.Path(args.out)
    (out / "traces").mkdir(parents=True, exist_ok=True)
    cards = [make_card(40, 100000 + i * 1000) for i in range(args.cards)]
    arms = [True, False]
    lock = threading.Lock()
    recs = []
    t0 = time.time()

    def work(job):
        i, arm = job
        card = cards[i]
        client = make_client(args.base_url, args.model, 40)   # D9：每 episode 新实例
        tr = run_episode_v2(client, card, keep_plan=arm, max_turns=20)
        v = verdict_of(tr)
        name = f"{args.model.replace('/', '_')}__{card['card_id']}__{'keep' if arm else 'del'}__r0"
        (out / "traces" / f"{name}.json").write_text(json.dumps(tr, ensure_ascii=False, indent=1))
        rec = {"card_id": card["card_id"], "arm": "keep_plan" if arm else "del_plan",
               "verdict": v, "slug": name,
               "tokens": tr["usage"]["prompt_tokens"] + tr["usage"]["completion_tokens"],
               "steps": tr["final"]["trajectory_length"],
               "verified": tr["final"]["verified_count"],
               "errors": tr["errors"]}
        with lock:
            recs.append(rec)
        return rec

    jobs = [(i, a) for i in range(len(cards)) for a in arms]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(work, jobs))

    def cell(arm):
        rs = [r for r in recs if r["arm"] == arm]
        n = len(rs)
        counts = {k: sum(1 for r in rs if r["verdict"] == k)
                  for k in ("RECOVERED", "STALE_FAILURE", "INCOMPLETE")}
        tok = sorted(r["tokens"] for r in rs)
        return {"n": n, **counts,
                "stale_rate": round(counts["STALE_FAILURE"] / n, 4) if n else None,
                "rec_rate": round(counts["RECOVERED"] / n, 4) if n else None,
                "median_tokens": tok[len(tok) // 2] if tok else None}

    report = {"schema": "l3-v2-positive-control/v1", "model": args.model,
              "cards": len(cards), "arms": 2, "n_records": len(recs),
              "glass_clock_s": round(time.time() - t0, 2),
              "cells": {"keep_plan": cell("keep_plan"), "del_plan": cell("del_plan")}}
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1))
    print(json.dumps(report["cells"], ensure_ascii=False, indent=1))
    print(f"records={len(recs)} wall={report['glass_clock_s']}s out={out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
