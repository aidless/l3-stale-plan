#!/usr/bin/env python3
"""v3 real-model smoke: 2 cards x 2 arms. Alias of the v2 runner's ClientV2.

Small, bounded, local (API calls only via the Magpie gateway). Purpose: show the
v3 version-only carrier separates "cannot address the service" (v2 D16) from
"followed an outdated plan version" before any v3 preregistration is approved.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import v2_runner_sc as v2
import v3_runner as v3


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="openrouter/minimax/minimax-m3.1-flash")
    ap.add_argument("--base-url", default="http://127.0.0.1:3425/v1")
    ap.add_argument("--cards", type=int, default=2)
    ap.add_argument("--out", default="runs/l3-v3-smoke")
    args = ap.parse_args()

    out = pathlib.Path(args.out)
    (out / "traces").mkdir(parents=True, exist_ok=True)
    rows = []
    for i in range(args.cards):
        card = v3.make_card(seed=200000 + i * 1000)
        for arm, keep in (("keep", True), ("del", False)):
            client = v2.make_client(args.base_url, args.model)  # 每 episode 新实例（D9）
            tr = v3.run_episode(client, card, keep_carrier=keep)
            (out / "traces" / f"{card['card_id']}__{arm}.json").write_text(
                json.dumps(tr, ensure_ascii=False, indent=1), encoding="utf-8")
            ok = v3.count_ok_writes(tr)
            inj = tr["injection"]["step"] if tr["injection"] else None
            print(f"{card['card_id']} {arm:4s} {tr['verdict']:24s} "
                  f"ok_writes={ok:2d} inj_step={inj} verified={tr['final']['verified_count']}/40")
            rows.append({"card_id": card["card_id"], "arm": arm,
                         "verdict": tr["verdict"], "ok_writes": ok,
                         "ok_before_injection": sum(
                             1 for s in tr["steps"] if inj is not None and s["step"] < inj
                             for c in s["tool_calls"] if c["tool"] == "write" and c["ok"]),
                         "verified": tr["final"]["verified_count"]})
    (out / "rows.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
