#!/usr/bin/env python3
"""追加 D9：Client 跨 episode 复用 bug（并更正 D8.3 的"并发烧盘"归因）。"""
import hashlib
import os
from pathlib import Path

DOC = Path(__file__).resolve().parent.parent / "DEVIATION_L3.md"

BLOCK = """
## D9（2026-11-10）：Client 跨 episode 复用 —— 94.7% "折损"的真因，并更正 D8.3

### D9.1 病灶

`l3_pilot/factorial_3x2.py` 的 `client_for(model)` 把 `agent_arm.Client` 缓存在
`threading.local()` 的 pool 里，**整个进程复用同一个实例**。
而 `agent_arm.Client`（冻结文件 `agent_arm.py:86-113`）把 `calls / prompt_tokens /
completion_tokens` 挂在实例上、**没有 reset()**，且 `complete()` 第一句就是
`if self.calls >= self.max_calls: raise Budget(...)`。

后果：**每个 worker 只有第 1 个 episode 能真跑，第 2 个起开口即 raise Budget**，
落盘表现为 `verdict=INCOMPLETE`、`n_steps_taken=0`、`errors=["model call budget exhausted after N calls"]`，
且耗时约 0 秒。

对照：顺序版 `formal_runner.py:653` 是 **每个 episode new 一个 Client**，所以 Run A 300 条没这个问题；
`formal_runner_mt.py:95` 虽然也按 thread 缓存，但它一进程只跑自己那一份、且同样应当在 episode 边界重建。
→ 这是我的编排层 bug，不是模型、不是限流、不是上下文长度。**冻结层 (agent_arm.py) 一字未改。**

### D9.2 更正 D8.3 的归因

D8.3 把第一次 2880 的 94.7% 折损记成"24 并发烧盘"。真实配比是：
- **主因（D9.1）**：240 卡 × 6 格 = 1440 job/模型，每个 worker 只成功第 1 个 → 折损 ≈ 1 − 16/2880 ≈ 99%；
- **次因**：高并发下确实多出一批 `transport` / 真实 429，但量级远小于主因。

"D8.3 的教训（吞吐不是健康证据）"仍然成立且更硬：那次 25 分钟跑完 2880 条，
**每条约 0.5 秒** —— 一秒内不可能真跑完一次 40 文件的迁移。**看到异常快的吞吐，第一反应应是"它在空转"，不是"它很快"。**

### D9.3 修法 + 双向守卫

- 新增模块级 `make_client(base_url, model, max_calls)`，一处集中"每 episode 新实例"；
  `client_for()` 改为调它（注释里写清原因与实测代价）。
- `--selftest` 新增守卫：两次 `make_client` 必须是不同实例、计数各自为 0、改 `c1.calls` 不影响 `c2.calls`。
- **RED 实测**：把 `make_client` 改成返回全局缓存实例 →
  `AssertionError: make_client 必须每次返回新实例`；恢复后 `SELFTEST OK`。
- 修后真实运行（8 分片 × 2 worker，240 卡 × 6 格 × 2 模型 = 2880）：
  **5 分钟 58 条，INCOMPLETE 5 条（8.6%）**，STALE 30 / REC 23 → 折损回到 10% 以内，ETA ≈ 4 小时。

### D9.4 被这次 bug 污染的产物（已删，只留计数）

`runs/l3-fact-240x6x2-shard0..7`（第一/二/三轮共 2880+1634+1634 条，其中 94.7%/75%/99% 是 steps=0 空转）、
`runs/l3-fact-ds-120`、`runs/l3-fact-glm-120` 全部删除，只在本节保留计数。
保留的只有真实跑过步数的记录，`purge_shard_state.py` 的判据（0 步 + 预算耗尽 / episode_exception）与此一致。
"""


def main() -> int:
    before = DOC.read_bytes()
    bh = hashlib.sha256(before).hexdigest()
    assert b"## D9" not in before, "D9 已存在"
    payload = BLOCK.encode("utf-8")
    fd = os.open(DOC, os.O_WRONLY | os.O_APPEND)
    try:
        os.write(fd, payload)
    finally:
        os.close(fd)
    after = DOC.read_bytes()
    assert after.startswith(before), "前缀不一致"
    assert hashlib.sha256(after[: len(before)]).hexdigest() == bh, "前缀哈希不一致"
    print(f"OK: D9 appended {len(payload)}B; {len(before)} -> {len(after)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
