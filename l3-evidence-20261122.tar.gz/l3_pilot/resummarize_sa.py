#!/usr/bin/env python3
"""从 S_a judgements 现算 report.json（runner 被 timeout 杀在写报告前的补救）。

新尺先对表纪律：selftest 先在 40 卡批重建 report，必须与已登记 report.json
逐字段相等，才允许对 --apply 的目标 run 落盘。
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import v2_runner_sc as v2  # noqa: E402
import sa_runner as sa  # noqa: E402


def rebuild(run_dir: pathlib.Path, model: str, cards: int) -> dict:
    js = [json.loads(p.read_text(encoding="utf-8"))
          for p in sorted((run_dir / "judgements").glob("*.json"))]
    recs = [{k: j[k] for k in ("card_id", "arm", "verdict", "slug", "tokens",
                               "verified", "steps", "errors", "transport_loss")}
            for j in js]
    summary = v2.summarize(recs)
    return {
        "schema": "l3-sa-report/v1", "model": model, "cards": cards,
        "arms": ["keep", "del"], "carrier": sa.CARRIER,
        "retrieval_carrier": True, "resource_names_constant": True,
        "max_tokens": sa.MAX_TOKENS, "inject_turn": sa.INJECT_TURN,
        "wall_clock_s": 0,  # 无法从载体还原，显式 0 而非伪造
        "writes": sa.writes_block(js), **summary,
        "resummarized_from_carriers": True,
        "carrier_judgements": len(js),
    }


def diff(a: dict, b: dict, prefix: str = "") -> list[str]:
    out = []
    for k in sorted(set(a) | set(b)):
        key = f"{prefix}.{k}" if prefix else k
        # 顶层重建元数据不参与对表（registered report 没有这些字段）
        if not prefix and k in ("wall_clock_s", "resummarized_from_carriers",
                                "carrier_judgements"):
            continue
        av, bv = a.get(k), b.get(k)
        if isinstance(av, dict) and isinstance(bv, dict):
            out += diff(av, bv, key)
        elif av != bv:
            out.append(f"{key}: expect={bv} got={av}")
    return out


def selftest() -> None:
    root = pathlib.Path(__file__).resolve().parent
    d40 = root / "runs" / "l3-sa-sc-40"
    registered = json.loads((d40 / "report.json").read_text(encoding="utf-8"))
    rebuilt = rebuild(d40, registered["model"], registered["cards"])
    bad = diff(rebuilt, registered)
    assert not bad, ("40 卡对表失败（新尺读错底物）", bad)
    print(f"[PASS] GREEN 40 卡 report 逐字段对表一致（跳过 wall_clock_s）")
    wrong = dict(registered)
    wrong["paired"] = dict(registered["paired"], diff_pp=99.0)
    assert diff(rebuilt, wrong), "RED 未触发：篡改 diff_pp 未被抓出"
    print("[PASS] RED 篡改字段必被抓出")
    print("SELFTEST PASS (2/2)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--run-dir", default=None)
    ap.add_argument("--model", default="workbuddy/deepseek-v4.1-flash")
    ap.add_argument("--cards", type=int, default=200)
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        selftest()
        return 0
    assert a.run_dir, "--run-dir is required unless --selftest"
    rd = pathlib.Path(a.run_dir)
    rep = rebuild(rd, a.model, a.cards)
    out = rd / "report.json"
    if a.apply:
        if out.exists():
            bak = out.with_name(f"report.json.bak-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}")
            bak.write_bytes(out.read_bytes())
            print(f"backup -> {bak}")
        out.write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"wrote {out}")
    print(json.dumps({"n_records": rep["n_records"],
                      "paired": rep["paired"],
                      "writes": rep["writes"],
                      "carrier_judgements": rep["carrier_judgements"]},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
