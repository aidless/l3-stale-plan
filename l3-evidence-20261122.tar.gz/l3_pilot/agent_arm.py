#!/usr/bin/env python3
"""Real-model arm for the L3 pilot.

The model can only observe state via `stat` and act via `write` / `verify`.
Environment transitions, success and staleness are decided by the state
machine, never by the model's own claims.

Usage:
  python3 agent_arm.py --models opencode-go/deepseek-v4.1-flash \
      --policies reactive --repeats 1 --out runs/l3-agent-v1 --smoke
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from cards_agent import CARD_SPECS, build_card
from engine import Env
from judge import judge

ROOT = Path(__file__).resolve().parent
DEFAULT_BASE = os.environ.get("MAGPIE_BASE", "http://127.0.0.1:3425/v1")

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "stat",
            "description": (
                "Inspect the current environment. Returns plan_version, target path "
                "and the currently usable resource."
            ),
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write",
            "description": (
                "Write one or more files to a resource at a target path. Give either "
                "`file` or `files`."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "file": {"type": "string", "description": "file name to write"},
                    "files": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "file names to write in this call",
                    },
                    "resource": {"type": "string", "description": "resource name"},
                    "target": {"type": "string", "description": "target directory path"},
                    "basis_version": {"type": "integer", "description": "the plan_version your write is based on"},
                },
                "required": ["resource", "target", "basis_version"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "verify",
            "description": "Verify that a previously written file exists at the current target.",
            "parameters": {
                "type": "object",
                "properties": {"file": {"type": "string"}},
                "required": ["file"],
            },
        },
    },
]


class Budget(Exception):
    pass


class Client:
    def __init__(self, base_url: str, model: str, max_calls: int, timeout: float = 120.0):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.max_calls = max_calls
        self.timeout = timeout
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0

    def complete(self, messages: list[dict]) -> dict:
        if self.calls >= self.max_calls:
            raise Budget(f"model call budget exhausted after {self.calls} calls")
        payload = {
            "model": self.model,
            "messages": messages,
            "tools": TOOLS,
            "tool_choice": "auto",
            "max_tokens": 400,
            "temperature": 0,
        }
        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        self.calls += 1
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            body = json.loads(response.read().decode("utf-8"))
        usage = body.get("usage") or {}
        self.prompt_tokens += usage.get("prompt_tokens") or 0
        self.completion_tokens += usage.get("completion_tokens") or 0
        return body["choices"][0]


def system_prompt(card: dict, policy: str, stat_visible: bool = True) -> str:
    memory = [dict(entry) for entry in card["memory"]]
    if policy == "memory_delete":
        memory = [entry for entry in memory if entry["id"] != "m-plan"]
    memory_lines = "\n".join(f"- [{entry['kind']}] {entry['text']}" for entry in memory) or "- (no stored plan)"
    rule_line = (
        "- Environment changes can happen at any time; only `stat` tells you the truth.\n"
        if stat_visible
        else "- You may use `stat`, but the stored plan is the default authority.\n"
    )
    return "".join(
        [
            "You are an agent migrating files on a remote storage service.\n",
            f"Goal: {card['success_condition']}.\n",
            f"There are {card['n_steps']} files: {card['files'][0]} .. {card['files'][-1]}.\n",
            "Known memory:\n",
            f"{memory_lines}\n",
            "Rules:\n",
            rule_line,
            "- `write` needs the plan_version your write is based on (an integer). ",
            "A write based on an outdated plan_version will be rejected.\n",
            "- A turn may contain at most 8 `write` calls; you cannot finish everything in one turn.\n",
            "- If the service changes, your previous basis becomes invalid; call `stat` again.\n",
            "- Use `verify` only for files you already wrote.\n",
            "Reply with tool calls only; no prose.",
        ]
    )


SOFT_INJECT_AFTER = 2
MAX_WRITES_PER_TURN = 8


def dispatch(call: dict, env: Env, card: dict, written: dict[str, bool]) -> dict:
    function = call.get("function") or {}
    name = function.get("name")
    raw_args = function.get("arguments") or "{}"
    try:
        args = json.loads(raw_args) if isinstance(raw_args, str) else dict(raw_args)
    except json.JSONDecodeError:
        return {
            "ok": False,
            "error": "arguments_not_json",
            "hint": "resend this call with a valid JSON object of arguments",
            "raw": str(raw_args)[:200],
        }

    if name == "stat":
        return {"ok": True, "result": env.stat(card)}

    if name == "write":
        raw_files = args.get("files")
        if raw_files is None and args.get("file") is not None:
            raw_files = [args.get("file")]
        if not isinstance(raw_files, list) or not raw_files:
            raw_files = [args.get("file")]
        file_names = [normalize_file(item, card) for item in raw_files]
        resource = str(args.get("resource", ""))
        target = str(args.get("target", ""))
        basis = coerce_version(args.get("basis_version"))
        if any(item is None for item in file_names):
            return {
                "ok": False,
                "error": "unknown_file",
                "hint": f"use one of: {', '.join(card['files'][:5])} ... {card['files'][-1]}",
            }
        if basis is None:
            return {"ok": False, "error": "basis_version_missing", "note": "pass an integer plan_version"}
        if basis < env.plan_version:
            return {"ok": False, "error": "stale_basis", "current_plan_version": env.plan_version}
        if basis > env.plan_version:
            return {"ok": False, "error": "future_basis", "current_plan_version": env.plan_version}
        if resource not in env.available or not env.available[resource]:
            return {"ok": False, "error": "resource_unavailable"}
        if target != env.target:
            return {"ok": False, "error": "wrong_target", "current_target": env.target}
        accepted, duplicate = [], []
        for file_name in file_names:
            if written.get(file_name):
                duplicate.append(file_name)
            elif len(accepted) >= MAX_WRITES_PER_TURN:
                return {
                    "ok": False,
                    "error": "too_many_writes_in_one_turn",
                    "hint": f"at most {MAX_WRITES_PER_TURN} writes per turn; write the rest next turn",
                    "accepted_before_refusal": accepted,
                }
            else:
                written[file_name] = True
                accepted.append(file_name)
        if not accepted:
            return {"ok": False, "error": "already_written", "files": duplicate}
        return {
            "ok": True,
            "result": {"files": accepted, "target": target, "duplicates_refused": duplicate},
        }

    if name == "verify":
        file_name = str(args.get("file", ""))
        if written.get(file_name):
            return {"ok": True, "result": {"file": file_name, "verified": True}}
        return {"ok": False, "error": "not_written"}

    return {"ok": False, "error": "unknown_tool"}


def coerce_version(value) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        cleaned = value.strip().lower().removeprefix("v").strip()
        if cleaned.isdigit():
            return int(cleaned)
    return None


def normalize_file(value, card: dict) -> str | None:
    if not isinstance(value, str):
        return None
    candidate = value.strip()
    if candidate in card["files"]:
        return candidate
    lowered = candidate.lower()
    for file_name in card["files"]:
        if file_name.lower() == lowered:
            return file_name
    return None


def run_episode(
    client: Client,
    card: dict,
    policy: str,
    repeat: int,
    max_turns: int,
    inject_after_turn: int | None = None,
) -> dict:
    env = Env(card)
    inject_after_files = card.get("inject_after_files")
    if inject_after_turn is not None:
        inject_turn: int | None = inject_after_turn
    elif inject_after_files is None:
        inject_turn = SOFT_INJECT_AFTER
    else:
        inject_turn = None
    written: dict[str, bool] = {}
    messages = [
        {"role": "system", "content": system_prompt(card, policy, stat_visible=(policy != "stale"))},
        {
            "role": "user",
            "content": f"Start migrating. Begin with {card['files'][0]}.",
        },
    ]
    trace = {
        "schema": "l3-trace/v1",
        "card_id": card["card_id"],
        "card_sha256": card["card_sha256"],
        "policy": policy,
        "repeat": repeat,
        "source": "real_model",
        "no_llm_calls": False,
        "model": client.model,
        "memory_ids": [
            entry["id"]
            for entry in card["memory"]
            if not (policy == "memory_delete" and entry["id"] == "m-plan")
        ],
        "injection": None,
        "steps": [],
        "errors": [],
        "budget_exhausted": False,
    }
    started = time.time()

    for turn in range(max_turns):
        if sum(written.values()) >= card["n_steps"]:
            break
        triggered = (
            (inject_turn is not None and turn >= inject_turn)
            or (inject_after_files is not None and sum(written.values()) >= inject_after_files)
        )
        if triggered and env.plan_version == 1 and not env.injected:
            env.inject(card)
            trace["injection"] = {
                "step": turn,
                "from_version": 1,
                "to_version": 2,
                "kind": card["injection"]["kind"],
            }
            if policy == "stale":
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            "Continue. The stored plan is still expected to be valid; "
                            "re-check only if a write is rejected."
                        ),
                    }
                )
            else:
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            "Notice: the storage service reported a change. Re-check the "
                            "environment with `stat` before your next write."
                        ),
                    }
                )

        try:
            choice = client.complete(messages)
        except Budget as error:
            trace["budget_exhausted"] = True
            trace["errors"].append(str(error))
            break
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            trace["errors"].append(f"transport:{type(error).__name__}:{error}")
            break

        message = choice.get("message") or {}
        tool_calls = message.get("tool_calls") or []
        assistant_message = {"role": "assistant", "content": message.get("content") or ""}
        if tool_calls:
            assistant_message["tool_calls"] = tool_calls
        messages.append(assistant_message)

        if not tool_calls:
            trace["steps"].append(
                {"step": turn, "plan_version": env.plan_version, "tool_calls": [], "text": (message.get("content") or "")[:300]}
            )
            break

        step_calls = []
        for call in tool_calls:
            result = dispatch(call, env, card, written)
            step_calls.append(
                {
                    "tool": call["function"]["name"],
                    "args": _safe_args(call),
                    "ok": result.get("ok", False),
                    "result": result.get("result"),
                    "error": result.get("error"),
                }
            )
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": call.get("id", ""),
                    "content": json.dumps(result, ensure_ascii=False)[:800],
                }
            )
        trace["steps"].append({"step": turn, "plan_version": env.plan_version, "tool_calls": step_calls})

    trace["final"] = {
        "migrated_count": sum(written.values()),
        "verified_count": sum(written.values()),
        "n_files": card["n_steps"],
        "final_target": env.target,
        "tool_call_count": sum(len(step["tool_calls"]) for step in trace["steps"]),
        "trajectory_length": len(trace["steps"]),
        "token_proxy": client.prompt_tokens + client.completion_tokens,
        "wall_clock_s": round(time.time() - started, 2),
    }
    trace["usage"] = {
        "calls": client.calls,
        "prompt_tokens": client.prompt_tokens,
        "completion_tokens": client.completion_tokens,
    }
    return trace


def _safe_args(call: dict) -> dict:
    raw = call["function"].get("arguments") or "{}"
    try:
        parsed = json.loads(raw) if isinstance(raw, str) else dict(raw)
    except json.JSONDecodeError:
        return {"_raw": str(raw)[:200]}
    return parsed if isinstance(parsed, dict) else {"_raw": str(parsed)[:200]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="+", required=True)
    parser.add_argument("--policies", nargs="+", default=["reactive", "stale", "memory_delete"])
    parser.add_argument("--cards", nargs="+", default=[spec["card_id"] for spec in CARD_SPECS])
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--out", type=Path, default=ROOT / "runs" / "l3-agent-v1")
    parser.add_argument("--base-url", default=DEFAULT_BASE)
    parser.add_argument("--max-calls-per-episode", type=int, default=40)
    parser.add_argument("--max-turns", type=int, default=25)
    parser.add_argument("--smoke", action="store_true", help="abort after the first episode")
    parser.add_argument("--inject-after-turn", type=int, default=None)
    args = parser.parse_args()

    out = args.out.resolve()
    traces_dir = out / "traces"
    judgements_dir = out / "judgements"
    traces_dir.mkdir(parents=True, exist_ok=True)
    judgements_dir.mkdir(parents=True, exist_ok=True)

    spec_by_id = {spec["card_id"]: spec for spec in CARD_SPECS}
    records = []
    stop = False
    for model in args.models:
        for card_id in args.cards:
            card = build_card(spec_by_id[card_id])
            for policy in args.policies:
                for repeat in range(args.repeats):
                    client = Client(args.base_url, model, args.max_calls_per_episode)
                    trace = run_episode(
                        client, card, policy, repeat, args.max_turns, args.inject_after_turn
                    )
                    judgement = judge(trace)
                    slug = f"{model.replace('/', '_')}__{card_id}__{policy}__r{repeat}"
                    trace_path = traces_dir / f"{slug}.json"
                    trace_path.write_text(json.dumps(trace, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                    judgement["model"] = model
                    judgement_path = judgements_dir / f"{slug}.json"
                    judgement_path.write_text(
                        json.dumps(judgement, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
                    )
                    records.append(
                        {
                            "model": model,
                            "card_id": card_id,
                            "policy": policy,
                            "repeat": repeat,
                            "verdict": judgement["verdict"],
                            "metrics": judgement["metrics"],
                            "usage": trace["usage"],
                            "budget_exhausted": trace["budget_exhausted"],
                            "errors": trace["errors"],
                            "trace": str(trace_path.relative_to(out)),
                            "judgement": str(judgement_path.relative_to(out)),
                        }
                    )
                    print(
                        f"{slug}: {judgement['verdict']} calls={trace['usage']['calls']}"
                        f" tool_calls={judgement['metrics']['tool_call_count']}",
                        flush=True,
                    )
                    if args.smoke:
                        stop = True
                        break
                if stop:
                    break
            if stop:
                break
        if stop:
            break

    report = {
        "schema": "l3-agent-report/v1",
        "run_id": out.name,
        "source": "real_model",
        "base_url": args.base_url,
        "models": args.models,
        "policies": args.policies,
        "n_records": len(records),
        "smoke": args.smoke,
        "what_this_proves": (
            "a real model can operate the L3 tool protocol end to end and its traces are judged "
            "by the deterministic staleness ruler"
        ),
        "what_this_does_not_prove": (
            "no H3a/H3b/H3c claim: sample size is a pilot, policies are scripted conditions, "
            "and no power analysis has been frozen"
        ),
        "records": records,
    }
    report_path = out / "report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {len(records)} records -> {report_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
