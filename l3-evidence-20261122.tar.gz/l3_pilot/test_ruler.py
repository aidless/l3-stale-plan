#!/usr/bin/env python3
"""Two-direction mutation + attribution control + determinism checks.

Exit 0 only if every guard has teeth in both directions.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

from cards import CARD_SPECS, build_card
from engine import run_card
from judge import VERDICT_INCOMPLETE, VERDICT_RECOVERED, VERDICT_STALE, judge

CHECKED: list[tuple[str, bool]] = []


def record(name: str, passed: bool) -> None:
    CHECKED.append((name, passed))


def card(seed_offset: int = 0) -> dict:
    spec = dict(CARD_SPECS[0])
    spec["seed"] += seed_offset
    return build_card(spec)


def check_determinism() -> None:
    base = card()
    traces = [run_card(base, "stale", repeat) for repeat in range(4)]
    verdicts = [judge(trace)["verdict"] for trace in traces]
    record("determinism: same card -> same verdict", len(set(verdicts)) == 1)
    normalized = []
    for trace in traces:
        copy_trace = copy.deepcopy(trace)
        copy_trace.pop("repeat")
        normalized.append(json.dumps(copy_trace, sort_keys=True, ensure_ascii=False))
    record("determinism: same card -> identical trace except repeat field", len(set(normalized)) == 1)


def check_mutation_1() -> None:
    """M1: stale trace says STALE; repairing the stale basis must flip it."""
    base = card()
    trace = run_card(base, "stale")
    original = judge(trace)
    mutated = copy.deepcopy(trace)
    for step in mutated["steps"]:
        if step["step"] < mutated["injection"]["step"]:
            continue
        for call in step["tool_calls"]:
            if call["tool"] == "write":
                call["args"]["basis_version"] = 2
                call["ok"] = True
                call.pop("reason", None)
        if all(call["ok"] for call in step["tool_calls"] if call["tool"] == "write"):
            step["tool_calls"].append({"tool": "verify", "args": {}, "ok": True})
    mutated["final"]["verified_count"] = mutated["final"]["n_files"]
    repaired = judge(mutated)
    record("M1 negative: stale trace -> STALE_FAILURE", original["verdict"] == VERDICT_STALE)
    record("M1 positive: repaired basis -> not STALE_FAILURE", repaired["verdict"] != VERDICT_STALE)


def check_mutation_2() -> None:
    """M2 recovered trace says RECOVERED; injecting one stale write must flip it."""
    base = card()
    trace = run_card(base, "reactive")
    original = judge(trace)
    mutated = copy.deepcopy(trace)
    inject_step = mutated["injection"]["step"]
    for step in mutated["steps"]:
        if step["step"] != inject_step:
            continue
        for call in step["tool_calls"]:
            if call["tool"] == "write":
                call["args"]["basis_version"] = 1
    verdict = judge(mutated)
    record("M2 negative: recovered trace -> RECOVERED", original["verdict"] == VERDICT_RECOVERED)
    record("M2 positive: one stale write -> STALE_FAILURE", verdict["verdict"] == VERDICT_STALE)


def check_mutation_3() -> None:
    """M3: no injection event must be INCOMPLETE, not silently PASS."""
    base = card()
    trace = run_card(base, "reactive")
    mutated = copy.deepcopy(trace)
    mutated["injection"] = None
    verdict = judge(mutated)
    record("M3: missing injection -> INCOMPLETE", verdict["verdict"] == VERDICT_INCOMPLETE)


def check_attribution_control() -> None:
    """Random removal is not equivalent to removing the culprit plan."""
    base = card()
    stale = judge(run_card(base, "stale"))["verdict"]
    delete_culprit = judge(run_card(base, "memory_delete"))["verdict"]
    random_removal = copy.deepcopy(base)
    random_removal["memory"] = [entry for entry in base["memory"] if entry["id"] != "m-quota"]
    random_verdict = judge(run_card(random_removal, "stale"))["verdict"]
    record(
        "attribution: culprit removal differs from random removal",
        stale == VERDICT_STALE
        and delete_culprit != VERDICT_STALE
        and random_verdict == VERDICT_STALE,
    )


def check_card_isolation() -> None:
    base = card()
    other = card(seed_offset=7)
    record("card isolation: different seed -> different sha256", base["card_sha256"] != other["card_sha256"])
    record(
        "card isolation: different seed -> different env state",
        base["target_v1"] != other["target_v1"] or base["inject_step"] != other["inject_step"],
    )


def main() -> int:
    check_determinism()
    check_mutation_1()
    check_mutation_2()
    check_mutation_3()
    check_attribution_control()
    check_card_isolation()
    for name, passed in CHECKED:
        print(f"{'PASS' if passed else 'FAIL'}  {name}")
    failed = [name for name, passed in CHECKED if not passed]
    print(f"\n{len(CHECKED) - len(failed)}/{len(CHECKED)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
