#!/usr/bin/env python3
"""Reproducible power / MDE arithmetic for L3 paired-proportion endpoints.

No experiment is run here. Every number in PREREG.md that comes from this
script is recomputed by `--check`.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from scipy.stats import norm

ROOT = Path(__file__).resolve().parent
PREREG = ROOT.parent / "PREREG_L3.md"

ALPHA = 0.05
POWER = 0.80
Z_ALPHA = norm.ppf(1 - ALPHA / 2)
Z_POWER = norm.ppf(POWER)
TWO_SIDED = (Z_ALPHA + Z_POWER) ** 2

ARM_CONFIG = {
    "h3b": {
        "description": "paired D (memory_delete) vs B (full context), primary endpoint stale_failure_rate",
        "p_baseline": 0.40,
        "delta": 0.15,
        "discordance": 0.40,
        "n_cards": 240,
        "n_seeds": 3,
    },
    "h3a": {
        "description": "paired culprit-removal vs random-removal attribution, exact binomial",
        "p_baseline": 0.50,
        "delta": 0.20,
        "n_tasks": 40,
        "two_replays": 2,
        "alpha": 0.05,
    },
    "h3c": {
        "description": "Spearman rank correlation between accuracy and cost-per-success orderings",
        "null_rho": 0.0,
        "target_rho": 0.5,
        "n_methods": 8,
        "alpha": 0.05,
    },
}


def required_n(delta: float, discordance: float) -> int:
    """Number of paired units for a two-sided McNemar-style proportion test."""
    if not 0 < discordance <= 1:
        raise ValueError("discordance must be in (0, 1]")
    if delta <= 0:
        raise ValueError("delta must be positive")
    value = TWO_SIDED * discordance / (delta * delta)
    return int(value) + (1 if value % 1 else 0)


def mde(n: int, discordance: float) -> float:
    return (Z_ALPHA + Z_POWER) * (discordance / n) ** 0.5


def two_sided_binomial_p(successes: int, trials: int, p: float) -> float:
    from scipy.stats import binomtest

    return float(binomtest(successes, trials, p, alternative="two-sided").pvalue)


def fisher_z_power(n: int, rho: float, alpha: float = 0.05) -> float:
    if n < 4:
        return 0.0
    z_rho = 0.5 * __import__("math").log((1 + rho) / (1 - rho))
    critical = norm.ppf(1 - alpha / 2)
    lam = z_rho * ((n - 3) ** 0.5)
    return float(norm.cdf(lam - critical) + norm.cdf(-lam - critical))


def compute() -> dict:
    h3b = ARM_CONFIG["h3b"]
    n_required = required_n(h3b["delta"], h3b["discordance"])
    n_effective = h3b["n_cards"] * h3b["n_seeds"]
    h3a = ARM_CONFIG["h3a"]
    h3a_p = two_sided_binomial_p(
        successes=round(h3a["n_tasks"] * (h3a["p_baseline"] + h3a["delta"])),
        trials=h3a["n_tasks"],
        p=h3a["p_baseline"],
    )
    h3c = ARM_CONFIG["h3c"]
    return {
        "schema": "l3-power/v1",
        "alpha": ALPHA,
        "power_target": POWER,
        "z_alpha": float(Z_ALPHA),
        "z_power": float(Z_POWER),
        "two_sided_factor": float(TWO_SIDED),
        "arm_config": ARM_CONFIG,
        "h3b": {
            "n_required_exact": TWO_SIDED * h3b["discordance"] / (h3b["delta"] ** 2),
            "n_required_ceiling": n_required,
            "n_effective": n_effective,
            "mde": mde(n_effective, h3b["discordance"]),
            "adequate": n_effective >= n_required,
        },
        "h3a": {
            "binomial_p_at_target": h3a_p,
            "significant_at_0_05": h3a_p < 0.05,
            "note": "descriptive only; H3a is registered as a feasibility estimate, not a confirmatory test",
        },
        "h3c": {
            "spearman_power_at_target": fisher_z_power(h3c["n_methods"], h3c["target_rho"]),
            "note": "descriptive only; n_methods is too small for a confirmatory rank-correlation test",
        },
        "correction_note": (
            "Earlier hand estimate n~140 was wrong: the correct paired-proportion formula "
            "divides by delta^2, not delta. The recomputed requirement is reported above."
        ),
    }


PREREG_NUMBERS = {
    "h3b_n_required_ceiling": lambda result: result["h3b"]["n_required_ceiling"],
    "h3b_n_effective": lambda result: result["h3b"]["n_effective"],
    "h3b_mde_4dp": lambda result: round(result["h3b"]["mde"], 4),
    "h3a_binomial_p_4dp": lambda result: round(result["h3a"]["binomial_p_at_target"], 4),
    "h3c_power_3dp": lambda result: round(result["h3c"]["spearman_power_at_target"], 3),
}


def check_prereg(result: dict) -> list[str]:
    if not PREREG.exists():
        return [f"missing {PREREG}"]
    text = PREREG.read_text(encoding="utf-8")
    errors = []
    for name, getter in PREREG_NUMBERS.items():
        expected = f"<!-- {name}: {getter(result)} -->"
        if expected not in text:
            errors.append(f"PREREG missing or stale anchor: {expected}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=ROOT / "runs" / "power_l3.json")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    result = compute()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "h3b_n_required": result["h3b"]["n_required_ceiling"],
        "h3b_n_effective": result["h3b"]["n_effective"],
        "h3b_mde": round(result["h3b"]["mde"], 4),
        "h3a_p": round(result["h3a"]["binomial_p_at_target"], 4),
        "h3c_power": round(result["h3c"]["spearman_power_at_target"], 3),
    }, indent=2))
    errors = check_prereg(result) if args.check else []
    if errors:
        for error in errors:
            print(f"FAIL: {error}")
        return 1
    if args.check:
        print(f"OK: PREREG_L3.md anchors match {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
