#!/usr/bin/env python3
"""追加 D8：STALE 语义、删失偏向、并发烧盘。O_APPEND 单写 + 前缀断言。"""
import hashlib
import os
from pathlib import Path

DOC = Path(__file__).resolve().parent.parent / "DEVIATION_L3.md"

BLOCK = """
## D8（2026-11-10）：量具三条 —— STALE 的语义、删失偏向、并发烧盘

D7 装的是"口径会不会被静默改"，D8 记的是"口径本身测的是什么"。三条都由 LeCun 视角评审指出，
主会话已在落盘产物上独立复算。

### D8.1 `STALE_FAILURE` 不等于"没干完"

`judge.py:48-49` 里 stale 分支优先于完成度：只要注入后出现一次 `basis < plan_version_at[step]` 的写，
就判 STALE，**哪怕之后把 40 个文件全搬完**。

实测（Run A，`runs/l3-runA-50x2x3`，300 条）：
`opencode-go / B` 50/50 STALE，其中 **36 条最终 `verified_count = n_files = 40`（72%）**。
3×2 因子里 13 条 STALE 有 **8 条**同样搬完。

→ 正确表述："B 臂 100% 至少写错过一次版本，其中 72% 最终仍交付全部文件"。
不推翻 B vs D（D 一次没写错），但把"修复失效"降级为"避免一次版本错写"。
**本偏离不改 judge.py 判据**（冻结），只在报告里并列 `stale_and_completed` 计数。

### D8.2 删失偏向：0 步记录在 stale_rate 口径下算"成功"

3×2 因子的 36 条里有 **9 条 `steps = 0`**（`L3-R0005` 六格全 0 步、token 逐位相同 53048，
错误只有 `model call budget exhausted after 40 calls`）。这些记录 verdict 是 INCOMPLETE，
不进 stale 分子 → **系统性偏向 recheck 臂**（它的死格全不 stale）。

剔除死格后的真值：authority 5/5 = 100% STALE，recheck 0/4 = 0% STALE（方向不变，有效单元从 6 降到 4）。
→ 任何报告必须同时给 `n`、`dead_cells`、`n_effective`，不能只给 `stale_rate`。

### D8.3 24 并发把第一次 2880 全烧了（吞吐不是健康证据）

第一次点火：8 分片 × 3 worker = 24 并发，25 分钟"跑完" 2880 条。
实际 `INCOMPLETE 2728 / 2880 = 94.7%`，其中 **2700 条错误原文
`model call budget exhausted after 40 calls`，median `steps = 0`**
→ 限流下空回复被计成 call，40 次瞬间烧光。有效数据只剩 203 条。

处理：`l3_pilot/purge_shard_state.py` 只清「0 步 + 预算耗尽」与 `episode_exception`
（真实跑过步数的 INCOMPLETE 一律保留，防洗白），清掉 2677 条 → 降 16 并发（8×2）重启。
重启 5.5 分钟实测 255 条：STALE 116 / REC 81 / INC 58（22.7%），`budget exhausted` 权重降到 24。

→ 纪律：**吞吐不是健康证据，判决分布才是。** 报进度必须同时报 verdict 分布与错误原文分布。

### D8.4 任务本质是指令服从，不是记忆归因（LeCun 判断，接受）

三条判据都指向"不需要学"：① `if stat.version > basis: basis = stat.version` 这 20 行规则拿满；
② 失效信号在 `agent_arm.py:328-329` 被逐字广播给模型；③ 工具层回 `stale_basis` 免费纠错
（本批 13/13 触发 `refused_stale_write_count = 1`）。
记忆里删一行与被规则改一句，在 context 里都是 token，不可区分。

→ v2 方向：不再"再删几行 memory"，而是换载体（检索内容 / 参数 / KV 可见历史），
让记忆有"能算什么"的差别，否则任何记忆消融都测不出东西。
"""


def main() -> int:
    before = DOC.read_bytes()
    before_hash = hashlib.sha256(before).hexdigest()
    assert b"## D8" not in before, "D8 已存在，拒绝重复追加"
    payload = BLOCK.encode("utf-8")
    fd = os.open(DOC, os.O_WRONLY | os.O_APPEND)
    try:
        os.write(fd, payload)
    finally:
        os.close(fd)
    after = DOC.read_bytes()
    assert after.startswith(before), "追加后前缀不一致"
    assert hashlib.sha256(after[: len(before)]).hexdigest() == before_hash, "前缀哈希不一致"
    print(f"OK: D8 appended, {len(payload)} bytes; {len(before)} -> {len(after)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
